// pages/payment/payment.js
let videoAd = null;

Page({
  data: {
    productId: '',
    productType: '',
    title: '解锁完整内容',
    loading: false,
    errorMsg: ''
  },

  onLoad: function (options) {
    this.setData({
      productId: options.productId || '',
      productType: options.type || '',
      title: options.title ? decodeURIComponent(options.title) : '解锁完整内容'
    });

    this.initAd();
  },

  initAd: function() {
    var self = this;
    if (wx.createRewardedVideoAd) { 
      videoAd = wx.createRewardedVideoAd({ 
        adUnitId: 'adunit-c4492dd7a33354a0' 
      });
      
      videoAd.onLoad(() => {
        console.log('激励视频广告加载成功');
      });
      
      videoAd.onError((err) => { 
        console.error('激励视频广告加载失败', err);
        self.setData({
          errorMsg: '广告加载失败，请稍后重试'
        });
      });
      
      videoAd.onClose((res) => {
        if (res && res.isEnded || res === undefined) {
          self.handleUnlockSuccess();
        } else {
          wx.showToast({
            title: '需观看完整视频才能解锁',
            icon: 'none'
          });
          self.setData({ loading: false });
        }
      });
    } else {
      self.setData({
        errorMsg: '当前微信版本过低，不支持广告功能，请升级'
      });
    }
  },

  watchAd: function() {
    var self = this;
    if (!videoAd) {
      wx.showToast({ title: '广告组件未初始化', icon: 'none' });
      return;
    }

    self.setData({ loading: true, errorMsg: '' });

    videoAd.show().catch(() => { 
      videoAd.load() 
        .then(() => {
          self.setData({ loading: false });
          videoAd.show();
        }) 
        .catch(err => { 
          console.error('激励视频广告显示失败', err);
          self.setData({ 
            loading: false,
            errorMsg: '广告暂时无法显示，请稍后再试'
          });
          wx.showToast({
            title: '广告加载失败',
            icon: 'none'
          });
        });
    });
  },

  handleUnlockSuccess: function() {
    wx.showToast({
      title: '解锁成功',
      icon: 'success'
    });
    
    // 将解锁状态写入缓存，等待上一页 onShow 时去读取
    wx.setStorageSync('pending_unlock', this.data.productType);
    
    var unlockKey = 'ad_unlocked_' + this.data.productType;
    wx.setStorageSync(unlockKey, Date.now());

    // 【极限压缩延迟】：从 1500ms 降至 300ms。这段时间刚好让微信的 Toast 闪现一下，随后立刻开始返回动画
    setTimeout(() => {
      wx.navigateBack({
        delta: 1
      });
    }, 300);
  },

  goBack: function() {
    wx.navigateBack({
      delta: 1
    });
  }
})