// pages/webview/webview.js
Page({
  data: {
    // H5页面URL - 初始为空，等待openid获取后设置
    url: '',
    openid: '',
    apiBaseUrl: '',
    loadError: false,
    retryCount: 0
  },

  onShow: function() {
    // 隐藏左上角的“返回首页”按钮（小房子Icon）
    if (wx.hideHomeButton) {
      wx.hideHomeButton();
    }
    
    // 检查是否有刚看完广告回来的待处理解锁任务
    var pendingUnlock = wx.getStorageSync('pending_unlock');
    if (pendingUnlock) {
      wx.removeStorageSync('pending_unlock');
      console.log('检测到从广告页回来的解锁任务:', pendingUnlock);
      // 【极限压缩延迟】：从 800ms 降至 300ms。避开 navigateBack 的转场动画以防 insertTextView:fail
      setTimeout(() => {
        this.refreshWithUnlock(pendingUnlock);
      }, 300);
    }
  },

  onLoad: function(options) {
    this.optionsCache = options;
    this.initWebview();
  },
  
  initWebview: function() {
    var self = this;
    var options = this.optionsCache || {};
    
    // 动态判断当前小程序运行环境
    var envVersion = 'release';
    try {
      var accountInfo = wx.getAccountInfoSync();
      envVersion = (accountInfo && accountInfo.miniProgram && accountInfo.miniProgram.envVersion) || 'release';
    } catch (e) {}
    
    // 生产环境（正式版）使用 www 域名，开发者工具和体验版使用 dev 域名
    var baseUrl = (envVersion === 'release') 
                  ? 'https://www.caishenlaile88.com' 
                  : 'https://dev.caishenlaile88.com';
    
    console.log('当前环境版本:', envVersion, '分配域名:', baseUrl);
    
    // 启用分享给好友和分享到朋友圈
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });

    var cacheVersion = Date.now();
    var params = [];
    
    var userPhone = wx.getStorageSync('userPhone') || decodeURIComponent(options.phone || '');
    if (userPhone) {
      params.push('phone=' + encodeURIComponent(userPhone));
    }
    var authRejected = wx.getStorageSync('auth_rejected') || options.auth_rejected;
    if (authRejected) {
      params.push('auth_rejected=true');
      wx.removeStorageSync('auth_rejected');
    }
    params.push('api_base=' + encodeURIComponent(baseUrl));
    params.push('v=' + cacheVersion);
    params.push('from_miniprogram=1');
    params.push('retry=' + this.data.retryCount);
    
    if (options.reportId) {
        params.push('reportId=' + encodeURIComponent(options.reportId));
    }
    
    var initialUrl = baseUrl + (params.length > 0 ? '?' + params.join('&') : '');
    self.setData({
      url: initialUrl,
      apiBaseUrl: baseUrl,
      loadError: false
    });
    
    // 清除掉所有可能导致回退的本地缓存域名
    wx.setStorageSync('active_api_base', baseUrl);
    wx.setStorageSync('active_h5_base', baseUrl);
    
    // 异步去获取/刷新 openid
    self.getOpenId(baseUrl, function(openid) {
      console.log('异步获取到openid:', openid ? openid.substring(0, 10) + '...' : '为空');
    });
  },

  // 带着解锁参数强刷H5（尝试使用Hash模式降低重载延迟）
  refreshWithUnlock: function(productType) {
    console.log('执行带解锁参数的极速通信:', productType);
    var currentUrl = this.data.url;
    if (!currentUrl) return;
    
    // 我们不再修改查询参数（?xxx=yyy），因为这一定会导致 Webview 完全刷新白屏。
    // 改为在 URL 的 Hash 部分追加参数。在某些微信版本中，这只会触发 H5 的 hashchange 事件而不会全局重载。
    var urlObj = currentUrl.split('#')[0];
    var newUrl = urlObj + '#unlocked_type=' + encodeURIComponent(productType) + '&ts=' + Date.now();
    
    // 此时本页面一定是当前处于前台且活跃的页面，调用 setData 是安全的
    this.setData({ url: newUrl });
  },

  // 监听Webview加载错误
  handleError: function(e) {
    console.error('Webview加载失败:', e);
    // 自动重试机制（最多重试2次）
    if (this.data.retryCount < 2) {
      this.setData({
        retryCount: this.data.retryCount + 1,
        url: '' // 先清空，强制重新渲染
      }, () => {
        setTimeout(() => {
          this.initWebview();
        }, 1500); // 等待1.5秒后重试，给服务器唤醒时间
      });
    } else {
      // 超过重试次数，显示降级UI
      this.setData({
        loadError: true
      });
    }
  },

  // 监听Webview加载成功
  handleLoad: function(e) {
    console.log('Webview加载成功');
    this.setData({
      loadError: false,
      retryCount: 0
    });
  },

  // 手动重试按钮
  retryLoad: function() {
    this.setData({
      loadError: false,
      url: ''
    }, () => {
      this.initWebview();
    });
  },

  // 监听H5发送的消息
  handleMessage: function(e) {
    var data = e.detail.data;
    if (!data || !data.length) return;
    
    var msg = data[data.length - 1];
    console.log('收到H5消息:', msg);
    
    if (msg.action === 'payment_success') {
      console.log('H5支付成功通知，可在此处处理相关逻辑');
      this.refreshWebview();
    }
  },

  // 刷新webview
  refreshWebview: function() {
    var currentUrl = this.data.url;
    if (!currentUrl) return;
    
    var urlObj = new URL(currentUrl);
    var base = currentUrl.split('?')[0];
    var query = currentUrl.split('?')[1] || '';
    var hashPart = '';
    
    if (query.indexOf('#') > -1) {
      var parts = query.split('#');
      query = parts[0];
      hashPart = '#' + parts[1];
    } else if (base.indexOf('#') > -1) {
      var parts = base.split('#');
      base = parts[0];
      hashPart = '#' + parts[1];
    }
    
    var kv = {};
    query.split('&').forEach(function(item) {
      if (!item) return;
      var pair = item.split('=');
      kv[pair[0]] = pair[1];
    });
    
    kv.refresh_ts = Date.now();
    var newQuery = Object.keys(kv).map(function(key) {
      return key + '=' + kv[key];
    }).join('&');
    var newUrl = base + (newQuery ? '?' + newQuery : '') + hashPart;
    this.setData({ url: newUrl });
  },

  // 获取用户openid
  getOpenId: function(requestBaseUrl, callback) {
    var storedOpenId = wx.getStorageSync('wechatOpenId');
    if (storedOpenId) {
      callback(storedOpenId);
      return;
    }

    wx.login({
      success: function(res) {
        if (res.code) {
          wx.request({
            url: requestBaseUrl + '/api/wechat/login',
            method: 'POST',
            header: {
              'content-type': 'application/json'
            },
            data: { code: res.code },
            success: function(response) {
              var data = response.data;
              if (data.success && data.openid) {
                wx.setStorageSync('wechatOpenId', data.openid);
                callback(data.openid);
              } else {
                console.error('获取openid失败:', data.error);
                callback('');
              }
            },
            fail: function(error) {
              console.error('请求openid失败:', error);
              callback('');
            }
          });
        } else {
          console.error('获取用户登录态失败:', res.errMsg);
          callback('');
        }
      },
      fail: function(error) {
        console.error('wx.login失败:', error);
        callback('');
      }
    });
  },

  // 分享给朋友
  onShareAppMessage: function(options) {
    return {
      title: '裁神来了 - 劳动者裁员法律咨询神器',
      path: '/pages/index/index',
      imageUrl: '' 
    };
  }
})