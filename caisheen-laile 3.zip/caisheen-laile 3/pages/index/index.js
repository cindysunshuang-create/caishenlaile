// pages/index/index.js
Page({
  data: {},

  onLoad: function (options) {
    // 开启分享给朋友和朋友圈（核心需求：保留可分享能力）
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  // 点击“我已知悉，进入体验”按钮
  enterApp: function() {
    // 使用 redirectTo 或者 navigateTo 跳转到 H5 Webview
    // 不要在 onLoad 中直接调，避免引发 routeDone webviewId not found 错误
    wx.redirectTo({
      url: '/pages/webview/webview',
      fail: function(err) {
        console.error('跳转 webview 失败:', err);
        // 如果出错回退方案
        wx.navigateTo({ url: '/pages/webview/webview' });
      }
    });
  },

  // 分享给朋友
  onShareAppMessage: function () {
    return {
      title: '裁神来了 - 劳动者裁员法律咨询神器',
      path: '/pages/index/index',
      imageUrl: '' 
    }
  },

  // 分享到朋友圈
  onShareTimeline: function () {
    return {
      title: '裁神来了 - 劳动者裁员法律咨询神器',
      query: 'from=timeline',
      imageUrl: '' 
    }
  }
})