// pages/save-image/save-image.js
Page({
  data: {
    imageData: '',
    tempFilePath: '',
    isLoading: true,
    statusText: '正在处理图片...'
  },

  onLoad: function(options) {
    // 启用分享给好友和分享到朋友圈
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });

    // 优先检查是否有imageUrl（从服务器上传）
    if (options.imageUrl) {
      try {
        const imageUrl = decodeURIComponent(options.imageUrl);
        this.setData({
          statusText: '正在下载图片...'
        });
        this.downloadAndSaveImage(imageUrl);
        return;
      } catch (e) {
        console.error('解析图片URL失败:', e);
      }
    }

    // 获取传递过来的图片数据（base64）
    if (options.imageData) {
      try {
        const imageData = decodeURIComponent(options.imageData);
        this.setData({
          imageData: imageData,
          statusText: '正在生成图片...'
        });
        this.processAndSaveImage(imageData);
      } catch (e) {
        console.error('解析图片数据失败:', e);
        this.showError('图片数据解析失败');
      }
    } else {
      this.showError('未获取到图片数据');
    }
  },

  // 从URL下载图片并保存
  downloadAndSaveImage: function(imageUrl) {
    const that = this;
    const fileName = `report_${Date.now()}.png`;
    const filePath = `${wx.env.USER_DATA_PATH}/${fileName}`;

    wx.downloadFile({
      url: imageUrl,
      filePath: filePath,
      success: function(res) {
        console.log('图片下载成功:', res.filePath);
        that.setData({
          tempFilePath: res.filePath,
          isLoading: false,
          statusText: '图片已下载'
        });
        that.saveToAlbum(res.filePath);
      },
      fail: function(err) {
        console.error('图片下载失败，使用备用方案:', err);
        // 下载失败时，使用备用的base64处理方式
        // 这里应该返回错误，让用户重试
        that.setData({
          statusText: '正在处理...'
        });
        wx.showModal({
          title: '提示',
          content: '图片加载失败，是否重试？',
          confirmText: '重试',
          cancelText: '返回',
          success: function(res) {
            if (res.confirm) {
              // 重新尝试下载
              that.downloadAndSaveImage(imageUrl);
            } else {
              wx.navigateBack();
            }
          }
        });
      }
    });
  },

  processAndSaveImage: function(base64Data) {
    const that = this;

    // 移除data:image/png;base64,前缀
    const base64DataWithoutPrefix = base64Data.replace(/^data:image\/\w+;base64,/, '');

    // 将base64转换为临时文件
    const fsm = wx.getFileSystemManager();
    const fileName = `report_${Date.now()}.png`;
    const filePath = `${wx.env.USER_DATA_PATH}/${fileName}`;

    fsm.writeFile({
      filePath: filePath,
      data: base64DataWithoutPrefix,
      encoding: 'base64',
      success: function(res) {
        console.log('图片写入成功:', filePath);
        that.setData({
          tempFilePath: filePath,
          isLoading: false,
          statusText: '图片已生成'
        });
        // 自动保存到相册
        that.saveToAlbum(filePath);
      },
      fail: function(err) {
        console.error('图片写入失败:', err);
        that.showError('图片生成失败');
      }
    });
  },

  saveToAlbum: function(filePath) {
    const that = this;

    this.setData({
      statusText: '正在保存到相册...'
    });

    // 首先检查权限状态
    wx.getSetting({
      success: function(res) {
        console.log('权限设置:', res.authSetting);

        // 检查是否有保存到相册的权限
        if (res.authSetting['scope.writePhotosAlbum'] === true) {
          // 已有权限，直接保存
          that.doSaveToAlbum(filePath);
        } else if (res.authSetting['scope.writePhotosAlbum'] === undefined) {
          // 从未设置过权限，请求授权
          wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success: function() {
              console.log('用户授权成功');
              that.doSaveToAlbum(filePath);
            },
            fail: function(authErr) {
              console.error('授权失败:', authErr);
              // 用户拒绝，引导去设置页
              that.showAuthModal(filePath);
            }
          });
        } else {
          // 之前被拒绝过，引导去设置页
          that.showAuthModal(filePath);
        }
      },
      fail: function(err) {
        console.error('获取设置失败:', err);
        // 出错时也尝试直接保存
        that.doSaveToAlbum(filePath);
      }
    });
  },

  // 执行保存到相册
  doSaveToAlbum: function(filePath) {
    const that = this;

    // 保存到相册
    wx.saveImageToPhotosAlbum({
      filePath: filePath,
      success: function(res) {
        console.log('保存成功:', res);
        that.setData({
          statusText: '保存成功！'
        });

        // 通知H5页面保存成功
        wx.miniProgram.postMessage({
          data: {
            type: 'save_success',
            message: '保存成功'
          }
        });

        // 显示保存成功提示（1秒后自动返回）
        wx.showToast({
          title: '已保存到相册',
          icon: 'success',
          duration: 1500
        });

        // 1.5秒后自动返回上一页
        setTimeout(function() {
          wx.navigateBack();
        }, 1500);
      },
      fail: function(err) {
        console.error('保存失败:', err);
        if (err.errMsg && err.errMsg.includes('auth deny')) {
          // 用户拒绝授权
          that.showAuthModal(filePath);
        } else {
          that.showError('保存失败，请重试');
        }
      }
    });
  },

  // 显示授权弹窗
  showAuthModal: function(filePath) {
    const that = this;
    wx.showModal({
      title: '需要授权',
      content: '需要授权保存到相册的权限，才能将报告保存到手机',
      confirmText: '去授权',
      confirmColor: '#07C160',
      success: function(res) {
        if (res.confirm) {
          // 打开设置页面
          wx.openSetting({
            success: function(setRes) {
              if (setRes.authSetting['scope.writePhotosAlbum']) {
                // 用户授权了，重新保存
                that.doSaveToAlbum(filePath);
              } else {
                // 用户仍然拒绝
                that.setData({
                  statusText: '需要授权才能保存'
                });
                wx.navigateBack();
              }
            },
            fail: function() {
              that.showError('无法打开设置');
            }
          });
        } else {
          wx.navigateBack();
        }
      }
    });
  },

  openSetting: function() {
    wx.openSetting({
      success: function(res) {
        console.log('设置页面返回:', res);
        if (res.authSetting['scope.writePhotosAlbum']) {
          // 已授权，重新保存
          if (this.data.tempFilePath) {
            this.saveToAlbum(this.data.tempFilePath);
          }
        }
      }
    });
  },

  showError: function(message) {
    this.setData({
      isLoading: false,
      statusText: message
    });
    wx.showToast({
      title: message,
      icon: 'none',
      duration: 2000
    });
    setTimeout(function() {
      wx.navigateBack();
    }, 2000);
  },

  onShareAppMessage: function() {
    return {
      title: '裁神来了 - 劳动者裁员法律咨询',
      path: '/pages/index/index'
    };
  },

  onShareTimeline: function() {
    return {
      title: '裁神来了 - 劳动者裁员法律咨询',
      query: ''
    };
  }
});
