Page({
  onLoad() {
    // 启用分享给好友和分享到朋友圈
    wx.showShareMenu({
      withShareTicket: true,
      menus: ['shareAppMessage', 'shareTimeline']
    });
  },

  getPhoneNumber(e) {
    if (e.detail.code) {
      wx.showLoading({ title: '授权中...' });
      
      // 动态获取当前环境的BaseURL
      var activeApiBase = wx.getStorageSync('active_api_base') || 'https://www.caishenlaile88.com';
      
      wx.request({
        url: activeApiBase + '/api/wechat/phone',
        method: 'POST',
        data: {
          code: e.detail.code
        },
        success: (res) => {
          wx.hideLoading();
          if (res.data.success) {
            // 保存手机号
            wx.setStorageSync('userPhone', res.data.phone);
            
            // 返回webview主页面并携带手机号参数
            wx.reLaunch({
              url: '/pages/webview/webview?phone=' + encodeURIComponent(res.data.phone)
            });
          } else {
            wx.showToast({
              title: '获取手机号失败: ' + (res.data.error || '未知错误'),
              icon: 'none'
            });
          }
        },
        fail: () => {
          wx.hideLoading();
          wx.showToast({
            title: '网络请求失败',
            icon: 'none'
          });
        }
      });
    } else {
      wx.showToast({
        title: '您拒绝了授权',
        icon: 'none'
      });
    }
  },

  handleCancel() {
    // 用户拒绝授权，标记并返回webview主页面
    wx.setStorageSync('auth_rejected', true);
    wx.reLaunch({
      url: '/pages/webview/webview?auth_rejected=true'
    });
  },

  // 分享给朋友
  onShareAppMessage() {
    return {
      title: '裁神来了 - 劳动者裁员法律咨询',
      path: '/pages/index/index'
    };
  },

  // 分享到朋友圈
  onShareTimeline() {
    return {
      title: '裁神来了 - 劳动者裁员法律咨询',
      query: ''
    };
  }
});
