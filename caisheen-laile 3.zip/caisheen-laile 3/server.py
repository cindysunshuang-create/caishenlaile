#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
裁神来了 - 后端服务
提供AI对话和微信支付功能
部署环境：微信云托管 (Flask)
"""

import os
import json
import hashlib
import hmac
import time
import random
import string
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
import logging

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'caisheen_laile_secret_key_' + str(random.randint(1000, 9999)))

# 启用CORS
CORS(app, supports_credentials=True)

# ==================== 配置 ====================

# AI API配置
API_KEY = os.environ.get('API_KEY', '')
API_BASE_URL = os.environ.get('API_BASE_URL', 'https://api.openai.com/v1')

# ==================== 微信支付配置 ====================
WECHAT_PAY_CONFIG = {
    'appid': os.environ.get('WECHAT_APPID', 'wx466f15c87c417cb8'),
    'app_secret': os.environ.get('WECHAT_APP_SECRET', '1527de3f55a24aba316e84e0434dc9fc'),
    'app_key': os.environ.get('WECHAT_APP_KEY', '3h2aOa8mtXcFwAp4SnddcuiCJJsSpiDu'), # 虚拟支付现网AppKey
    'offer_id': os.environ.get('WECHAT_OFFER_ID', '1450492833'),
    'mch_id': os.environ.get('WECHAT_MCH_ID', '1739611802'),
    'api_key': os.environ.get('WECHAT_API_KEY', 'koushifulovemoneyverymuchcindyss'),
    'api_key_v2': os.environ.get('WECHAT_API_KEY_V2', 'koushifulovemoneyverymuchcindyss'),
    'private_key_path': os.environ.get('WECHAT_PRIVATE_KEY_PATH', '/path/to/apiclient_key.pem'),
    'certificate_path': os.environ.get('WECHAT_CERTIFICATE_PATH', '/path/to/apiclient_cert.pem'),
    'notify_url': os.environ.get('WECHAT_NOTIFY_URL', 'https://caishenlaile88.com/api/payment/notify'),
    'api_base_url': 'https://api.mch.weixin.qq.com',
    'env': int(os.environ.get('WECHAT_PAY_ENV', 1)) # 1: 沙箱环境, 0: 现网环境
}

# 产品价格配置（单位：分）
PRODUCTS = {
    'diagnosis_report': {'name': '专业诊断报告', 'price': 990, 'description': '包含赔偿计算、风险评估、证据清单、谈判话术'},
    'tool_package': {'name': '职场维权工具包', 'price': 490, 'description': '证据清单+模板话术库+完整集'},
    'topic_package': {'name': '解锁热门话题', 'price': 490, 'description': '解锁全部热门话题'}
}
FREE_TOPIC_IDS = ['n1', '2n', 'pip', 'sign']
TOPIC_DATA = [
    {'id': 'n1', 'category': '赔偿', 'title': 'N和N+1的区别', 'desc': '经济补偿金与代通知金', 'content': 'N是指经济补偿金，按劳动者在本单位工作的年限，每满一年支付一个月工资。<br><br>N+1是指经济补偿金+代通知金，公司未提前30天通知需额外支付一个月工资。', 'cases': [{'platform': '脉脉', 'summary': '入职3年，最初只给N，最终协商到N+1', 'result': 'N+1'}]},
    {'id': '2n', 'category': '赔偿', 'title': '2N赔偿金条件', 'desc': '违法解除劳动合同的赔偿', 'content': '2N是赔偿金，适用于违法解除劳动合同的情况，金额是经济补偿金的2倍。', 'cases': [{'platform': '知乎', 'summary': '无合法依据辞退，仲裁判2N', 'result': '2N'}]},
    {'id': 'pip', 'category': '谈判', 'title': 'PIP绩效改进计划', 'desc': '如何应对绩效改进计划', 'content': 'PIP常被用作变相裁员手段。应要求明确指标并保留沟通证据。', 'cases': [{'platform': '脉脉', 'summary': '收集证据后谈判成功拿到N+1.5', 'result': 'N+1.5'}]},
    {'id': 'sign', 'category': '合同', 'title': '试用期转正陷阱', 'desc': '试用期违规解除的识别', 'content': '试用期被违法解除同样可以主张赔偿。不要轻易签不利文件。', 'cases': [{'platform': '小红书', 'summary': '坚持仲裁拿到N+1', 'result': 'N+1'}]},
    {'id': 'contract1', 'category': '合同', 'title': '这些字千万别签', 'desc': '离职协议的自愿离职申请', 'content': '《自愿离职申请》《离职协议》等签署前务必核对补偿条款。', 'cases': [{'platform': '脉脉', 'summary': '拒签后公司提高补偿到N+2', 'result': 'N+2'}]},
    {'id': 'process1', 'category': '流程', 'title': '劳动仲裁流程', 'desc': '申请仲裁的全流程指引', 'content': '提交申请、受理、开庭、调解、裁决，不服可起诉。', 'cases': [{'platform': '知乎', 'summary': '提交完整证据后胜诉', 'result': '胜诉'}]},
    {'id': 'overtime', 'category': '赔偿', 'title': '加班费怎么算？', 'desc': '加班工资计算标准', 'content': '工作日1.5倍、休息日2倍、法定节假日3倍。', 'cases': [{'platform': '脉脉', 'summary': '保留打卡记录追回加班费', 'result': '追回成功'}]},
    {'id': 'social', 'category': '赔偿', 'title': '社保断缴怎么办？', 'desc': '社保公积金维权', 'content': '可向社保局投诉或申请仲裁，要求单位补缴。', 'cases': [{'platform': '小红书', 'summary': '成功补缴公积金', 'result': '补缴成功'}]}
]

# 数据存储
user_sessions = {}
diagnosis_reports = {}
orders = {}


# ==================== 辅助函数 ====================

def generate_order_id():
    timestamp = str(int(time.time()))
    random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    return f"C{timestamp}{random_str}"

def generate_nonce_str():
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=32))

def normalize_user_id(raw):
    if not raw:
        return ''
    return str(raw).strip()

def has_topic_unlock(user_id='', openid=''):
    user_id = normalize_user_id(user_id)
    openid = normalize_user_id(openid)
    if not user_id and not openid:
        return False
    for _, order in orders.items():
        if order.get('product_id') != 'topic_package':
            continue
        if order.get('status') != 'paid':
            continue
        order_user = normalize_user_id(order.get('user_id'))
        order_openid = normalize_user_id(order.get('openid'))
        if (user_id and order_user and user_id == order_user) or (openid and order_openid and openid == order_openid):
            return True
    return False

def calculate_n_months_salary(salary, years):
    return int(salary * years)

def calculate_n_plus_1(salary, years):
    return int(salary * years) + salary

def calculate_2n(salary, years):
    return int(salary * years) * 2


# ==================== H5页面路由 ====================

@app.route('/')
def index():
    """服务H5首页"""
    try:
        return send_from_directory('.', 'index.html')
    except Exception as e:
        logger.error(f"Error serving index.html: {e}")
        return "Index page not found", 404

@app.route('/<path:filename>')
def serve_static(filename):
    """服务静态文件"""
    try:
        return send_from_directory('.', filename)
    except Exception as e:
        logger.error(f"Error serving {filename}: {e}")
        return "File not found", 404


# ==================== 微信支付API ====================

@app.route('/api/payment/create', methods=['POST'])
def create_payment():
    """创建支付订单"""
    try:
        data = request.get_json()
        product_id = data.get('productId', 'diagnosis_report')
        user_id = data.get('userId', 'anonymous')
        openid = data.get('openid', '')

        product = PRODUCTS.get(product_id, PRODUCTS['diagnosis_report'])
        order_id = generate_order_id()
        
        # 价格单位分
        price = product['price']
        
        # 生成虚拟支付签名
        # signData 需要和前端保持完全一致
        offer_id = WECHAT_PAY_CONFIG['offer_id']
        app_key = WECHAT_PAY_CONFIG['app_key']
        
        # 确保顺序与前端 JSON.stringify 生成的字符串完全一致
        # 前端生成的顺序通常是按照对象定义时的顺序，或者按字母排序（取决于 JS 引擎，但通常按定义顺序）
        # 最安全的做法是：让前端只传必要的参数，后端也保持一致
        sign_data_dict = {
            "offerId": offer_id,
            "buyQuantity": 1,
            "env": WECHAT_PAY_CONFIG['env'], # 对应前端的沙箱/现网环境
            "currencyType": "CNY",
            "platform": "android",
            "productId": product_id,
            "goodsPrice": price,
            "outTradeNo": order_id,
            "attach": "payment"
        }
        # 使用 separators=(',', ':') 确保没有多余的空格，与前端 JSON.stringify 一致
        sign_data_str = json.dumps(sign_data_dict, separators=(',', ':'))
        
        # 对于虚拟支付，微信要求 mode 参数也参与签名（如果传了 mode 的话）。
        # 这里为了确保能跑通，如果后续需要加 mode 参数到签名里，可以这样拼：
        # pay_sig_str = sign_data_str # （当前文档：直接对 signData 字符串进行 HMAC-SHA256 签名）
        signature = hmac.new(app_key.encode('utf-8'), sign_data_str.encode('utf-8'), hashlib.sha256).hexdigest()

        # 存储订单
        orders[order_id] = {
            'order_id': order_id,
            'product_id': product_id,
            'user_id': user_id,
            'openid': openid,
            'amount': price,
            'status': 'pending',
            'created_at': time.strftime('%Y-%m-%d %H:%M:%S')
        }

        return jsonify({
            'success': True,
            'order_id': order_id,
            'outTradeNo': order_id,
            'amount': price / 100,
            'mode': 'short_series_goods',
            'signData': sign_data_str,
            'paySig': signature,
            'signature': signature,
            'paySign': signature, # 为了兼容前端字段名
            'timeStamp': str(int(time.time())),
            'nonceStr': generate_nonce_str(),
            'mock': True,
            'note': '请在微信开发者工具中测试真实支付'
        })

    except Exception as e:
        logger.error(f"创建订单失败: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/payment/notify', methods=['POST'])
def payment_notify():
    """微信支付回调"""
    try:
        xml_data = request.data
        logger.info(f"收到支付回调: {xml_data}")
        return '<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>'
    except Exception as e:
        logger.error(f"支付回调处理失败: {str(e)}")
        return '<xml><return_code><![CDATA[FAIL]]></return_code><return_msg><![CDATA[参数错误]]></return_msg></xml>'


@app.route('/api/payment/query/<order_id>', methods=['GET'])
def query_payment(order_id):
    """查询支付状态"""
    order = orders.get(order_id)
    if not order:
        return jsonify({'success': False, 'error': '订单不存在'}), 404
    return jsonify({
        'success': True,
        'order_id': order_id,
        'status': order['status'],
        'amount': order['amount'] / 100
    })

@app.route('/api/topics', methods=['GET'])
def get_topics():
    user_id = request.args.get('userId', '')
    openid = request.args.get('openid', '')
    category = request.args.get('category', '全部')
    unlocked = has_topic_unlock(user_id, openid)
    topics = TOPIC_DATA
    if category and category != '全部':
        topics = [t for t in TOPIC_DATA if t.get('category') == category]
    if not unlocked:
        topics = topics[:4]
    topic_list = [{'id': t['id'], 'category': t['category'], 'title': t['title'], 'desc': t['desc']} for t in topics]
    return jsonify({
        'success': True,
        'hasTopicPackage': unlocked,
        'freeTopicIds': FREE_TOPIC_IDS,
        'topics': topic_list,
        'total': len(TOPIC_DATA)
    })

@app.route('/api/topics/<topic_id>', methods=['GET'])
def get_topic_detail(topic_id):
    user_id = request.args.get('userId', '')
    openid = request.args.get('openid', '')
    unlocked = has_topic_unlock(user_id, openid)
    topic = next((t for t in TOPIC_DATA if t.get('id') == topic_id), None)
    if not topic:
        return jsonify({'success': False, 'error': '话题不存在'}), 404
    if not unlocked and topic_id not in FREE_TOPIC_IDS:
        return jsonify({'success': False, 'needUnlock': True, 'error': '请先解锁热门话题'}), 403
    return jsonify({'success': True, 'hasTopicPackage': unlocked, 'topic': topic})


@app.route('/api/payment/simulate-success', methods=['POST'])
def simulate_payment_success():
    """模拟支付成功（测试用）"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if order_id in orders:
            orders[order_id]['status'] = 'paid'
            orders[order_id]['paid_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
            return jsonify({'success': True, 'message': '模拟支付成功', 'order_id': order_id})
        return jsonify({'success': False, 'error': '订单不存在'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== 微信登录 ====================

@app.route('/api/wechat/login', methods=['POST'])
def wechat_login():
    """微信小程序登录，获取openid"""
    try:
        data = request.get_json()
        code = data.get('code')
        if not code:
            return jsonify({'success': False, 'error': 'code不能为空'}), 400

        appid = WECHAT_PAY_CONFIG['appid']
        secret = WECHAT_PAY_CONFIG.get('app_secret')

        url = f"https://api.weixin.qq.com/sns/jscode2session?appid={appid}&secret={secret}&js_code={code}&grant_type=authorization_code"
        response = requests.get(url, timeout=10)
        result = response.json()

        if 'openid' in result:
            # 移除明文传输 session_key 的逻辑，修复安全风险
            return jsonify({'success': True, 'openid': result.get('openid')})
        else:
            return jsonify({
                'success': True,
                'openid': f"mock_openid_{int(time.time())}",
                'mock': True
            })
    except Exception as e:
        logger.error(f"微信登录失败: {str(e)}")
        return jsonify({'success': True, 'openid': f"mock_openid_{int(time.time())}", 'mock': True})


# ==================== AI对话API ====================

@app.route('/api/ai/chat', methods=['POST'])
def ai_chat():
    """AI对话接口"""
    try:
        data = request.get_json()
        user_message = data.get('message', '')
        conversation_history = data.get('history', [])

        if not user_message:
            return jsonify({'success': False, 'error': '消息不能为空'}), 400

        messages = [
            {"role": "system", "content": """你是一位专业的劳动法律助手，专注于帮助劳动者维护自身权益。
你的职责是：
1. 用通俗易懂的语言解释劳动法相关知识
2. 分析裁员场景下的合法权益
3. 提供N、N+1、2N等赔偿计算逻辑
4. 给出实用的谈判话术和建议
5. 提醒用户收集证据的重要性

请用中文回复，语气专业但亲切。不要给出具体的法律建议，但可以提供法律信息参考。"""}
        ]

        for msg in conversation_history[-10:]:
            messages.append(msg)
        messages.append({"role": "user", "content": user_message})

        # 如果有API Key，调用AI
        if API_KEY:
            headers = {'Authorization': f'Bearer {API_KEY}', 'Content-Type': 'application/json'}
            payload = {'model': 'gpt-3.5-turbo', 'messages': messages, 'max_tokens': 1000, 'temperature': 0.7}
            response = requests.post(f'{API_BASE_URL}/chat/completions', headers=headers, json=payload, timeout=30)
            if response.status_code == 200:
                result = response.json()
                ai_reply = result['choices'][0]['message']['content']
                return jsonify({'success': True, 'reply': ai_reply})

        # 无API Key或调用失败，使用预设回复
        fallback_reply = get_fallback_reply(user_message)
        return jsonify({'success': True, 'reply': fallback_reply, 'fallback': True})

    except Exception as e:
        logger.error(f"AI对话错误: {str(e)}")
        fallback_reply = get_fallback_reply(user_message if 'user_message' in locals() else '')
        return jsonify({'success': True, 'reply': fallback_reply, 'fallback': True})


def get_fallback_reply(user_message):
    message_lower = user_message.lower()
    if 'n+1' in message_lower or '经济补偿' in message_lower:
        return """N是指经济补偿金，每工作一年支付一个月工资。N+1是在此基础上额外加一个月代通知金。

适用情况：
• N：合同到期不续签、协商解除等
• N+1：公司未提前30天书面通知解除（立即走人）

如果公司违法解除劳动合同，你可以主张2N赔偿！"""
    elif '2n' in message_lower or '赔偿金' in message_lower:
        return """2N是赔偿金，适用于违法解除劳动合同的情况，包括：
• 没有任何正当理由就解除合同
• 试用期无正当理由辞退
• 孕期、产期、哺乳期女职工被辞退
建议先做专业诊断，明确您的具体情况属于哪种情况。"""
    elif '证据' in message_lower or '举证' in message_lower:
        return """劳动仲裁关键证据清单：
1. 劳动合同（最重要）
2. 工资流水、社保缴费记录
3. 考勤记录（钉钉/飞书录屏）
4. 裁员通知、沟通记录
建议立即备份所有证据，防止被公司删除！"""
    else:
        return """感谢您的提问！根据您描述的情况，我建议您：
1. 先收集好相关证据（劳动合同、工资流水、考勤记录等）
2. 了解自己的合法权益
3. 做一个详细的专业诊断，获取个性化方案

如有更多问题，欢迎继续咨询！"""


# ==================== 诊断报告API ====================

@app.route('/api/diagnosis/generate', methods=['POST'])
def generate_diagnosis():
    """生成诊断报告"""
    try:
        data = request.get_json()
        entry_date = data.get('entryDate')
        leave_date = data.get('leaveDate')
        avg_salary = float(data.get('avgSalary', 0))
        reason = data.get('reason')
        notice = data.get('notice')
        employment_type = data.get('employmentType')
        company_nature = data.get('companyNature')

        entry = time.strptime(entry_date, '%Y-%m-%d')
        leave = time.strptime(leave_date, '%Y-%m-%d')
        years = (time.mktime(leave) - time.mktime(entry)) / (365 * 24 * 3600)
        years = round(years, 1)

        n_months = calculate_n_months_salary(avg_salary, years)
        n_plus_1 = calculate_n_plus_1(avg_salary, years)
        two_n = calculate_2n(avg_salary, years)

        risk_level = 'low'
        risk_text = '根据您提供的情况，公司操作较为规范，建议与公司友好协商。'
        if notice == 'no':
            risk_level = 'medium'
            risk_text = '根据您提供的情况，公司未提前30天书面通知，可能存在程序违法。'
        elif reason in ['unknown', 'performance']:
            risk_level = 'medium'
            risk_text = '根据您提供的情况，公司裁员理由不够充分。'

        report = {
            'report_id': generate_order_id(),
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'diagnosis': {'entry_date': entry_date, 'leave_date': leave_date, 'years': years, 'avg_salary': avg_salary, 'reason': reason, 'notice': notice, 'employment_type': employment_type, 'company_nature': company_nature},
            'compensation': {'n': n_months, 'n_plus_1': n_plus_1, 'two_n': two_n},
            'risk': {'level': risk_level, 'text': risk_text},
            'evidence_checklist': [
                {'title': '劳动合同', 'desc': '确认合同期限、工资标准、工作内容等关键条款'},
                {'title': '工资流水', 'desc': '打印最近12个月的银行流水，盖章备存'},
                {'title': '考勤记录', 'desc': '立即录屏保存钉钉/飞书打卡记录'},
                {'title': '裁员通知', 'desc': '保留公司发出的书面裁员通知、邮件、聊天记录'},
                {'title': '离职证明', 'desc': '如已开具，注意核对内容是否与实际情况一致'}
            ],
            'negotiation_tips': ['保持冷静，不要在情绪激动时做决定', '要求公司出具书面解除通知', '核对赔偿金额是否按法律规定计算', '不要签署任何空白或不了解的文件']
        }

        report_id = report['report_id']
        diagnosis_reports[report_id] = report
        return jsonify({'success': True, 'report': report, 'report_id': report_id})

    except Exception as e:
        logger.error(f"生成诊断报告错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/diagnosis/get/<report_id>', methods=['GET'])
def get_diagnosis(report_id):
    """获取诊断报告"""
    report = diagnosis_reports.get(report_id)
    if report:
        return jsonify({'success': True, 'report': report})
    return jsonify({'success': False, 'error': '报告不存在'}), 404


# ==================== 用户API ====================

@app.route('/api/user/login', methods=['POST'])
def user_login():
    """用户登录/注册"""
    try:
        data = request.get_json()
        phone = data.get('phone')
        name = data.get('name', '用户')
        if not phone:
            return jsonify({'success': False, 'error': '手机号不能为空'}), 400

        user_id = f"user_{phone[-4:]}_{int(time.time())}"
        user_sessions[user_id] = {'phone': phone, 'name': name, 'created_at': time.strftime('%Y-%m-%d %H:%M:%S')}
        return jsonify({'success': True, 'user': {'id': user_id, 'phone': phone, 'name': name}})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== 健康检查 ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'ok',
        'service': '裁神来了后端服务',
        'version': '2.0.0',
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        'wechat_pay_configured': WECHAT_PAY_CONFIG['mch_id'] != 'YOUR_MCH_ID'
    })


# ==================== 启动服务 ====================

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=False)
