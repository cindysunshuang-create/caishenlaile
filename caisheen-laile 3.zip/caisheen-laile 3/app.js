// 裁神来了 - 小程序入口
const WeChatPay = require('./wechat-pay.js');

App({
  onLaunch() {
    console.log('裁神来了小程序启动');

    // 初始化微信支付模块
    WeChatPay.initWeChatPay();
  },
  onShow() {
    // 小程序显示时执行
  },
  onHide() {
    // 小程序隐藏时执行
  },
  globalData: {
    userInfo: null,
    apiBaseUrl: 'https://www.caishenlaile88.com',
    WeChatPay: WeChatPay
  }
});
