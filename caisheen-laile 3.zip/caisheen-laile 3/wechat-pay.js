/**
 * 微信支付模块
 * 用于小程序端调起微信支付
 */

// 存储用户openid
let userOpenId = '';

/**
 * 初始化微信支付
 * 需要在小程序启动时调用
 */
function initWeChatPay() {
    // 检查是否在微信环境中
    if (typeof wx === 'undefined') {
        console.log('非微信环境，使用模拟支付');
        return;
    }

    console.log('微信支付模块已初始化');

    // 尝试从本地存储获取openid
    try {
        const storedOpenId = wx.getStorageSync('wechatOpenId');
        if (storedOpenId) {
            userOpenId = storedOpenId;
            console.log('已从存储获取openid:', userOpenId);
        }
    } catch (e) {
        console.error('读取openid失败:', e);
    }
}

/**
 * 获取用户openid
 * 通过微信登录获取
 */
async function getUserOpenId() {
    // 如果已有openid，直接返回
    if (userOpenId) {
        return userOpenId;
    }

    // 尝试从本地存储获取
    try {
        const storedOpenId = wx.getStorageSync('wechatOpenId');
        if (storedOpenId) {
            userOpenId = storedOpenId;
            return userOpenId;
        }
    } catch (e) {
        console.error('读取openid失败:', e);
    }

    // 如果在小程序环境中，尝试获取openid
    if (typeof wx !== 'undefined' && wx.login) {
        try {
            // 调用wx.login获取code
            const loginResult = await new Promise((resolve, reject) => {
                wx.login({
                    success: resolve,
                    fail: reject
                });
            });

            // 将code发送到后端获取openid
            const response = await wx.request({
                url: 'https://www.caishenlaile88.com/api/wechat/login',
                method: 'POST',
                data: { code: loginResult.code }
            });

            const data = response.data;
            if (data.success && data.openid) {
                userOpenId = data.openid;
                try {
                    wx.setStorageSync('wechatOpenId', data.openid);
                } catch (e) {
                    console.error('存储openid失败:', e);
                }
                return data.openid;
            }
        } catch (error) {
            console.error('获取openid失败:', error);
        }
    }

    return null;
}

/**
 * 创建支付订单
 * @param {string} productId - 产品ID
 * @returns {Promise}
 */
async function createPaymentOrder(productId) {
    try {
        // 获取用户openid
        const openid = await getUserOpenId();

        console.log('创建订单，openid:', openid);

        // 调用后端创建订单
        const response = await wx.request({
            url: 'https://www.caishenlaile88.com/api/payment/create',
            method: 'POST',
            data: {
                productId: productId,
                openid: openid || ''
            }
        });

        const data = response.data;
        console.log('创建订单响应:', data);
        return data;
    } catch (error) {
        console.error('创建订单失败:', error);
        return {
            success: false,
            error: error.errMsg || error.message || '创建订单失败'
        };
    }
}

/**
 * 调起微信支付
 * @param {Object} paymentParams - 支付参数
 * @returns {Promise}
 */
function requestWeChatPay(paymentParams) {
    return new Promise((resolve, reject) => {
        // 检查是否在微信环境中
        if (typeof wx === 'undefined' || !wx.requestPayment) {
            // 非微信环境，模拟支付成功
            console.log('非微信环境，模拟支付');
            resolve({
                success: true,
                mock: true,
                message: '模拟支付成功'
            });
            return;
        }

        // 测试环境暂时禁用虚拟支付插件，避免报错
        if (false && typeof wx !== 'undefined' && wx.requestVirtualPayment && paymentParams.signData) {
            console.log('调起微信虚拟支付，参数:', paymentParams);
            wx.requestVirtualPayment({
                signData: paymentParams.signData,
                paySig: paymentParams.paySig,
                signature: paymentParams.signature || '',
                mode: paymentParams.mode || 'short_series_goods',
                success: (res) => {
                    console.log('虚拟支付成功:', res);
                    resolve({
                        success: true,
                        message: '支付成功'
                    });
                },
                fail: (err) => {
                    console.log('虚拟支付失败:', err);
                    reject({
                        success: false,
                        error: err.errMsg || '支付失败'
                    });
                }
            });
            return;
        }

        console.log('调起微信支付，参数:', paymentParams);

        // 微信环境，调用真实支付
        wx.requestPayment({
            timeStamp: paymentParams.timeStamp,
            nonceStr: paymentParams.nonceStr,
            package: paymentParams.package,
            signType: paymentParams.signType || 'MD5',
            paySign: paymentParams.paySign,
            success: (res) => {
                console.log('支付成功:', res);
                resolve({
                    success: true,
                    message: '支付成功'
                });
            },
            fail: (err) => {
                console.log('支付失败:', err);
                reject({
                    success: false,
                    error: err.errMsg || '支付失败'
                });
            }
        });
    });
}

/**
 * 完整的支付流程
 * @param {string} productId - 产品ID
 * @returns {Promise}
 */
async function processPayment(productId) {
    try {
        wx.showLoading({ title: '创建订单中...' });

        // 1. 创建订单
        const orderResult = await createPaymentOrder(productId);

        wx.hideLoading();

        if (!orderResult.success) {
            wx.showToast({
                title: orderResult.error || '创建订单失败',
                icon: 'none'
            });
            return {
                success: false,
                error: orderResult.error || '创建订单失败'
            };
        }

        // 2. 如果是模拟环境，直接返回成功
        if (orderResult.mock) {
            wx.showToast({
                title: '模拟支付成功',
                icon: 'success'
            });
            return {
                success: true,
                orderId: orderResult.order_id,
                mock: true,
                message: '模拟支付成功'
            };
        }

        // 3. 微信环境，调起支付
        // 测试环境暂时禁用虚拟支付
        if (false && orderResult.signData && orderResult.paySig) {
            wx.showLoading({ title: '调起支付...' });
            try {
                const payResult = await requestWeChatPay({
                    signData: typeof orderResult.signData === 'string' ? orderResult.signData : JSON.stringify(orderResult.signData),
                    paySig: orderResult.paySig,
                    signature: orderResult.signature || '',
                    mode: orderResult.mode || 'short_series_goods'
                });

                wx.hideLoading();

                if (payResult.success) {
                    wx.showToast({
                        title: '支付成功',
                        icon: 'success'
                    });
                }
                return payResult;
            } catch (payError) {
                wx.hideLoading();
                console.error('支付失败:', payError);
                wx.showToast({
                    title: payError.error || '支付失败',
                    icon: 'none'
                });
                return payError;
            }
        }
        
        // 兜底检查常规支付参数
        if (orderResult.timeStamp && orderResult.nonceStr && orderResult.package && orderResult.paySign) {
            wx.showLoading({ title: '调起支付...' });

            try {
                const payResult = await requestWeChatPay({
                    timeStamp: orderResult.timeStamp,
                    nonceStr: orderResult.nonceStr,
                    package: orderResult.package,
                    signType: orderResult.signType || 'MD5',
                    paySign: orderResult.paySign
                });

                wx.hideLoading();

                if (payResult.success) {
                    wx.showToast({
                        title: '支付成功',
                        icon: 'success'
                    });
                }

                return payResult;
            } catch (payError) {
                wx.hideLoading();
                console.error('支付失败:', payError);
                wx.showToast({
                    title: payError.error || '支付失败',
                    icon: 'none'
                });
                return payError;
            }
        }

        return {
            success: false,
            error: '支付参数获取失败'
        };

    } catch (error) {
        wx.hideLoading();
        console.error('支付流程错误:', error);
        wx.showToast({
            title: error.message || '支付失败',
            icon: 'none'
        });
        return {
            success: false,
            error: error.message || '支付失败'
        };
    }
}

/**
 * 查询订单状态
 * @param {string} orderId - 订单ID
 * @returns {Promise}
 */
async function queryOrderStatus(orderId) {
    try {
        const response = await wx.request({
            url: `https://www.caishenlaile88.com/api/payment/query/${orderId}`,
            method: 'GET'
        });
        return response.data;
    } catch (error) {
        console.error('查询订单失败:', error);
        return {
            success: false,
            error: error.errMsg || '查询订单失败'
        };
    }
}

/**
 * 模拟支付成功（仅用于测试）
 * @param {string} orderId - 订单ID
 * @returns {Promise}
 */
async function simulatePaymentSuccess(orderId) {
    try {
        const response = await wx.request({
            url: 'https://www.caishenlaile88.com/api/payment/simulate-success',
            method: 'POST',
            data: { order_id: orderId }
        });
        return response.data;
    } catch (error) {
        console.error('模拟支付失败:', error);
        return {
            success: false,
            error: error.errMsg || '模拟支付失败'
        };
    }
}

// 导出模块
module.exports = {
    initWeChatPay,
    getUserOpenId,
    createPaymentOrder,
    requestWeChatPay,
    processPayment,
    queryOrderStatus,
    simulatePaymentSuccess
};
