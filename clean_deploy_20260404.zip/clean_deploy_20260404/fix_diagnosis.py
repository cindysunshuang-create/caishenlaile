import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. 修复 viewReport，记录当前正在查看的 report ID
old_view = r"window\.viewReport = function\(reportId\) \{([\s\S]*?)showReport\(\);\n\};"
new_view = r"""window.viewReport = function(reportId) {\1
    try { localStorage.setItem('viewing_report_id', reportId); } catch(e) {}
    showReport();
};"""
content = re.sub(old_view, new_view, content)

# 2. 修复 submitDiagnosis，保存报告
old_submit = r"window\.submitDiagnosis = function\(\) \{[\s\S]*?showPaymentModal\(\);\n\};"
new_submit = """window.submitDiagnosis = function() {
    closeDiagnosis();
    fetchDiagnosisReport().catch(function(err) {});
    
    // 强制保存到历史记录，以便看完广告刷新后能恢复数据
    if (typeof saveReportToHistory === 'function') {
        saveReportToHistory(false);
        if (AppState.savedReports && AppState.savedReports.length > 0) {
            try { localStorage.setItem('viewing_report_id', AppState.savedReports[0].id); } catch(e) {}
        }
    }
    
    if (!checkAdUnlocked('diagnosis_report')) {
        showPaymentModal('diagnosis_report', 0);
        return;
    }
    showReport(true);
};"""
content = re.sub(old_submit, new_submit, content)

# 3. 修复 handlePaymentSuccess 中的 diagnosis_report 逻辑
old_handle = r"\} else if \(productType === 'diagnosis_report'\) \{[\s\S]*?showReport\(\);\n    \}"
new_handle = """} else if (productType === 'diagnosis_report') {
        AppState.hasDiagnosisReport = true;
        
        var viewingId = null;
        try { viewingId = localStorage.getItem('viewing_report_id'); } catch(e) {}
        
        var report = null;
        if (viewingId && AppState.savedReports) {
            report = AppState.savedReports.find(function(r) { return r.id === viewingId; });
        }
        if (!report && AppState.savedReports && AppState.savedReports.length > 0) {
            report = AppState.savedReports[0];
        }
        
        if (report) {
            report.isPaid = true;
            try { localStorage.setItem('caisheen_reports', JSON.stringify(AppState.savedReports)); } catch(e) {}
            AppState.userData = Object.assign({}, report.userData);
            AppState.calculatedData = Object.assign({}, report.calculatedData);
        } else {
            saveReportToHistory(true);
        }
        
        closePaymentModal();
        if (typeof old_showReport === 'function') {
            old_showReport(true);
        } else {
            showReport(true);
        }
    }"""
content = re.sub(old_handle, new_handle, content)

# 4. 确保 showPaymentModal 中 productType 为空时的默认值
content = content.replace("window.showPaymentModal = function(productType, price) {\n    if (!checkLogin(true)) return;", "window.showPaymentModal = function(productType, price) {\n    if (!checkLogin(true)) return;\n    productType = productType || 'diagnosis_report';")

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)

# Bump index.html version cache
index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()

html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_DIAGNOSIS_FIX', html_content)
with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print("Diagnosis report generation, storage, and retrieval patched.")