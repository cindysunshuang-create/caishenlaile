import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 强制修复话题列表渲染，去掉所有的付费锁逻辑，直接渲染本地数据
old_render_topic_page = re.search(r"function renderTopicPage\(filterCategory\) \{.*?(?=function showTopicDetail\()", content, re.DOTALL)
if old_render_topic_page:
    new_render_topic_page = """function renderTopicPage(filterCategory) {
    var container = document.getElementById('topic-list-container');
    var paywall = document.getElementById('topic-paywall');
    if (!container) return;

    if (paywall) paywall.style.display = 'none';

    var filteredData = TopicData;
    if (filterCategory && filterCategory !== '全部') {
        filteredData = TopicData.filter(function(item) {
            return item.category === filterCategory;
        });
    }

    var html = '';
    filteredData.forEach(function(item) {
        html += '<div class="topic-item" onclick="showTopicDetail(\\'' + item.id + '\\')">' +
            '<div class="topic-icon">💡</div>' +
            '<div class="topic-info">' +
            '<h3>' + item.title + '</h3>' +
            '<p>' + item.desc + '</p>' +
            '</div>' +
            '</div>';
    });

    container.innerHTML = html;
}

"""
    content = content.replace(old_render_topic_page.group(0), new_render_topic_page)
    print("Fixed renderTopicPage")
else:
    print("WARNING: renderTopicPage not found!")

# 强制修复话术库渲染
old_render_script_page = re.search(r"function renderScriptPage\(\) \{.*?(?=function renderEvidenceList\(\) \{)", content, re.DOTALL)
if old_render_script_page:
    new_render_script_page = """function renderScriptPage() {
    var container = document.getElementById('script-library-content');
    if (!container) return;

    var html = '';
    ScriptData.forEach(function(item) {
        html += '<div class="topic-item" onclick="showScriptDetail(' + item.id + ')">' +
            '<div class="topic-icon">💬</div>' +
            '<div class="topic-info">' +
            '<h3>' + item.title + '</h3>' +
            '<p>' + item.desc + '</p>' +
            '</div>' +
            '</div>';
    });

    container.innerHTML = html;
}

"""
    content = content.replace(old_render_script_page.group(0), new_render_script_page)
    print("Fixed renderScriptPage")
else:
    print("WARNING: renderScriptPage not found!")

# 强制修复话术库详情
old_script_detail = re.search(r"window\.showScriptDetail = function\(scriptId\) \{.*?(?=window\.showTopicDetail = function)", content, re.DOTALL)
if old_script_detail:
    new_script_detail = """window.showScriptDetail = function(scriptId) {
    if (!checkLogin(true)) return;
    
    var script = ScriptData.find(function(s) { return s.id === scriptId; });
    if (!script) return;

    var modal = document.getElementById('script-detail-modal');
    var detailTitle = document.getElementById('script-detail-title');
    var detailBody = document.querySelector('.script-detail-body');
    
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
        
        if (detailTitle) detailTitle.textContent = script.title;
        if (detailBody) {
            detailBody.innerHTML = '<div class="topic-content-box">' +
                '<h4 style="color:#F59E0B;margin-bottom:8px;">HR 话术：</h4>' +
                '<p style="margin-bottom:16px;">' + script.hrSay + '</p>' +
                '<h4 style="color:#EF4444;margin-bottom:8px;">背后的真相：</h4>' +
                '<p style="margin-bottom:16px;">' + script.truth + '</p>' +
                '<h4 style="color:#10B981;margin-bottom:8px;">应对方案：</h4>' +
                '<p>' + script.answer + '</p>' +
                '</div>';
        }
    }
};

"""
    content = content.replace(old_script_detail.group(0), new_script_detail)
    print("Fixed showScriptDetail")

# 更换 v 值爆破缓存
index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()
html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_TRUE_FEATURES', html_content)
with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Features fully patched.")
