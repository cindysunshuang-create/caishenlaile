import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Remove showAuthModal from enterApp
old_enter_app = """// 进入应用
window.enterApp = function() {
    var splashScreen = document.getElementById('splash-screen');
    var mainContent = document.getElementById('main-content');

    // 点击"进入体验"时先显示微信授权
    // 用户拒绝后记录状态，后续功能中再次提示
    showAuthModal();

    if (splashScreen) {
        splashScreen.style.display = 'none';
    }
    if (mainContent) {
        mainContent.classList.remove('hidden');
        mainContent.style.display = 'block';
    }
};"""

new_enter_app = """// 进入应用
window.enterApp = function() {
    var splashScreen = document.getElementById('splash-screen');
    var mainContent = document.getElementById('main-content');

    if (splashScreen) {
        splashScreen.style.display = 'none';
    }
    if (mainContent) {
        mainContent.classList.remove('hidden');
        mainContent.style.display = 'block';
    }
};"""
content = content.replace(old_enter_app, new_enter_app)

# 2. Auto-hide splash screen if from_miniprogram=1
old_init = """document.addEventListener('DOMContentLoaded', function() {
    console.log('裁神来了 - DOM加载完成');

    // 初始化数据渲染
    initLandingPage();"""

new_init = """document.addEventListener('DOMContentLoaded', function() {
    console.log('裁神来了 - DOM加载完成');

    // 如果从小程序进入，跳过H5引导页
    if (window.location.search.indexOf('from_miniprogram=1') > -1) {
        var splashScreen = document.getElementById('splash-screen');
        var mainContent = document.getElementById('main-content');
        if (splashScreen) splashScreen.style.display = 'none';
        if (mainContent) {
            mainContent.classList.remove('hidden');
            mainContent.style.display = 'block';
        }
    }

    // 初始化数据渲染
    initLandingPage();"""
content = content.replace(old_init, new_init)

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Patched app.js to fix double splash screen and auto-login popup")
