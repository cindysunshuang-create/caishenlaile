import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 替换所有硬编码的 ¥4.9 文案为观看广告解锁

# 1. 替换话题库底部的解锁按钮
content = content.replace('🔒 解锁全部话题（¥4.9）', '🎬 观看30s广告解锁')
content = content.replace('🔓 解锁全部话题（¥4.9）', '🎬 观看30s广告解锁')

# 2. 替换话术库底部的解锁按钮
content = content.replace('🔒 解锁全部话术（¥4.9）', '🎬 观看30s广告解锁')

# 3. 替换某些可能的弹窗内的文案
content = content.replace('<div class="pay-price">¥4.9</div>', '<div class="pay-price" style="font-size:16px;">免费(看广告)</div>')
content = content.replace('付费解锁更多话术', '观看广告解锁更多话术')

# 替换支付弹窗里的通用文字
content = content.replace('💡 付费后可查看全部话题详情和真实案例', '💡 观看广告后可免费查看全部话题详情和真实案例')
content = content.replace('💡 付费后可查看完整话术库和应对策略', '💡 观看广告后可免费查看完整话术库和应对策略')

# 确保按钮点击行为正确，将可能遗漏的 purchaseTopicPackage 和 showPaymentModal(xxx, 4.9) 替换
content = content.replace('onclick="purchaseTopicPackage()"', 'onclick="showPaymentModal(\'topic\', 0)"')
content = content.replace('showPaymentModal(\'topic_package\', 4.9)', 'showPaymentModal(\'topic\', 0)')
content = content.replace('showPaymentModal(\'tool_package\', 4.9)', 'showPaymentModal(\'script\', 0)')

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)

# Update index.html version cache
index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()

html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_ADS_UI', html_content)
with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print("Ads UI successfully patched!")