import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 替换旧的 DOMContentLoaded 监听器
old_listener = """// 监听从小程序原生页回退时的 URL 变化，自动触发解锁展开
document.addEventListener('DOMContentLoaded', function() {
    try {
        var urlParams = new URLSearchParams(window.location.search);
        var unlockedType = urlParams.get('unlocked_type');
        
        // 如果是因为看完广告返回而带上的参数，或者带有 refresh_ts 且有缓存
        if (unlockedType) {
            console.log('检测到广告解锁返回参数:', unlockedType);
            setTimeout(function() {
                if (typeof window.handlePaymentSuccess === 'function') {
                    window.handlePaymentSuccess(unlockedType);
                }
            }, 500); // 稍微延迟，确保 DOM 已经渲染完毕
        }
    } catch(e) {}
});"""

new_listener = """// 极速监听 URL 变化（支持 Query 和 Hash 两种模式）
function processUnlockFromUrl() {
    try {
        var urlParams = new URLSearchParams(window.location.search);
        var unlockedType = urlParams.get('unlocked_type');
        
        if (!unlockedType && window.location.hash) {
            var hashParams = new URLSearchParams(window.location.hash.substring(1));
            unlockedType = hashParams.get('unlocked_type');
        }
        
        if (unlockedType) {
            console.log('检测到广告解锁极速返回参数:', unlockedType);
            setTimeout(function() {
                if (typeof window.handlePaymentSuccess === 'function') {
                    window.handlePaymentSuccess(unlockedType);
                }
            }, 50); // 【极限压缩延迟】：50ms，仅为确保 JS 线程空闲
        }
    } catch(e) {}
}

document.addEventListener('DOMContentLoaded', processUnlockFromUrl);
window.addEventListener('hashchange', processUnlockFromUrl);"""

content = content.replace(old_listener, new_listener)

# 如果找不到旧的监听器，可能是因为之前被修改过，保险起见直接在末尾追加新的
if new_listener not in content:
    content += "\n" + new_listener

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)

# Update index.html version cache
index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()

html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_ZERO_LATENCY', html_content)
with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print("H5 latency logic patched successfully!")