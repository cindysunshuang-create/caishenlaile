import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. 替换 showPaymentModal 中的逻辑
old_show_payment_modal = re.search(r"window\.showPaymentModal = function\(productType, price\) \{.*?(?=window\.closePaymentModal = function)", content, re.DOTALL)
if old_show_payment_modal:
    new_show_payment_modal = """window.showPaymentModal = function(productType, price) {
    if (!checkLogin(true)) return;

    var productId = productType === 'script' ? 'tool_package' : productType;
    var displayTitle = '解锁完整报告';

    if (productType === 'script' || productType === 'tool_package') {
        displayTitle = '解锁谈判话术库';
    } else if (productType === 'topic_package' || productType === 'topic') {
        displayTitle = '解锁热门话题';
    }

    var searchStr = window.location.search || '';
    var hasWx = typeof wx !== 'undefined';
    var hasMiniProgram = hasWx && wx && typeof wx.miniProgram !== 'undefined';

    if (hasMiniProgram) {
        var targetUrl = '/pages/payment/payment?productId=' + encodeURIComponent(productId) +
            '&type=' + encodeURIComponent(productType) +
            '&title=' + encodeURIComponent(displayTitle) +
            '&unlockMode=rewarded_ad';

        wx.miniProgram.navigateTo({
            url: targetUrl,
            fail: function(err) {
                console.log('跳转广告解锁页失败:', err);
                showToast('广告解锁页打开失败，请重试');
            }
        });
        return;
    } else {
        // H5 fallback
        showToast('请在微信小程序中使用此功能');
    }
};

"""
    content = content.replace(old_show_payment_modal.group(0), new_show_payment_modal)
    print("Replaced showPaymentModal")

# 2. 替换 completePayment (虽然它可能不再被直接调用，但作为 fallback)
old_complete = re.search(r"window\.completePayment = function\(\) \{.*?(?=window\.skipPayment = function)", content, re.DOTALL)
if old_complete:
    new_complete = """window.completePayment = function() {
    // 这个函数已经不再直接处理支付，直接调用 showPaymentModal 以确保走广告逻辑
    var productType = (AppState.currentPayment && AppState.currentPayment.type) || 'diagnosis_report';
    showPaymentModal(productType, 0);
};

"""
    content = content.replace(old_complete.group(0), new_complete)
    print("Replaced completePayment")

# 3. 拦截 H5 中的点击事件，检查本地存储是否已被小程序更新为解锁
new_unlock_check = """
// 广告解锁检查
window.checkAdUnlocked = function(productType) {
    try {
        var unlockKey = 'ad_unlocked_' + productType;
        // 在实际业务中，由于小程序是在自己原生层写了 Storage，H5无法直接读取小程序的 Storage。
        // 所以我们依赖 URL 参数刷新，或者我们在 webview.js 中通过 reload H5 并加上参数
        // H5 检查 URL 中是否有刷新标记或广告解锁标记
        var urlParams = new URLSearchParams(window.location.search);
        var unlockedType = urlParams.get('unlocked_type');
        if (unlockedType === productType) {
            return true;
        }
        
        // 兼容一下本地 H5 的测试逻辑
        if (localStorage.getItem(unlockKey)) return true;
        
        // 另外，AppState里可能有后端返回的解锁状态
        if (productType === 'script' || productType === 'tool_package') {
            return AppState.hasToolPackage || AppState.hasScriptPackage;
        }
        if (productType === 'topic') {
            return AppState.hasTopicPackage;
        }
        
    } catch(e) {}
    return false;
};

// 拦截知识库点击
var old_toggleKnowledge = window.toggleKnowledge;
window.toggleKnowledge = function(id) {
    if (!checkLogin(true)) return;
    var contentEl = document.getElementById('knowledge-content-' + id);
    if (!contentEl) return;
    
    // 如果还没解锁，跳转去广告页
    if (!checkAdUnlocked('knowledge') && !checkAdUnlocked('tool_package')) {
        showPaymentModal('knowledge', 0);
        return;
    }
    
    var iconEl = document.getElementById('knowledge-icon-' + id);
    if (contentEl.style.display === 'none' || contentEl.style.display === '') {
        contentEl.style.display = 'block';
        if (iconEl) iconEl.textContent = '▼';
    } else {
        contentEl.style.display = 'none';
        if (iconEl) iconEl.textContent = '▶';
    }
};

// 拦截话题点击
var old_showTopicDetail = window.showTopicDetail;
window.showTopicDetail = function(topicId) {
    if (!checkLogin(true)) return;
    var freeTopics = AppState.freeTopicIds || ['n1', '2n', 'pip', 'sign'];
    var isFree = freeTopics.indexOf(topicId) > -1;
    
    if (!isFree && !checkAdUnlocked('topic')) {
        showPaymentModal('topic', 0);
        return;
    }
    old_showTopicDetail(topicId);
};

// 拦截话术库点击
var old_showScriptDetail = window.showScriptDetail;
window.showScriptDetail = function(scriptId) {
    if (!checkLogin(true)) return;
    
    if (!checkAdUnlocked('script')) {
        showPaymentModal('script', 0);
        return;
    }
    old_showScriptDetail(scriptId);
};
"""

content += new_unlock_check
print("Added Ad unlock checkers")

# 更新缓存号
index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()
html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_ADS_FINAL', html_content)
with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)
