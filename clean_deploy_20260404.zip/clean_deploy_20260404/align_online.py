import re
import os
import shutil

deploy_dir = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404'
app_js_path = os.path.join(deploy_dir, 'app.js')
app_online_path = os.path.join(deploy_dir, 'app_online.js')
index_html_path = os.path.join(deploy_dir, 'index.html')
index_online_path = os.path.join(deploy_dir, 'index_online.html')

# Replace app.js with app_online.js
shutil.copy2(app_online_path, app_js_path)
print("Replaced app.js with app_online.js")

# Replace index.html with index_online.html
shutil.copy2(index_online_path, index_html_path)
print("Replaced index.html with index_online.html")

# Bump version in index.html
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()

html_content = re.sub(r'app\.js(\?v=[a-zA-Z0-9_]+)?', 'app.js?v=20260404_ALIGN_ONLINE', html_content)

with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print("Updated index.html version.")

# We also need to make sure server.py points to app.js
server_py_path = os.path.join(deploy_dir, 'server.py')
with open(server_py_path, 'r', encoding='utf-8') as f:
    server_content = f.read()

server_content = server_content.replace("['app.js', 'app_v2.js', 'styles.css', 'index.html']", "['app.js', 'styles.css', 'index.html']")

with open(server_py_path, 'w', encoding='utf-8') as f:
    f.write(server_content)

print("Alignment complete.")
