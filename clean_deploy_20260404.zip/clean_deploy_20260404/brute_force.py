import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 强制重写所有渲染和点击逻辑（不依赖复杂的正则前瞻）

# 1. 移除 renderTopicPage 和 fetchTopicList，直接用新逻辑替换
content = re.sub(r"function renderTopicPage\(filterCategory\) \{[\s\S]*?\}\n\n", "", content)
content = re.sub(r"function fetchTopicList\(category\) \{[\s\S]*?\}\n\n", "", content)

new_topic_render = """
function renderTopicPage(filterCategory) {
    var container = document.getElementById('topic-list-container');
    var paywall = document.getElementById('topic-paywall');
    if (!container) return;

    if (paywall) paywall.style.display = 'none';

    var filteredData = TopicData;
    if (filterCategory && filterCategory !== '全部') {
        filteredData = TopicData.filter(function(item) {
            return item.category === filterCategory;
        });
    }

    var html = '';
    filteredData.forEach(function(item) {
        html += '<div class="topic-item" onclick="showTopicDetail(\\'' + item.id + '\\')">' +
            '<div class="topic-icon">💡</div>' +
            '<div class="topic-info">' +
            '<h3>' + item.title + '</h3>' +
            '<p>' + item.desc + '</p>' +
            '</div>' +
            '</div>';
    });

    container.innerHTML = html;
}
"""
content += new_topic_render

# 2. 重写 renderScriptPage
content = re.sub(r"function renderScriptPage\(\) \{[\s\S]*?\}\n\n", "", content)
new_script_render = """
function renderScriptPage() {
    var container = document.getElementById('script-library-content');
    if (!container) return;

    var html = '';
    ScriptData.forEach(function(item) {
        html += '<div class="topic-item" onclick="showScriptDetail(' + item.id + ')">' +
            '<div class="topic-icon">💬</div>' +
            '<div class="topic-info">' +
            '<h3>' + item.title + '</h3>' +
            '<p>' + item.desc + '</p>' +
            '</div>' +
            '</div>';
    });

    container.innerHTML = html;
}
"""
content += new_script_render

# 3. 解决 H5 引导页闪现问题
# 之前的 document.getElementById 可能在 DOMContentLoaded 触发时元素还没准备好
old_hide = """    // 由于外部小程序已经有精美的引导页了，这里 H5 一加载就直接隐藏自己的简陋引导页
    var splashScreen = document.getElementById('splash-screen');
    var mainContent = document.getElementById('main-content');
    if (splashScreen) splashScreen.style.display = 'none';
    if (mainContent) {
        mainContent.classList.remove('hidden');
        mainContent.style.display = 'block';
    }"""

new_hide = """    // 强行用定时器和 CSS 类双重隐藏 H5 引导页，确保它绝对不会出现
    var hideSplash = function() {
        var splashScreen = document.getElementById('splash-screen');
        var mainContent = document.getElementById('main-content');
        if (splashScreen) splashScreen.style.display = 'none';
        if (mainContent) {
            mainContent.classList.remove('hidden');
            mainContent.style.display = 'block';
        }
    };
    hideSplash();
    setTimeout(hideSplash, 100);
    setTimeout(hideSplash, 500);"""

content = content.replace(old_hide, new_hide)

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)

# 4. 从 HTML 层面上彻底干掉 H5 引导页的显示
index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()

html_content = html_content.replace('<div id="splash-screen" class="splash-screen">', '<div id="splash-screen" class="splash-screen" style="display:none !important;">')
html_content = html_content.replace('<main id="main-content" class="hidden">', '<main id="main-content" style="display:block !important;">')
html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_TRUE_FEATURES_2', html_content)

with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print("Absolute brute-force fix applied.")
