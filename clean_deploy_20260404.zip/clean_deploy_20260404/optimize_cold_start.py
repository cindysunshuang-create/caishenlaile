import re
import os

index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'

with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()

# 强行给 H5 引导页加上 style="display:none !important;"，从而从物理层面抹除它，彻底解决冷启动闪现带来的延迟感
if 'id="splash-screen" class="splash-screen" style="z-index: 9999;"' in html_content:
    html_content = html_content.replace('id="splash-screen" class="splash-screen" style="z-index: 9999;"', 'id="splash-screen" class="splash-screen" style="display:none !important;"')
elif 'id="splash-screen" class="splash-screen"' in html_content:
    html_content = html_content.replace('id="splash-screen" class="splash-screen"', 'id="splash-screen" class="splash-screen" style="display:none !important;"')

# 同时确保 main-content 直接显示，无需等待 JS 控制
if 'id="main-content" class="hidden"' in html_content:
    html_content = html_content.replace('id="main-content" class="hidden"', 'id="main-content" style="display:block !important;"')

html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_NO_SPLASH_FAST', html_content)

with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print("index.html fully optimized for cold start.")
