import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 1. 修复 renderTopicPreview (不再显示锁，直接用本地 TopicData)
old_topic_preview = re.search(r"function renderTopicPreview\(filterCategory\) \{.*?(?=function renderKnowledgePreview\(\) \{)", content, re.DOTALL)
if old_topic_preview:
    new_topic_preview = """function renderTopicPreview(filterCategory) {
    var container = document.querySelector('.topics-section .topics-list');
    if (!container) return;

    var html = '';
    var filteredData = TopicData;

    // 如果有筛选分类，则过滤数据
    if (filterCategory && filterCategory !== '全部') {
        filteredData = TopicData.filter(function(item) {
            return item.category === filterCategory;
        });
    }

    var previewData = filteredData.slice(0, 4);

    previewData.forEach(function(item) {
        // 直接使用本地 TopicData 的真实数据，不再根据付费状态显示假锁
        html += '<div class="topic-item" onclick="showTopicDetail(\\'' + item.id + '\\')">' +
            '<div class="topic-icon">💡</div>' +
            '<div class="topic-info">' +
            '<h3>' + item.title + '</h3>' +
            '<p>' + item.desc + '</p>' +
            '</div>' +
            '</div>';
    });

    container.innerHTML = html;
}

"""
    content = content.replace(old_topic_preview.group(0), new_topic_preview)
    print("Patched renderTopicPreview")

# 2. 修复 showTopicDetail (弹窗直接拉起本地详细数据)
old_topic_detail = re.search(r"window\.showTopicDetail = function\(topicId\) \{.*?(?=window\.showTopicPayModal = function\(\) \{)", content, re.DOTALL)
if old_topic_detail:
    new_topic_detail = """window.showTopicDetail = function(topicId) {
    if (!checkLogin(true)) return;

    AppState.currentTopicId = topicId;
    // 不再校验付费状态，如果需要看广告解锁，由专门的广告系统拦截。这里假设直接展示（如果未解锁，后端拦截，但当前采用全前端展示+部分解锁机制）
    var topic = TopicData.find(function(t) { return t.id === topicId; });
    if (!topic) {
        showToast('获取话题详情失败');
        return;
    }

    var modal = document.getElementById('topic-detail-modal');
    var detailTitle = document.getElementById('topic-detail-title');
    var detailBody = document.querySelector('.topic-detail-body');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
        if (detailTitle) {
            detailTitle.textContent = topic.title;
        }
        if (detailBody) {
            var html = '<div class="topic-content-box">' +
                '<h4>' + topic.desc + '</h4>' +
                '<div class="topic-text">' + topic.content + '</div>' +
                '</div>';
            
            if (topic.cases && topic.cases.length > 0) {
                html += '<h4 style="margin-top:20px;margin-bottom:12px;color:#fff;">真实案例参考</h4>';
                topic.cases.forEach(function(c) {
                    html += '<div class="case-card">' +
                        '<div class="case-platform">' + c.platform + '</div>' +
                        '<div class="case-summary">' + c.summary + '</div>' +
                        '<div class="case-result">结果：' + c.result + '</div>' +
                        '</div>';
                });
            }
            detailBody.innerHTML = html;
        }
    }
};

"""
    content = content.replace(old_topic_detail.group(0), new_topic_detail)
    print("Patched showTopicDetail")

# 3. 修复知识库点击 (不再弹出收费墙，直接展开)
old_knowledge = re.search(r"window\.toggleKnowledge = function\(id\) \{.*?(?=window\.openEvidenceGuide = function\(\) \{)", content, re.DOTALL)
if old_knowledge:
    new_knowledge = """window.toggleKnowledge = function(id) {
    if (!checkLogin(true)) return;
    
    var contentEl = document.getElementById('knowledge-content-' + id);
    var iconEl = document.getElementById('knowledge-icon-' + id);
    
    if (contentEl) {
        if (contentEl.style.display === 'none' || contentEl.style.display === '') {
            contentEl.style.display = 'block';
            if (iconEl) iconEl.textContent = '▼';
        } else {
            contentEl.style.display = 'none';
            if (iconEl) iconEl.textContent = '▶';
        }
    }
};

"""
    content = content.replace(old_knowledge.group(0), new_knowledge)
    print("Patched toggleKnowledge")

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)

# Update index.html version cache
index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()

html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_FEATURES', html_content)

with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print("Features patch completed successfully!")
