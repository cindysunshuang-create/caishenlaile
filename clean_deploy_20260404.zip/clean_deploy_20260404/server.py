#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
裁神来了 - 后端服务
提供AI对话和微信支付功能
部署环境：微信云托管 (Flask)
"""

import os
import json
import sqlite3
import hashlib
import hmac
import time
from datetime import datetime, timedelta
import random
import string
import uuid
import base64
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import requests
import logging
import urllib3

# 禁用SSL警告（云托管环境需要）
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'caisheen_laile_secret_key_' + str(random.randint(1000, 9999)))

# 解决微信云托管INVALID_HOST错误
# 设置允许任何host
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.config['DEFAULT_DOMAIN'] = None  # 允许任何域名

# 使用werkzeug ProxyFix来处理代理
try:
    from werkzeug.middleware.proxy_fix import ProxyFix
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)
except ImportError:
    pass

# 启用CORS - 允许所有来源
CORS(app, supports_credentials=True, resources={r"/*": {"origins": "*"}})

# 允许所有Host头 - 解决微信云托管INVALID_HOST错误
app.config['TRUSTED_HOSTS'] = ['*']

# 强制Flask接受所有Host头
class HostValidationFix:
    """强制Flask接受任意Host头的WSGI中间件"""
    def __init__(self, app):
        self.app = app

    def __call__(self, environ, start_response):
        # 强制设置正确的Host头
        host = environ.get('HTTP_HOST', '')
        if host:
            # 如果有X-Forwarded-Host，使用它
            forwarded_host = environ.get('HTTP_X_FORWARDED_HOST')
            if forwarded_host:
                environ['HTTP_HOST'] = forwarded_host.split(',')[0].strip()

        # 绕过Flask的host验证
        environ['HTTP_HOST'] = environ.get('HTTP_HOST', 'localhost')
        return self.app(environ, start_response)

# 应用中间件
app.wsgi_app = HostValidationFix(app.wsgi_app)

# 显式设置响应头，允许所有域名访问
@app.after_request
def add_cors_headers(response):
    # 允许所有来源
    response.headers['Access-Control-Allow-Origin'] = '*'
    # 允许所有请求头
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With, X-Forwarded-For, X-Real-IP, Host'
    # 允许所有方法
    response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
    # 允许携带凭证
    response.headers['Access-Control-Allow-Credentials'] = 'true'
    return response

# 处理云托管自定义域名问题 - 允许所有Host
@app.before_request
def handle_options():
    if request.method == 'OPTIONS':
        response = app.make_response('')
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With'
        return response

# ==================== 配置 ====================

# AI API配置
API_KEY = os.environ.get('API_KEY', '')
API_BASE_URL = os.environ.get('API_BASE_URL', 'https://api.openai.com/v1')

# 微信支付配置
# 测试模式：通过环境变量控制，默认False
TEST_MODE = os.environ.get('WECHAT_TEST_MODE', 'false').lower() == 'true'

WECHAT_PAY_CONFIG = {
    'appid': os.environ.get('WECHAT_APPID', 'wx466f15c87c417cb8'),
    # 小程序原始ID（用于JSAPI支付）- 格式：http://servicewechat.com/wxappid/
    'mini_appid': os.environ.get('WECHAT_MINI_APPID', 'wx466f15c87c417cb8'),
    'app_secret': os.environ.get('WECHAT_APP_SECRET', '1527de3f55a24aba316e84e0434dc9fc'),
    'mch_id': os.environ.get('WECHAT_MCH_ID', ''),
    'api_key': os.environ.get('WECHAT_API_KEY', ''),
    'api_key_v2': os.environ.get('WECHAT_API_KEY_V2', ''),
    # 沙箱环境API密钥（需要在微信商户平台沙箱设置）
    'sandbox_api_key': os.environ.get('WECHAT_SANDBOX_API_KEY', ''),
    'private_key_path': os.environ.get('WECHAT_PRIVATE_KEY_PATH', '/path/to/apiclient_key.pem'),
    'certificate_path': os.environ.get('WECHAT_CERTIFICATE_PATH', '/path/to/apiclient_cert.pem'),
    'notify_url': os.environ.get('WECHAT_NOTIFY_URL', 'https://www.caishenlaile88.com/api/payment/notify'),
    # 根据环境选择不同的API地址
    'api_base_url': 'https://api.mch.weixin.qq.com/sandboxnew' if TEST_MODE else 'https://api.mch.weixin.qq.com',
    'sandbox_sign_url': 'https://api.mch.weixin.qq.com/sandboxnew/pay/getsignkey'
}

# 自动检测是否在本地运行
IS_LOCAL = os.environ.get('PORT', '') == '8081' or os.path.exists('.local_dev')

if IS_LOCAL:
    logger.info("检测到本地开发环境")
    # 本地开发环境可以使用localhost
    pass

logger.info(f"微信支付模式: {'沙箱测试' if TEST_MODE else '生产环境'}")
logger.info(f"API基础地址: {WECHAT_PAY_CONFIG['api_base_url']}")

# 沙箱密钥缓存
_sandbox_signkey = None


def get_sandbox_signkey():
    """
    获取沙箱API密钥
    根据方案一：通过API调用获取沙箱密钥
    """
    global _sandbox_signkey

    # 如果已经获取过，直接返回缓存
    if _sandbox_signkey:
        logger.info("使用缓存的沙箱signkey")
        return _sandbox_signkey

    logger.info(f"TEST_MODE = {TEST_MODE}")

    if not TEST_MODE:
        logger.info("非测试模式，不获取沙箱密钥")
        return None

    # 调用沙箱获取密钥API
    url = WECHAT_PAY_CONFIG['sandbox_sign_url']
    nonce_str = generate_nonce_str()
    mch_id = WECHAT_PAY_CONFIG['mch_id']
    api_key = WECHAT_PAY_CONFIG['api_key']

    logger.info(f"获取沙箱signkey: mch_id={mch_id}, url={url}")

    params = {
        'mch_id': mch_id,
        'nonce_str': nonce_str
    }

    # 使用正式API密钥进行签名
    params['sign'] = generate_wechat_sign(params, api_key)

    # 转换为XML
    xml_data = dict_to_xml(params)

    logger.info(f"请求XML: {xml_data}")

    try:
        response = requests.post(url, data=xml_data.encode('utf-8'), headers={'Content-Type': 'application/xml'}, timeout=10, verify=False)
        logger.info(f"沙箱API响应状态码: {response.status_code}")
        logger.info(f"沙箱API响应内容: {response.text[:500]}")

        result = xml_to_dict(response.text)

        logger.info(f"沙箱signkey返回: {result}")

        if result.get('return_code') == 'SUCCESS' and result.get('result_code') == 'SUCCESS':
            _sandbox_signkey = result.get('sandbox_signkey')
            logger.info(f"成功获取沙箱signkey: {_sandbox_signkey[:10]}...")
            return _sandbox_signkey
        else:
            error_msg = result.get('return_msg') or result.get('err_code_des', '获取沙箱密钥失败')
            logger.error(f"获取沙箱密钥失败: {error_msg}, result={result}")
            # 如果获取失败，使用配置中的密钥作为后备
            return WECHAT_PAY_CONFIG.get('sandbox_api_key', api_key)
    except Exception as e:
        logger.error(f"获取沙箱密钥异常: {str(e)}")
        # 如果异常，使用配置中的密钥作为后备
        return WECHAT_PAY_CONFIG.get('sandbox_api_key', api_key)


def get_active_api_key():
    """
    获取当前使用的API密钥
    沙箱模式下动态获取，生产模式下使用正式密钥
    """
    if TEST_MODE:
        sandbox_key = get_sandbox_signkey()
        if sandbox_key:
            return sandbox_key
        # 如果获取沙箱密钥失败，尝试使用正式密钥
        logger.warning("沙箱密钥获取失败，尝试使用正式密钥")
        return WECHAT_PAY_CONFIG['api_key']
    else:
        return WECHAT_PAY_CONFIG['api_key']


def get_api_base_url():
    """
    获取API基础URL
    如果沙箱失败，回退到生产环境
    """
    # 如果是测试模式且沙箱密钥获取失败，使用生产环境
    if TEST_MODE:
        sandbox_key = get_sandbox_signkey()
        if sandbox_key:
            return 'https://api.mch.weixin.qq.com/sandboxnew'
        else:
            # 沙箱失败，使用生产环境
            logger.warning("沙箱环境不可用，切换到生产环境")
            return 'https://api.mch.weixin.qq.com'
    return 'https://api.mch.weixin.qq.com'

# 产品价格配置（单位：分）
PRODUCTS = {
    'diagnosis_report': {'name': 'AI诊断报告', 'price': 990, 'description': '包含赔偿计算、风险评估、证据清单、谈判话术'},
    'tool_package': {'name': '职场维权工具包', 'price': 490, 'description': '话术库+完整集'},
    'topic_package': {'name': '热门话题完整版', 'price': 490, 'description': '解锁全部热门话题'}
}
FREE_TOPIC_IDS = ['n1', '2n', 'pip', 'sign']
TOPIC_DATA = [
    {'id': 'n1', 'category': '赔偿', 'title': 'N和N+1的区别', 'desc': '经济补偿金与代通知金', 'content': 'N是指经济补偿金，按劳动者在本单位工作的年限，每满一年支付一个月工资。<br><br>N+1是指经济补偿金+代通知金，公司未提前30天通知需额外支付一个月工资。<br><br><strong>2024年新变化：</strong>部分地区对高工资员工有3倍社平工资封顶限制。', 'cases': [{'platform': '脉脉', 'summary': '入职3年，被公司以"组织架构优化"裁员，HR最初只肯给N，沟通后拿到N+1', 'result': 'N+1'}, {'platform': '小红书', 'summary': '工作5年，月薪2万，公司口头通知裁员，最终仲裁拿到2N赔偿40万', 'result': '2N 40万'}]},
    {'id': '2n', 'category': '赔偿', 'title': '2N赔偿金条件', 'desc': '违法解除劳动合同的赔偿', 'content': '2N是赔偿金，适用于违法解除劳动合同的情况，金额是经济补偿金的2倍。<br><br><strong>常见违法解除情形：</strong><br>• 没有任何正当理由解除合同<br>• 未提前30天书面通知<br>• 以"不能胜任"为由但无证据<br>• 孕期、产期、哺乳期女职工<br><br><strong>维权建议：</strong>先协商，协商不成可申请劳动仲裁。', 'cases': [{'platform': '知乎', 'summary': '孕期被公司以"绩效不合格"辞退，仲裁成功拿到2N赔偿', 'result': '2N'}, {'platform': '脉脉', 'summary': '无任何理由被裁员，公司无法举证合法性，最终判赔2N', 'result': '2N'}]},
    {'id': 'pip', 'category': '谈判', 'title': 'PIP绩效改进计划', 'desc': '如何应对绩效改进计划', 'content': 'PIP是绩效改进计划，常被用作变相裁员的手段。<br><br><strong>应对方法：</strong><br>• 要求明确具体的绩效标准<br>• 保留所有沟通记录<br>• 拒绝签署不合理的PIP文件<br>• 必要时可拒绝签字并书面说明理由<br><br><strong>重要：</strong>PIP本身不违法，但以此为由裁员需要提供充分证据。', 'cases': [{'platform': '小红书', 'summary': '入职8个月突遭PIP，拒绝签字后公司以"不符合录用条件"辞退，最终仲裁败诉', 'result': 'N/A 败诉'}, {'platform': '脉脉', 'summary': '被PIP后收集证据证明考核标准不合理，谈判成功拿到N+1.5', 'result': 'N+1.5'}]},
    {'id': 'sign', 'category': '合同', 'title': '试用期转正陷阱', 'desc': '试用期违规解除的识别', 'content': '试用期被裁员同样有赔偿！<br><br>• 工作不满6个月，按0.5个月工资计算N<br>• 违法解除同样可以主张2N<br><br><strong>注意：</strong>不要签署"不符合录用条件"的评估表，这可能成为公司合法解除的依据。', 'cases': [{'platform': '脉脉', 'summary': '试用期第5个月被以"不符合录用条件"辞退，未签评估表，仲裁拿回1个月工资', 'result': '1个月工资'}, {'platform': '小红书', 'summary': '应届生试用期被裁，HR威胁不签自愿离职就写差评，最终坚持仲裁拿到N+1', 'result': 'N+1'}]},
    {'id': 'contract1', 'category': '合同', 'title': '这些字千万别签', 'desc': '离职协议的自愿离职申请', 'content': '签字前务必谨慎，以下文件不要轻易签字：<br><br>❌ <strong>《离职协议》</strong> - 确认补偿金额是否合理<br><br>❌ <strong>《自愿离职申请》</strong> - 签了等于自愿，没有赔偿<br><br>❌ <strong>《绩效考核确认书》</strong> - 可能成为"不能胜任"的证据<br><br>❌ <strong>《竞业限制协议》</strong> - 可能影响后续就业', 'cases': [{'platform': '知乎', 'summary': '签署《自愿离职申请》后后悔，因无法证明胁迫，仲裁败诉', 'result': '0 败诉'}, {'platform': '脉脉', 'summary': '拒签《离职协议》后公司妥协，最终拿到N+2', 'result': 'N+2'}]},
    {'id': 'process1', 'category': '流程', 'title': '劳动仲裁流程', 'desc': '申请仲裁的全流程指引', 'content': '劳动仲裁流程：<br><br>1. 提交仲裁申请<br>2. 仲裁委5日内决定是否受理<br>3. 开庭审理<br>4. 调解（如有）<br>5. 裁决<br><br><strong>注意：</strong>劳动仲裁免费，一般45天内结案。不服裁决可在15日内向法院起诉。', 'cases': [{'platform': '知乎', 'summary': '全程自己打仲裁，提交12项证据，最终胜诉拿到18万赔偿', 'result': '胜诉 18万'}, {'platform': '小红书', 'summary': '仲裁到执行用了6个月，公司已无财产可执行，提醒大家早行动', 'result': '执行难'}]},
    {'id': 'overtime', 'category': '赔偿', 'title': '加班费怎么算？', 'desc': '加班工资计算标准', 'content': '加班费计算标准：<br><br>• 工作日加班：1.5倍工资<br>• 休息日加班：2倍工资（可安排补休）<br>• 法定节假日加班：3倍工资<br><br><strong>2024年新规：</strong>加班费计入社保缴费基数，节假日加班需支付300%工资且不能以调休替代。', 'cases': [{'platform': '脉脉', 'summary': '保留3年加班记录，仲裁成功追回加班费12万', 'result': '12万'}, {'platform': '小红书', 'summary': '只有口头要求加班无证据，仲裁败诉，提醒大家注意留痕', 'result': '0 败诉'}]},
    {'id': 'social', 'category': '赔偿', 'title': '社保断缴怎么办？', 'desc': '社保公积金维权', 'content': '公司未足额缴纳社保公积金，可以：<br><br>1. <strong>向社保局投诉</strong> - 要求公司补缴<br>2. <strong>申请劳动仲裁</strong> - 通过仲裁追缴<br><br><strong>注意：</strong>• 补缴不受1年时效限制<br>• 需要提供劳动关系证明<br>• 个人部分也需要补缴<br><br><strong>建议：</strong>先协商，协商不成再投诉。', 'cases': [{'platform': '脉脉', 'summary': '投诉后公司补缴3年社保，个人部分自己出了2万', 'result': '补缴成功'}, {'platform': '小红书', 'summary': '仲裁追缴公积金，成功补缴6万', 'result': '6万'}]}
]

# 数据存储
user_sessions = {}
diagnosis_reports = {}
orders = {}
reward_unlocks = {}
REWARD_UNLOCK_DB_PATH = os.environ.get(
    'REWARD_UNLOCK_DB_PATH',
    os.path.join(os.path.dirname(os.path.abspath(__file__)), 'reward_unlocks.sqlite3')
)
REWARD_AD_UNIT_ID = os.environ.get('REWARDED_VIDEO_AD_UNIT_ID', 'adunit-c4492dd7a33354a0')
VALID_REWARD_PRODUCTS = {
    'diagnosis_report',
    'tool_package',
    'topic_package',
    'knowledge',
    'evidence'
}


# ==================== 辅助函数 ====================

def generate_order_id():
    timestamp = str(int(time.time()))
    random_str = ''.join(random.choices(string.ascii_uppercase + string.digits, k=8))
    return f"C{timestamp}{random_str}"

def generate_nonce_str():
    return ''.join(random.choices(string.ascii_lowercase + string.digits, k=32))

def normalize_user_id(raw):
    if not raw:
        return ''
    return str(raw).strip()

def normalize_reward_product_id(product_id=''):
    product_id = normalize_user_id(product_id)
    if product_id == 'script':
        return 'tool_package'
    return product_id

def get_reward_unlock_conn():
    conn = sqlite3.connect(REWARD_UNLOCK_DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_reward_unlock_store():
    conn = get_reward_unlock_conn()
    try:
        conn.execute(
            '''
            CREATE TABLE IF NOT EXISTS reward_unlocks (
                product_id TEXT NOT NULL,
                user_id TEXT NOT NULL DEFAULT '',
                openid TEXT NOT NULL DEFAULT '',
                scene TEXT NOT NULL DEFAULT '',
                ad_unit_id TEXT NOT NULL DEFAULT '',
                unlocked_at TEXT NOT NULL,
                PRIMARY KEY (product_id, user_id, openid)
            )
            '''
        )
        conn.commit()
    finally:
        conn.close()

def build_unlock_key(product_id='', user_id='', openid=''):
    product_id = normalize_reward_product_id(product_id)
    user_id = normalize_user_id(user_id)
    openid = normalize_user_id(openid)
    if product_id and user_id:
        return f"{product_id}:user:{user_id}"
    if product_id and openid:
        return f"{product_id}:openid:{openid}"
    return ''

def save_reward_unlock(product_id='', user_id='', openid='', scene='', ad_unit_id=''):
    key = build_unlock_key(product_id, user_id, openid)
    if not key:
        return False
    product_id = normalize_reward_product_id(product_id)
    user_id = normalize_user_id(user_id)
    openid = normalize_user_id(openid)
    unlocked_at = time.strftime('%Y-%m-%d %H:%M:%S')
    reward_unlocks[key] = {
        'product_id': product_id,
        'user_id': user_id,
        'openid': openid,
        'scene': normalize_user_id(scene),
        'ad_unit_id': normalize_user_id(ad_unit_id),
        'unlocked_at': unlocked_at
    }
    conn = get_reward_unlock_conn()
    try:
        conn.execute(
            '''
            INSERT OR REPLACE INTO reward_unlocks (product_id, user_id, openid, scene, ad_unit_id, unlocked_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ''',
            (product_id, user_id, openid, normalize_user_id(scene), normalize_user_id(ad_unit_id), unlocked_at)
        )
        conn.commit()
    finally:
        conn.close()
    return True

def has_reward_unlock(product_id='', user_id='', openid=''):
    product_id = normalize_reward_product_id(product_id)
    if not product_id:
        return False
    user_key = build_unlock_key(product_id, user_id, '')
    openid_key = build_unlock_key(product_id, '', openid)
    if (user_key and user_key in reward_unlocks) or (openid_key and openid_key in reward_unlocks):
        return True
    conn = get_reward_unlock_conn()
    try:
        conditions = []
        params = [product_id]
        if normalize_user_id(user_id):
            conditions.append('user_id = ?')
            params.append(normalize_user_id(user_id))
        if normalize_user_id(openid):
            conditions.append('openid = ?')
            params.append(normalize_user_id(openid))
        if not conditions:
            return False
        row = conn.execute(
            f"SELECT product_id, user_id, openid, scene, ad_unit_id, unlocked_at FROM reward_unlocks WHERE product_id = ? AND ({' OR '.join(conditions)}) LIMIT 1",
            params
        ).fetchone()
        if not row:
            return False
        cached_key = build_unlock_key(row['product_id'], row['user_id'], row['openid'])
        if cached_key:
            reward_unlocks[cached_key] = dict(row)
        return True
    finally:
        conn.close()

def has_topic_unlock(user_id='', openid=''):
    if not user_id and not openid:
        return False
    if has_reward_unlock('topic_package', user_id, openid):
        return True
    for _, order in orders.items():
        if order.get('product_id') != 'topic_package':
            continue
        if order.get('status') != 'paid':
            continue
        order_user = order.get('user_id', '')
        order_openid = order.get('openid', '')
        if (user_id and order_user and str(user_id) == str(order_user)) or \
           (openid and order_openid and str(openid) == str(order_openid)):
            return True
    return False

init_reward_unlock_store()

def calculate_n_value(entry_date_str, leave_date_str):
    """
    根据《劳动合同法》第47条精确计算经济补偿金的N值
    规则：
    1. 每满一年支付一个月工资
    2. 六个月以上不满一年的，按一年计算
    3. 不满六个月的，向劳动者支付半个月工资的经济补偿
    """
    try:
        entry = datetime.strptime(entry_date_str, '%Y-%m-%d')
        leave = datetime.strptime(leave_date_str, '%Y-%m-%d')
    except Exception as e:
        logger.error(f"日期解析错误: {e}")
        return 0

    # 1. 计算整年数
    years = leave.year - entry.year
    
    # 调整整年数：如果离职日期的月日小于入职日期的月日，说明不满这一整年
    # 注意：这里需要仔细处理。比如入职 2020-01-01，离职 2021-01-01，应该是满1年。
    # 上面的减法 2021-2020 = 1。
    # 比较 (2021, 1, 1) 和 (2021, 1, 1)，相等，不需要减。
    # 如果离职 2020-12-31，比较 (2020, 12, 31) 和 (2020, 1, 1) -> 此时年份差是0，逻辑正确。
    # 如果入职 2020-05-01，离职 2021-04-30。年份差1。
    # 比较 (2021, 4, 30) 和 (2021, 5, 1)。前者小，years -= 1 -> years = 0。正确。
    
    # 构建当前年份的“入职纪念日”
    try:
        current_anniversary = entry.replace(year=leave.year)
    except ValueError:
        # 处理闰年2月29日入职的情况，非闰年对应2月28日
        current_anniversary = entry.replace(year=leave.year, month=2, day=28)
    
    if leave < current_anniversary:
        years -= 1
        # 上一周年的日期
        try:
            last_anniversary = entry.replace(year=leave.year - 1)
        except ValueError:
            last_anniversary = entry.replace(year=leave.year - 1, month=2, day=28)
    else:
        last_anniversary = current_anniversary

    # 2. 判断剩余时间
    # 剩余时间 = leave - last_anniversary
    # 判断是否超过6个月
    
    # 计算 last_anniversary + 6 months 的日期
    target_year = last_anniversary.year
    target_month = last_anniversary.month + 6
    if target_month > 12:
        target_year += 1
        target_month -= 12
        
    # 获取目标月份的最大天数，防止如 8.31 + 6个月 = 2.31 报错
    import calendar
    _, last_day = calendar.monthrange(target_year, target_month)
    target_day = min(last_anniversary.day, last_day)
    
    six_months_date = datetime(target_year, target_month, target_day)
    
    n_value = float(years)
    
    # 离职日期 >= 6个月界限 -> 加1个月
    # 否则，如果离职日期 > 上一周年 -> 加0.5个月
    # 如果离职日期 == 上一周年 -> 不加（正好满年）
    
    if leave >= six_months_date:
        n_value += 1.0
    elif leave > last_anniversary:
        n_value += 0.5
        
    return n_value

def calculate_years_to_months(years):
    """
    [已弃用，保留兼容性] 将年限转换为劳动法规定的补偿月数
    """
    full_years = int(years)
    months = round((years - full_years) * 12)
    total_months = full_years
    if months < 6:
        total_months += 0.5
    else:
        total_months += 1
    return total_months

def calculate_n_months_salary(salary, n_value):
    """
    计算N：经济补偿金
    每工作一年支付一个月工资
    """
    return int(salary * n_value)

def calculate_n_plus_1(salary, n_value):
    """
    计算N+1：经济补偿金 + 代通知金
    N + 1个月工资（公司未提前30天通知）
    """
    return int(salary * (n_value + 1))

def calculate_2n(salary, n_value):
    """
    计算2N：赔偿金（违法解除劳动合同）
    2倍的经济补偿金
    """
    return int(salary * n_value * 2)


# ==================== 微信支付签名函数 ====================

def generate_wechat_sign(params, api_key):
    """生成微信支付签名 (MD5)"""
    # 按参数名排序
    sorted_params = sorted(params.items(), key=lambda x: x[0])
    # 拼接成字符串
    sign_str = '&'.join([f"{k}={v}" for k, v in sorted_params if v])
    sign_str += f"&key={api_key}"
    # MD5加密并转大写
    sign = hashlib.md5(sign_str.encode('utf-8')).hexdigest().upper()
    return sign

def dict_to_xml(params):
    """字典转XML"""
    xml_parts = ['<xml>']
    for key, value in params.items():
        xml_parts.append(f'<{key}><![CDATA[{value}]]></{key}>')
    xml_parts.append('</xml>')
    return ''.join(xml_parts)

def xml_to_dict(xml_str):
    """XML转字典"""
    try:
        import xml.etree.ElementTree as ET
        root = ET.fromstring(xml_str)
        return {child.tag: child.text for child in root}
    except Exception as e:
        logger.error(f"XML解析失败: {e}, xml_str={xml_str[:500] if xml_str else 'empty'}")
        return {}

def create_unified_order(openid, product_name, out_trade_no, total_fee, client_ip, notify_url):
    """调用微信统一下单API"""
    # 使用动态API地址（沙箱失败时自动回退到生产环境）
    base_url = get_api_base_url()
    url = f"{base_url}/pay/unifiedorder"
    logger.info(f"使用API地址: {url}")

    # 使用动态获取的API密钥（沙箱模式会自动获取signkey）
    sign_key = get_active_api_key()
    logger.info(f"使用API密钥: {sign_key[:10] if sign_key else 'None'}...")

    # 构建请求参数
    params = {
        'appid': WECHAT_PAY_CONFIG['appid'],
        'mch_id': WECHAT_PAY_CONFIG['mch_id'],
        'nonce_str': generate_nonce_str(),
        'body': product_name[:128],  # 限制长度
        'out_trade_no': out_trade_no,
        'total_fee': total_fee,
        'spbill_create_ip': client_ip,
        'notify_url': notify_url,
        'trade_type': 'JSAPI',
        'openid': openid
    }

    # 生成签名
    params['sign'] = generate_wechat_sign(params, sign_key)

    # 转换为XML
    xml_data = dict_to_xml(params)

    logger.info(f"调用微信统一下单: url={url}, total_fee={total_fee}, openid={openid[:10]}...")

    try:
        # 发送请求（禁用SSL验证）
        response = requests.post(url, data=xml_data.encode('utf-8'), headers={'Content-Type': 'application/xml'}, timeout=10, verify=False)
        result = xml_to_dict(response.text)

        logger.info(f"微信统一下单返回: {result}")

        if result.get('return_code') == 'SUCCESS' and result.get('result_code') == 'SUCCESS':
            return {
                'success': True,
                'prepay_id': result.get('prepay_id'),
                'nonce_str': params['nonce_str']
            }
        else:
            error_msg = result.get('return_msg') or result.get('err_code_des', '下单失败')
            logger.error(f"微信统一下单失败: {error_msg}, result={result}")
            return {
                'success': False,
                'error': error_msg
            }
    except Exception as e:
        logger.error(f"调用微信统一下单API异常: {e}")
        return {'success': False, 'error': str(e)}


# ==================== H5页面路由 ====================

# 确定静态文件根目录
STATIC_DIRS = [
    '/app',  # Docker 容器目录优先
    os.path.dirname(os.path.abspath(__file__)),  # server.py 所在目录
    '.',  # 当前工作目录
]

def find_static_file(filename):
    """查找静态文件所在的目录"""
    for directory in STATIC_DIRS:
        file_path = os.path.join(directory, filename)
        if os.path.exists(file_path):
            logger.info(f"Found {filename} in {directory}")
            return directory
    logger.error(f"Could not find {filename} in any directory")
    return None

@app.route('/')
def index():
    """服务H5首页"""
    # 强制优先从 dist 目录读取 index.html
    dist_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dist')
    if os.path.exists(os.path.join(dist_dir, 'index.html')):
        logger.info(f"Serving index.html from {dist_dir}")
        response = send_from_directory(dist_dir, 'index.html')
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response

    static_dir = find_static_file('index.html')
    if static_dir:
        logger.info(f"Serving index.html from {static_dir}")
        response = send_from_directory(static_dir, 'index.html')
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response
    return "Index page not found", 404

# 上传图片访问路由
@app.route('/uploads/<filename>')
def serve_upload(filename):
    """服务上传的图片"""
    upload_dir = '/app/uploads'
    if not os.path.exists(upload_dir):
        upload_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
    return send_from_directory(upload_dir, filename)

# ==================== 微信支付API ====================

@app.route('/api/payment/create', methods=['POST'])
def create_payment():
    """创建支付订单"""
    try:
        data = request.get_json()
        product_id = data.get('productId', 'diagnosis_report')
        user_id = data.get('userId', 'anonymous')
        openid = data.get('openid', '')

        # 获取客户端IP
        client_ip = request.remote_addr
        if request.headers.get('X-Forwarded-For'):
            client_ip = request.headers.get('X-Forwarded-For').split(',')[0].strip()

        product = PRODUCTS.get(product_id, PRODUCTS['diagnosis_report'])
        order_id = generate_order_id()

        # 如果有openid，调用真实微信支付
        if openid:
            notify_url = WECHAT_PAY_CONFIG['notify_url']
            logger.info(f"创建支付订单: openid={openid[:10]}..., product={product_id}, test_mode={TEST_MODE}")

            result = create_unified_order(
                openid=openid,
                product_name=product['name'],
                out_trade_no=order_id,
                total_fee=product['price'],
                client_ip=client_ip,
                notify_url=notify_url
            )

            logger.info(f"统一下单结果: {result}")

            if result.get('success'):
                prepay_id = result['prepay_id']
                timestamp = str(int(time.time()))
                nonce_str = result['nonce_str']

                # 使用动态获取的API密钥进行二次签名
                sign_key = get_active_api_key()

                # 小程序JSAPI支付需要使用小程序原始ID
                # appId需要是公众号或小程序的原始ID格式
                mini_appid = WECHAT_PAY_CONFIG.get('mini_appid', WECHAT_PAY_CONFIG['appid'])
                logger.info(f"使用小程序appId: {mini_appid}")

                # 小程序调起支付需要二次签名
                pay_params = {
                    'appId': mini_appid,
                    'timeStamp': timestamp,
                    'nonceStr': nonce_str,
                    'package': f'prepay_id={prepay_id}',
                    'signType': 'MD5'
                }
                pay_sign = generate_wechat_sign(pay_params, sign_key)

                # 存储订单
                orders[order_id] = {
                    'order_id': order_id,
                    'product_id': product_id,
                    'user_id': user_id,
                    'openid': openid,
                    'amount': product['price'],
                    'status': 'pending',
                    'prepay_id': prepay_id,
                    'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                    'test_mode': TEST_MODE
                }

                return jsonify({
                    'success': True,
                    'order_id': order_id,
                    'amount': product['price'] / 100,
                    'timeStamp': timestamp,
                    'nonceStr': nonce_str,
                    'package': f'prepay_id={prepay_id}',
                    'signType': 'MD5',
                    'paySign': pay_sign,
                    'test_mode': TEST_MODE,
                    'note': '真实微信支付订单' if not TEST_MODE else '沙箱环境测试'
                })
            else:
                logger.error(f"微信统一下单失败: {result.get('error')}, result={result}")
                return jsonify({
                    'success': False,
                    'error': f'微信支付下单失败: {result.get("error")}',
                    'detail': result,
                    'test_mode': TEST_MODE,
                    'api_url': get_api_base_url()
                }), 500
        else:
            # 没有openid，使用模拟支付（用于测试）
            orders[order_id] = {
                'order_id': order_id,
                'product_id': product_id,
                'user_id': user_id,
                'amount': product['price'],
                'status': 'pending',
                'created_at': time.strftime('%Y-%m-%d %H:%M:%S')
            }

            return jsonify({
                'success': True,
                'order_id': order_id,
                'amount': product['price'] / 100,
                'timeStamp': str(int(time.time())),
                'nonceStr': generate_nonce_str(),
                'mock': True,
                'note': '模拟支付，请传入openid进行真实支付测试'
            })

    except Exception as e:
        logger.error(f"创建订单失败: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/payment/notify', methods=['POST'])
def payment_notify():
    """微信支付回调 - 云托管版本"""
    try:
        xml_data = request.data
        logger.info(f"收到支付回调: {xml_data}")

        # 解析XML
        params = xml_to_dict(xml_data.decode('utf-8'))

        # 验证签名 - 使用动态API密钥
        out_trade_no = params.get('out_trade_no')
        order_info = orders.get(out_trade_no, {})
        is_test_mode = order_info.get('test_mode', TEST_MODE)

        # 使用动态获取的API密钥
        sign_key = get_active_api_key()

        # 验证签名
        received_sign = params.get('sign', '')
        params_to_sign = {k: v for k, v in params.items() if k != 'sign'}
        calculated_sign = generate_wechat_sign(params_to_sign, sign_key)

        if calculated_sign != received_sign:
            logger.error(f"签名验证失败: 收到的签名={received_sign}, 计算的签名={calculated_sign}")
            return jsonify({'errcode': 1, 'errmsg': '签名验证失败'})

        # 检查返回码
        if params.get('return_code') != 'SUCCESS':
            return jsonify({'errcode': 1, 'errmsg': '返回码失败'})

        # 检查业务结果
        if params.get('result_code') == 'SUCCESS':
            transaction_id = params.get('transaction_id')

            # 更新订单状态
            if out_trade_no in orders:
                orders[out_trade_no]['status'] = 'paid'
                orders[out_trade_no]['paid_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
                orders[out_trade_no]['transaction_id'] = transaction_id
                logger.info(f"订单 {out_trade_no} 支付成功")

        # 云托管版本必须返回JSON格式
        return jsonify({'errcode': 0, 'errmsg': 'OK'})

    except Exception as e:
        logger.error(f"支付回调处理失败: {str(e)}")
        return jsonify({'errcode': 1, 'errmsg': str(e)})


@app.route('/api/payment/query/<order_id>', methods=['GET'])
def query_payment(order_id):
    """查询支付状态"""
    order = orders.get(order_id)
    if not order:
        return jsonify({'success': False, 'error': '订单不存在'}), 404
    return jsonify({
        'success': True,
        'order_id': order_id,
        'status': order['status'],
        'amount': order['amount'] / 100
    })

@app.route('/api/reward/unlock', methods=['POST'])
def reward_unlock():
    """记录激励广告解锁状态"""
    try:
        data = request.get_json() or {}
        product_id = normalize_reward_product_id(data.get('productId', ''))
        user_id = data.get('userId', '')
        openid = data.get('openid', '')
        scene = normalize_user_id(data.get('scene', ''))
        ad_unit_id = normalize_user_id(data.get('adUnitId', ''))
        if product_id not in VALID_REWARD_PRODUCTS:
            return jsonify({'success': False, 'error': '不支持的解锁类型'}), 400
        if scene and scene != 'mini_program_rewarded_video':
            return jsonify({'success': False, 'error': '非法解锁场景'}), 400
        if ad_unit_id and ad_unit_id != REWARD_AD_UNIT_ID:
            return jsonify({'success': False, 'error': '广告位不匹配'}), 400
        saved = save_reward_unlock(product_id, user_id, openid, scene, ad_unit_id)
        if not saved:
            return jsonify({'success': False, 'error': '缺少用户标识'}), 400
        return jsonify({'success': True, 'productId': product_id})
    except Exception as e:
        logger.error(f"记录激励广告解锁失败: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/topics', methods=['GET'])
def get_topics():
    user_id = request.args.get('userId', '')
    openid = request.args.get('openid', '')
    category = request.args.get('category', '全部')
    ad_unlocked = request.args.get('adUnlocked') == '1'
    unlocked = ad_unlocked or has_topic_unlock(user_id, openid)
    topics = TOPIC_DATA
    if category and category != '全部':
        topics = [t for t in TOPIC_DATA if t.get('category') == category]
    if not unlocked:
        topics = topics[:4]
    topic_list = [{'id': t['id'], 'category': t['category'], 'title': t['title'], 'desc': t['desc']} for t in topics]
    return jsonify({
        'success': True,
        'hasTopicPackage': unlocked,
        'freeTopicIds': FREE_TOPIC_IDS,
        'topics': topic_list,
        'total': len(TOPIC_DATA)
    })

@app.route('/api/topics/<topic_id>', methods=['GET'])
def get_topic_detail(topic_id):
    user_id = request.args.get('userId', '')
    openid = request.args.get('openid', '')
    ad_unlocked = request.args.get('adUnlocked') == '1'
    unlocked = ad_unlocked or has_topic_unlock(user_id, openid)
    topic = next((t for t in TOPIC_DATA if t.get('id') == topic_id), None)
    if not topic:
        return jsonify({'success': False, 'error': '话题不存在'}), 404
    if not unlocked and topic_id not in FREE_TOPIC_IDS:
        return jsonify({'success': False, 'needUnlock': True, 'error': '请先解锁热门话题'}), 403
    return jsonify({'success': True, 'hasTopicPackage': unlocked, 'topic': topic})


def query_wechat_order(order_id):
    """主动向微信查询订单状态"""
    try:
        url = f"{get_api_base_url()}/pay/orderquery"
        mch_id = WECHAT_PAY_CONFIG['mch_id']
        appid = WECHAT_PAY_CONFIG['appid']
        api_key = get_active_api_key()
        
        params = {
            'appid': appid,
            'mch_id': mch_id,
            'out_trade_no': order_id,
            'nonce_str': generate_nonce_str()
        }
        
        # 签名
        params['sign'] = generate_wechat_sign(params, api_key)
        
        # 转XML并请求
        xml_data = dict_to_xml(params)
        logger.info(f"主动查询微信订单: order_id={order_id}")
        
        response = requests.post(url, data=xml_data.encode('utf-8'), headers={'Content-Type': 'application/xml'}, timeout=10, verify=False)
        result = xml_to_dict(response.text)
        
        logger.info(f"微信查询结果: {result}")
        
        if result.get('return_code') == 'SUCCESS' and result.get('result_code') == 'SUCCESS':
            trade_state = result.get('trade_state')
            if trade_state == 'SUCCESS':
                return {
                    'success': True,
                    'status': 'paid',
                    'transaction_id': result.get('transaction_id'),
                    'total_fee': result.get('total_fee')
                }
            elif trade_state in ['NOTPAY', 'USERPAYING']:
                return {'success': True, 'status': 'pending'}
            elif trade_state in ['CLOSED', 'REVOKED', 'PAYERROR']:
                return {'success': True, 'status': 'failed'}
                
        return {'success': False, 'error': result.get('return_msg') or '查询失败'}
        
    except Exception as e:
        logger.error(f"主动查询订单异常: {e}")
        return {'success': False, 'error': str(e)}


@app.route('/api/payment/status', methods=['GET'])
def payment_status():
    """查询支付状态（兼容前端调用）"""
    try:
        order_id = request.args.get('orderId', '')
        openid = request.args.get('openid', '')

        logger.info(f"查询支付状态: orderId={order_id}, openid={openid[:10] if openid else ''}...")

        if not order_id and not openid:
            return jsonify({'success': False, 'error': '订单ID或OpenID不能为空'}), 400

        order = orders.get(order_id) if order_id else None
        if not order:
            if order_id:
                logger.warning(f"订单不存在: {order_id}")
            # 如果没有找到订单，尝试通过openid查找最新的订单
            if openid:
                # 倒序遍历查找最新订单
                for oid, o in reversed(list(orders.items())):
                    if o.get('openid') == openid:
                        order = o
                        order_id = oid
                        break

        if not order:
            return jsonify({'success': False, 'error': '订单不存在', 'paid': False}), 404

        # 如果本地状态未支付，主动去微信查一次
        is_paid = order['status'] == 'paid'
        if not is_paid and not order.get('mock', False):
            # 只有真实订单才去微信查
            wechat_result = query_wechat_order(order_id)
            if wechat_result.get('success') and wechat_result.get('status') == 'paid':
                # 更新本地状态
                order['status'] = 'paid'
                order['paid_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
                order['transaction_id'] = wechat_result.get('transaction_id')
                is_paid = True
                logger.info(f"主动查询发现订单已支付: {order_id}")

        logger.info(f"订单状态: {order_id}, status={order['status']}, paid={is_paid}")

        return jsonify({
            'success': True,
            'order_id': order_id,
            'status': order['status'],
            'paid': is_paid,
            'amount': order['amount'] / 100
        })
    except Exception as e:
        logger.error(f"查询支付状态失败: {str(e)}")
        return jsonify({'success': False, 'error': str(e), 'paid': False}), 500


@app.route('/api/payment/simulate-success', methods=['POST'])
def simulate_payment_success():
    """模拟支付成功（测试用）"""
    try:
        data = request.get_json()
        order_id = data.get('order_id')
        if order_id in orders:
            orders[order_id]['status'] = 'paid'
            orders[order_id]['paid_at'] = time.strftime('%Y-%m-%d %H:%M:%S')
            return jsonify({'success': True, 'message': '模拟支付成功', 'order_id': order_id})
        return jsonify({'success': False, 'error': '订单不存在'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== 微信登录 ====================

# 缓存 access_token
_access_token = None
_access_token_expire = 0

def get_access_token():
    """获取微信接口调用凭证"""
    global _access_token, _access_token_expire
    
    now = time.time()
    if _access_token and now < _access_token_expire:
        return _access_token
        
    appid = WECHAT_PAY_CONFIG['appid']
    secret = WECHAT_PAY_CONFIG['app_secret']
    
    url = f"https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={appid}&secret={secret}"
    
    try:
        response = requests.get(url, timeout=10, verify=False)
        result = response.json()
        
        if 'access_token' in result:
            _access_token = result['access_token']
            _access_token_expire = now + result['expires_in'] - 60  # 提前60秒过期
            logger.info("获取access_token成功")
            return _access_token
        else:
            logger.error(f"获取access_token失败: {result}")
            return None
    except Exception as e:
        logger.error(f"获取access_token异常: {e}")
        return None

@app.route('/api/wechat/phone', methods=['POST'])
def get_user_phone():
    """获取用户手机号"""
    try:
        data = request.get_json()
        code = data.get('code')
        
        if not code:
            return jsonify({'success': False, 'error': 'code不能为空'}), 400
            
        access_token = get_access_token()
        if not access_token:
            return jsonify({'success': False, 'error': '获取access_token失败'}), 500
            
        url = f"https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token={access_token}"
        
        response = requests.post(url, json={'code': code}, timeout=10, verify=False)
        result = response.json()
        
        logger.info(f"获取手机号结果: {result}")
        
        if result.get('errcode') == 0:
            phone_info = result.get('phone_info', {})
            phone_number = phone_info.get('phoneNumber')
            return jsonify({
                'success': True, 
                'phone': phone_number,
                'countryCode': phone_info.get('countryCode')
            })
        else:
            return jsonify({
                'success': False, 
                'error': result.get('errmsg'),
                'code': result.get('errcode')
            })
            
    except Exception as e:
        logger.error(f"获取手机号异常: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/wechat/login', methods=['POST'])
def wechat_login():
    """微信小程序登录，获取openid"""
    try:
        data = request.get_json()
        code = data.get('code')
        if not code:
            return jsonify({'success': False, 'error': 'code不能为空'}), 400

        appid = WECHAT_PAY_CONFIG['appid']
        secret = WECHAT_PAY_CONFIG.get('app_secret')

        logger.info(f"微信登录: appid={appid[:10]}..., code={code[:20]}...")

        # 检查配置
        if not secret or secret == 'YOUR_APP_SECRET':
            logger.error("AppSecret未配置")
            return jsonify({'success': False, 'error': 'AppSecret未配置', 'code': 'APP_SECRET_MISSING'})

        # 调用微信jscode2session接口
        url = f"https://api.weixin.qq.com/sns/jscode2session?appid={appid}&secret={secret}&js_code={code}&grant_type=authorization_code"

        logger.info(f"开始调用微信API: {url[:80]}...")

        # 禁用SSL证书验证（云托管环境需要）
        response = requests.get(url, timeout=10, verify=False)
        result = response.json()

        logger.info(f"微信API返回: {result}")

        if 'openid' in result:
            logger.info(f"成功获取openid: {result['openid'][:10]}...")
            return jsonify({'success': True, 'openid': result.get('openid'), 'session_key': result.get('session_key')})
        else:
            # 微信API调用失败，返回详细错误信息
            err_code = result.get('errcode', '')
            err_msg = result.get('errmsg', '未知错误')
            logger.error(f"微信登录失败: errcode={err_code}, errmsg={err_msg}")

            # 提供更友好的错误信息
            error_display = err_msg
            if err_code == -1:
                error_display = '系统繁忙，请稍后重试'
            elif err_code == 0:
                error_display = 'code已失效，请重新获取'
            elif err_code == 40029:
                error_display = 'code无效，请重新获取'
            elif err_code == 45011:
                error_display = 'API频率限制，请稍后重试'
            elif err_code == 40226:
                error_display = '高风险用户，暂时无法登录'

            return jsonify({
                'success': False,
                'error': error_display,
                'detail': result,
                'code': err_code
            })
    except Exception as e:
        logger.error(f"微信登录异常: {str(e)}")
        return jsonify({'success': False, 'error': f'微信登录异常: {str(e)}', 'exception': str(e)})


@app.route('/api/wechat/test-login', methods=['GET'])
def wechat_test_login():
    """测试微信登录配置是否正确"""
    appid = WECHAT_PAY_CONFIG['appid']
    secret = WECHAT_PAY_CONFIG.get('app_secret')

    return jsonify({
        'success': True,
        'appid_configured': bool(appid),
        'secret_configured': bool(secret and secret != 'YOUR_APP_SECRET'),
        'appid': appid[:10] + '...' if appid else '',
        'mch_id': WECHAT_PAY_CONFIG.get('mch_id')
    })


@app.route('/api/wechat/sandbox-key', methods=['GET'])
def get_sandbox_key():
    """获取沙箱API密钥"""
    if not TEST_MODE:
        return jsonify({
            'success': False,
            'error': '当前不是沙箱测试模式'
        })

    # 尝试获取沙箱密钥
    sandbox_key = get_sandbox_signkey()

    if sandbox_key:
        return jsonify({
            'success': True,
            'sandbox_key': sandbox_key[:10] + '...',
            'test_mode': TEST_MODE,
            'message': '沙箱密钥获取成功'
        })
    else:
        return jsonify({
            'success': False,
            'error': '沙箱密钥获取失败，请检查商户号和API密钥是否正确',
            'test_mode': TEST_MODE
        })


# ==================== AI对话API ====================

@app.route('/api/ai/chat', methods=['POST'])
def ai_chat():
    """AI对话接口"""
    try:
        data = request.get_json()
        user_message = data.get('message', '')
        conversation_history = data.get('history', [])

        if not user_message:
            return jsonify({'success': False, 'error': '消息不能为空'}), 400

        messages = [
            {"role": "system", "content": """你是一位专业的劳动法律AI助手，专注于帮助劳动者维护自身权益。
你的职责是：
1. 用通俗易懂的语言解释劳动法相关知识
2. 分析裁员场景下的合法权益
3. 提供N、N+1、2N等赔偿计算逻辑
4. 给出实用的谈判话术和建议
5. 提醒用户收集证据的重要性

请用中文回复，语气专业但亲切。不要给出具体的法律建议，但可以提供法律信息参考。"""}
        ]

        for msg in conversation_history[-10:]:
            messages.append(msg)
        messages.append({"role": "user", "content": user_message})

        # 如果有API Key，调用AI
        if API_KEY:
            headers = {'Authorization': f'Bearer {API_KEY}', 'Content-Type': 'application/json'}
            payload = {'model': 'gpt-3.5-turbo', 'messages': messages, 'max_tokens': 1000, 'temperature': 0.7}
            response = requests.post(f'{API_BASE_URL}/chat/completions', headers=headers, json=payload, timeout=30)
            if response.status_code == 200:
                result = response.json()
                ai_reply = result['choices'][0]['message']['content']
                return jsonify({'success': True, 'reply': ai_reply})

        # 无API Key或调用失败，使用预设回复
        fallback_reply = get_fallback_reply(user_message)
        return jsonify({'success': True, 'reply': fallback_reply, 'fallback': True})

    except Exception as e:
        logger.error(f"AI对话错误: {str(e)}")
        fallback_reply = get_fallback_reply(user_message if 'user_message' in locals() else '')
        return jsonify({'success': True, 'reply': fallback_reply, 'fallback': True})


def get_fallback_reply(user_message):
    message_lower = user_message.lower()
    if 'n+1' in message_lower or '经济补偿' in message_lower:
        return """N是指经济补偿金，每工作一年支付一个月工资。N+1是在此基础上额外加一个月代通知金。

适用情况：
• N：合同到期不续签、协商解除等
• N+1：公司未提前30天书面通知解除（立即走人）

如果公司违法解除劳动合同，你可以主张2N赔偿！"""
    elif '2n' in message_lower or '赔偿金' in message_lower:
        return """2N是赔偿金，适用于违法解除劳动合同的情况，包括：
• 没有任何正当理由就解除合同
• 试用期无正当理由辞退
• 孕期、产期、哺乳期女职工被辞退
建议先做AI诊断，明确您的具体情况属于哪种情况。"""
    elif '证据' in message_lower or '举证' in message_lower:
        return """劳动仲裁关键证据清单：
1. 劳动合同（最重要）
2. 工资流水、社保缴费记录
3. 考勤记录（钉钉/飞书录屏）
4. 裁员通知、沟通记录
建议立即备份所有证据，防止被公司删除！"""
    else:
        return """感谢您的提问！根据您描述的情况，我建议您：
1. 先收集好相关证据（劳动合同、工资流水、考勤记录等）
2. 了解自己的合法权益
3. 做一个详细的AI诊断，获取个性化方案

如有更多问题，欢迎继续咨询！"""


# ==================== 诊断报告API ====================

@app.route('/api/diagnosis/generate', methods=['POST'])
def generate_diagnosis():
    """生成诊断报告"""
    try:
        data = request.get_json()
        entry_date = data.get('entryDate')
        leave_date = data.get('leaveDate')
        avg_salary = float(data.get('avgSalary', 0))
        reason = data.get('reason')
        notice = data.get('notice')
        employment_type = data.get('employmentType')
        company_nature = data.get('companyNature')

        entry = time.strptime(entry_date, '%Y-%m-%d')
        leave = time.strptime(leave_date, '%Y-%m-%d')
        years = (time.mktime(leave) - time.mktime(entry)) / (365 * 24 * 3600)
        years = round(years, 1)

        # 计算精确的 N 值
        n_value = calculate_n_value(entry_date, leave_date)

        n_months = calculate_n_months_salary(avg_salary, n_value)
        n_plus_1 = calculate_n_plus_1(avg_salary, n_value)
        two_n = calculate_2n(avg_salary, n_value)

        risk_level = 'low'
        risk_text = '根据您提供的情况，公司操作较为规范，建议与公司友好协商。'
        if notice == 'no':
            risk_level = 'medium'
            risk_text = '根据您提供的情况，公司未提前30天书面通知，可能存在程序违法。'
        elif reason in ['unknown', 'performance']:
            risk_level = 'medium'
            risk_text = '根据您提供的情况，公司裁员理由不够充分。'

        report = {
            'report_id': generate_order_id(),
            'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
            'diagnosis': {'entry_date': entry_date, 'leave_date': leave_date, 'years': years, 'avg_salary': avg_salary, 'reason': reason, 'notice': notice, 'employment_type': employment_type, 'company_nature': company_nature},
            'compensation': {'n': n_months, 'n_plus_1': n_plus_1, 'two_n': two_n},
            'risk': {'level': risk_level, 'text': risk_text},
            'evidence_checklist': [
                {'title': '劳动合同', 'desc': '确认合同期限、工资标准、工作内容等关键条款'},
                {'title': '工资流水', 'desc': '打印最近12个月的银行流水，盖章备存'},
                {'title': '考勤记录', 'desc': '立即录屏保存钉钉/飞书打卡记录'},
                {'title': '裁员通知', 'desc': '保留公司发出的书面裁员通知、邮件、聊天记录'},
                {'title': '离职证明', 'desc': '如已开具，注意核对内容是否与实际情况一致'}
            ],
            'negotiation_tips': ['保持冷静，不要在情绪激动时做决定', '要求公司出具书面解除通知', '核对赔偿金额是否按法律规定计算', '不要签署任何空白或不了解的文件']
        }

        report_id = report['report_id']
        diagnosis_reports[report_id] = report
        return jsonify({'success': True, 'report': report, 'report_id': report_id})

    except Exception as e:
        logger.error(f"生成诊断报告错误: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/diagnosis/get/<report_id>', methods=['GET'])
def get_diagnosis(report_id):
    """获取诊断报告"""
    report = diagnosis_reports.get(report_id)
    if report:
        return jsonify({'success': True, 'report': report})
    return jsonify({'success': False, 'error': '报告不存在'}), 404


# ==================== 用户API ====================

@app.route('/api/user/login', methods=['POST'])
def user_login():
    """用户登录/注册"""
    try:
        data = request.get_json()
        phone = data.get('phone')
        name = data.get('name', '用户')
        if not phone:
            return jsonify({'success': False, 'error': '手机号不能为空'}), 400

        user_id = f"user_{phone[-4:]}_{int(time.time())}"
        user_sessions[user_id] = {'phone': phone, 'name': name, 'created_at': time.strftime('%Y-%m-%d %H:%M:%S')}
        return jsonify({'success': True, 'user': {'id': user_id, 'phone': phone, 'name': name}})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== 图片上传API ====================

import base64
import uuid

# 存储上传的图片URL
uploaded_images = {}

@app.route('/api/upload/image', methods=['POST'])
def upload_image():
    """上传图片并返回URL"""
    try:
        data = request.get_json()
        image_base64 = data.get('image', '')

        if not image_base64:
            return jsonify({'success': False, 'error': '图片数据不能为空'}), 400

        # 生成唯一文件名
        image_id = str(uuid.uuid4())
        filename = f"{image_id}.png"

        # 确定存储目录
        upload_dir = '/app/uploads'
        if not os.path.exists(upload_dir):
            upload_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')

        os.makedirs(upload_dir, exist_ok=True)
        file_path = os.path.join(upload_dir, filename)

        # 解码并保存图片
        try:
            image_data = base64.b64decode(image_base64)
            with open(file_path, 'wb') as f:
                f.write(image_data)
        except Exception as e:
            logger.error(f"图片解码失败: {e}")
            return jsonify({'success': False, 'error': '图片数据格式错误'}), 400

        # 返回访问URL（完整URL）
        # 优先使用自定义域名
        host = request.host
        scheme = 'https'
        image_url = f"{scheme}://{host}/uploads/{filename}"

        uploaded_images[image_id] = {
            'url': image_url,
            'path': file_path,
            'created_at': time.strftime('%Y-%m-%d %H:%M:%S')
        }

        logger.info(f"图片上传成功: {filename}, URL: {image_url}")
        return jsonify({
            'success': True,
            'url': image_url,
            'image_id': image_id
        })

    except Exception as e:
        logger.error(f"图片上传失败: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


# ==================== 健康检查 ====================

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'ok',
        'service': '裁神来了后端服务',
        'version': '2.0.0',
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        'wechat_pay_configured': WECHAT_PAY_CONFIG['mch_id'] != 'YOUR_MCH_ID'
    })


# ==================== 启动服务 ====================


@app.route('/dist/<path:filename>')
def serve_dist_static(filename):
    """明确服务 dist 目录下的静态文件"""
    dist_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dist')
    if os.path.exists(os.path.join(dist_dir, filename)):
        response = send_from_directory(dist_dir, filename)
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response.headers['Pragma'] = 'no-cache'
        response.headers['Expires'] = '0'
        return response
    return "File not found in dist", 404

@app.route('/<path:filename>')
def serve_static(filename):
    """服务静态文件"""
    # 排除API路由
    if filename.startswith('api/'):
        return "API endpoint not found", 404

    static_dir = find_static_file(filename)
    if static_dir:
        response = send_from_directory(static_dir, filename)
        if filename in ['app.js', 'styles.css', 'index.html']:
            response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
            response.headers['Pragma'] = 'no-cache'
            response.headers['Expires'] = '0'
        return response
    return "File not found", 404


@app.route('/debug/appjs')
def debug_appjs():
    import os
    try:
        app_js_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'app.js')
        with open(app_js_path, 'r', encoding='utf-8') as f:
            app_content = f.read()
        return "FOUND unlockToolPackage: " + str('window.unlockToolPackage = function' in app_content) + "\nIS_AD_VERSION: " + str('观看30s广告解锁' in app_content) + "\nLENGTH: " + str(len(app_content))
    except Exception as e:
        return str(e)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=IS_LOCAL)
