import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 恢复 H5 的引导页
old_init = """document.addEventListener('DOMContentLoaded', function() {
    console.log('裁神来了 - DOM加载完成');

    // 如果从小程序进入，跳过H5引导页
    if (window.location.search.indexOf('from_miniprogram=1') > -1) {
        var splashScreen = document.getElementById('splash-screen');
        var mainContent = document.getElementById('main-content');
        if (splashScreen) splashScreen.style.display = 'none';
        if (mainContent) {
            mainContent.classList.remove('hidden');
            mainContent.style.display = 'block';
        }
    }

    // 初始化数据渲染
    initLandingPage();"""

new_init = """document.addEventListener('DOMContentLoaded', function() {
    console.log('裁神来了 - DOM加载完成');

    // 初始化数据渲染
    initLandingPage();"""

content = content.replace(old_init, new_init)

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Restored H5 splash screen logic.")
