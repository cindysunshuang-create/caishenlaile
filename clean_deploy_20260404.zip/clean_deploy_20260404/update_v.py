import re
import os
import shutil

index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'

with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()

# 更换 v 值爆破缓存
html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_ONLY_MINI_SPLASH', html_content)

with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print("Cache buster updated.")
