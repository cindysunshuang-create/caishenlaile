import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 移除 H5 内部的引导页跳过逻辑，并隐藏它，也就是去掉第二个引导页
old_init = """document.addEventListener('DOMContentLoaded', function() {
    console.log('裁神来了 - DOM加载完成');

    // 初始化数据渲染
    initLandingPage();"""

new_init = """document.addEventListener('DOMContentLoaded', function() {
    console.log('裁神来了 - DOM加载完成');

    // 由于外部小程序已经有引导页了，这里 H5 一加载就直接隐藏自己的引导页（去掉第二个引导页）
    var splashScreen = document.getElementById('splash-screen');
    var mainContent = document.getElementById('main-content');
    if (splashScreen) splashScreen.style.display = 'none';
    if (mainContent) {
        mainContent.classList.remove('hidden');
        mainContent.style.display = 'block';
    }

    // 初始化数据渲染
    initLandingPage();"""

content = content.replace(old_init, new_init)

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Removed H5 inner splash screen.")
