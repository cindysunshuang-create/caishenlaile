import re
import os

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 增强 checkAdUnlocked 逻辑，让其支持 diagnosis_report，并在 URL 参数检测到解锁后，主动调用 handlePaymentSuccess 触发页面重绘和报告展开

new_unlock_check = """
// 广告解锁检查增强版
window.checkAdUnlocked = function(productType) {
    try {
        var unlockKey = 'ad_unlocked_' + productType;
        
        // 1. 检查 URL 参数
        var urlParams = new URLSearchParams(window.location.search);
        var unlockedType = urlParams.get('unlocked_type');
        var justUnlocked = false;
        
        if (unlockedType === productType) justUnlocked = true;
        
        // 2. 检查本地缓存（从微信 webview.js 同步过来的或者 H5 写入的）
        if (localStorage.getItem(unlockKey)) justUnlocked = true;
        
        // 如果是刚刚解锁的，我们需要确保对应的解锁逻辑被执行，把阻挡层去掉
        if (justUnlocked) {
            return true;
        }
        
        // 3. 检查 AppState
        if (productType === 'script' || productType === 'tool_package') {
            return AppState.hasToolPackage || AppState.hasScriptPackage;
        }
        if (productType === 'topic' || productType === 'topic_package') {
            return AppState.hasTopicPackage;
        }
        if (productType === 'diagnosis_report') {
            return AppState.hasDiagnosisReport;
        }
        
    } catch(e) {}
    return false;
};

// 监听从小程序原生页回退时的 URL 变化，自动触发解锁展开
document.addEventListener('DOMContentLoaded', function() {
    try {
        var urlParams = new URLSearchParams(window.location.search);
        var unlockedType = urlParams.get('unlocked_type');
        
        // 如果是因为看完广告返回而带上的参数，或者带有 refresh_ts 且有缓存
        if (unlockedType) {
            console.log('检测到广告解锁返回参数:', unlockedType);
            setTimeout(function() {
                if (typeof window.handlePaymentSuccess === 'function') {
                    window.handlePaymentSuccess(unlockedType);
                }
            }, 500); // 稍微延迟，确保 DOM 已经渲染完毕
        }
    } catch(e) {}
});

// 重写诊断报告展示逻辑，拦截支付直接跳广告
var old_showReport = window.showReport;
window.showReport = function(forceShow) {
    if (!checkLogin(true)) return;
    
    // 如果没有 forceShow 并且报告没有解锁，则拦截并跳转广告
    if (!forceShow && !checkAdUnlocked('diagnosis_report')) {
        showPaymentModal('diagnosis_report', 0);
        return;
    }
    
    // 调用原始的展示逻辑
    if (typeof old_showReport === 'function') {
        old_showReport(true);
    }
};

// 拦截原先点击“获取诊断报告 (¥9.9)”等按钮的逻辑
window.generateReport = function() {
    if (!checkLogin(true)) return;
    
    // 原本 generateReport 可能是去调起支付，现在我们直接跳广告
    if (!checkAdUnlocked('diagnosis_report')) {
        showPaymentModal('diagnosis_report', 0);
        return;
    }
    showReport(true);
};
"""

# 我们把它加到文件末尾
content += new_unlock_check

# 更新缓存号
index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()
html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_DIAGNOSIS_AD', html_content)
with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)
print("Diagnosis report ad logic successfully patched!")