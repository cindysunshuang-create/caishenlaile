// 裁神来了 - 完整业务逻辑（修复版）

var API_BASE_URL = (function() {
    var urlParams;
    var apiBaseFromQuery = '';
    try {
        urlParams = new URLSearchParams(window.location.search);
        apiBaseFromQuery = (urlParams.get('api_base') || '').trim();
    } catch (e) {}
    if (apiBaseFromQuery) {
        try { localStorage.setItem('api_base_override', apiBaseFromQuery); } catch (e) {}
        return apiBaseFromQuery.replace(/\/+$/, '');
    }
    var apiBaseFromStorage = '';
    try { apiBaseFromStorage = (localStorage.getItem('api_base_override') || '').trim(); } catch (e) {}
    if (apiBaseFromStorage) {
        return apiBaseFromStorage.replace(/\/+$/, '');
    }
    return (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1')
        ? 'http://localhost:8081'
        : 'https://www.caishenlaile88.com';
})();

// ==================== 数据定义 ====================
var AppState = {
    currentTab: 'home',
    diagnosisStep: 1,
    totalSteps: 8,
    isLoggedIn: false,
    hasRejectedAuth: false,
    userData: {
        phone: '',
        name: '',
        avatar: '👤',
        entryDate: null,
        leaveDate: null,
        avgSalary: null,
        reason: null,
        notice: null,
        employmentType: null,
        companyNature: null,
        pregnancy: null
    },
    calculatedData: {
        years: 0,
        n: 0,
        n1: 0,
        city: 'beijing'
    },
    currentReport: null,
    hasToolPackage: false,
    hasDiagnosisReport: false,
    hasTopicPackage: false,  // 热门话题包解锁状态
    freeTopicIds: ['n1', '2n', 'pip', 'sign'],
    topicListData: [],
    topicMap: {},
    savedReports: [],  // 保存的报告历史
    userOpenId: null  // 用户微信openid
};

function loadUnlockState() {
    try {
        AppState.hasToolPackage = localStorage.getItem('hasToolPackage') === 'true';
        AppState.hasTopicPackage = localStorage.getItem('hasTopicPackage') === 'true';
    } catch (e) {}
}

function persistUnlockState() {
    try {
        localStorage.setItem('hasToolPackage', AppState.hasToolPackage ? 'true' : 'false');
        localStorage.setItem('hasTopicPackage', AppState.hasTopicPackage ? 'true' : 'false');
    } catch (e) {}
}

// ==================== 微信登录获取openid ====================
// 从URL参数获取openid
function getOpenIdFromUrl() {
    try {
        var urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('openid') || '';
    } catch (e) {
        // 兼容不支持URLSearchParams的浏览器
        var match = window.location.search.match(/[?&]openid=([^&]*)/);
        return match ? match[1] : '';
    }
}

window.getUserOpenId = function() {
    return new Promise(function(resolve, reject) {
        // 如果已有openid，直接返回
        if (AppState.userOpenId) {
            resolve(AppState.userOpenId);
            return;
        }

        // 优先从URL参数获取openid（从小程序webview传入）
        var urlOpenId = getOpenIdFromUrl();
        if (urlOpenId) {
            AppState.userOpenId = urlOpenId;
            try {
                localStorage.setItem('wechatOpenId', urlOpenId);
            } catch (e) {}
            resolve(urlOpenId);
            return;
        }

        // 尝试从localStorage获取
        try {
            var storedOpenId = localStorage.getItem('wechatOpenId');
            if (storedOpenId) {
                AppState.userOpenId = storedOpenId;
                resolve(storedOpenId);
                return;
            }
        } catch (e) {
            console.log('localStorage不可用');
        }

        // 微信小程序环境尝试获取openid
        if (typeof wx !== 'undefined' && wx.login) {
            wx.login({
                success: function(loginRes) {
                    if (loginRes.code) {
                        // 发送code到后端获取openid
                        fetch(API_BASE_URL + '/api/wechat/login', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ code: loginRes.code })
                        })
                        .then(function(response) { return response.json(); })
                        .then(function(data) {
                            if (data.success && data.openid) {
                                AppState.userOpenId = data.openid;
                                try {
                                    localStorage.setItem('wechatOpenId', data.openid);
                                } catch (e) {}
                                resolve(data.openid);
                            } else {
                                resolve(null);
                            }
                        })
                        .catch(function() {
                            resolve(null);
                        });
                    } else {
                        resolve(null);
                    }
                },
                fail: function() {
                    resolve(null);
                }
            });
        } else {
            // 非微信环境
            resolve(null);
        }
    });
};

// ==================== 登录验证 ====================
// 检查是否登录，未登录则弹出授权弹窗
// 如果用户之前拒绝过授权，再次提示
window.checkLogin = function() {
    // 1. 检查全局状态和本地存储
    if (AppState.isLoggedIn || localStorage.getItem('userPhone')) {
        return true;
    }

    // 2. 双重保险：检查 URL 参数（防止页面未刷新或初始化延迟导致状态未同步）
    // 如果用户刚从授权页返回，URL中会有phone参数，但可能因为页面未刷新导致checkUrlParamsForAuth未执行
    try {
        var urlParams = new URLSearchParams(window.location.search);
        var phone = urlParams.get('phone');
        if (phone) {
            console.log('checkLogin: 检测到URL中有phone，自动登录');
            // 立即同步状态
            localStorage.setItem('userPhone', phone);
            localStorage.removeItem('auth_rejected');
            AppState.isLoggedIn = true;
            AppState.userData.phone = phone;
            AppState.userData.name = '微信用户';
            
            // 顺便触发一下UI更新，但不需要阻塞返回
            setTimeout(function() {
                updateLoginState();
                updateProfileDisplay();
            }, 0);
            
            return true;
        }
    } catch(e) {
        console.error('checkLogin URL检查失败:', e);
    }

    // 3. 未登录或未授权手机号，由于主界面功能已改为未授权可用，不再强制跳转
    // 我们目前要求所有功能未授权下可用，所以这里直接返回 true。
    // 如果真要登录，用户会点击头像。
    return true; // 允许未授权使用功能
};

// 话术库数据（完整版 - 带案例详情）
var ScriptData = [
    {
        id: 1,
        title: 'HR约谈开场 - 保持冷静',
        desc: '与HR协商时的开场白和要点',
        category: '基础策略',
        hrSay: '我们今天聊聊你的工作表现...',
        truth: '这是HR的经典开场白，目的是让你紧张从而降低心理防线。',
        answer: '好的，我了解。我们可以详细聊聊。请问我可以录音保留记录吗？'
    },
    {
        id: 2,
        title: '要求出具书面通知',
        desc: '争取合理赔偿金的对话策略',
        category: '基础策略',
        hrSay: '你收拾一下，明天不用来了。',
        truth: '根据《劳动合同法》，公司解除劳动合同应当出具书面通知。',
        answer: '请出具书面的解除劳动合同通知，否则我不认可解除的合法性。'
    },
    {
        id: 3,
        title: 'PIP威胁',
        desc: '应对绩效改进计划的陷阱',
        category: '深度场景',
        hrSay: '不签PIP就自愿离职！',
        truth: 'PIP是变相裁员的常用手段，员工有权拒绝不合理的PIP。',
        answer: '我不同意签署这份PIP。请按照法律规定的程序来，如果公司要裁员，请依法支付赔偿。'
    },
    {
        id: 4,
        title: '协商解除话术',
        desc: '与HR协商解除劳动合同',
        category: '深度场景',
        hrSay: '公司愿意给N，你考虑一下。',
        truth: 'N是法定最低标准，可以尝试争取N+1或2N。',
        answer: '我理解公司的立场。根据我的工作年限和工资水平，N+1是我能接受的最低方案。如果协商不成，我会通过劳动仲裁维护权益。'
    },
    {
        id: 5,
        title: '拒绝主动离职诱导',
        desc: '应对公司诱导主动辞职的方法',
        category: '深度场景',
        hrSay: '你主动离职吧，这样对你以后找工作好。',
        truth: '主动离职等于放弃所有赔偿，切记不要签署任何自愿离职文件！',
        answer: '谢谢关心。我不会主动离职。如果公司要解除劳动合同，请按照法律规定来，我会保留通过法律途径维护权益的权利。'
    }
];

// 证据清单数据（完整版）
var EvidenceData = [
    { id: 1, title: '劳动合同原件', desc: '证明劳动关系和工资标准', content: '劳动合同是证明劳动关系的最重要证据。原件丢失可到社保局打印缴费记录，或到公积金管理中心打印缴费明细。' },
    { id: 2, title: '工资条/银行流水', desc: '证明实际工资收入', content: '工资流水可到银行打印详细交易记录。建议保留工资条原件或电子版。年终奖、绩效奖等也需证明。' },
    { id: 3, title: '社保公积金缴费记录', desc: '证明缴费基数和年限', content: '社保缴费记录可到社保局自助机打印或通过社保APP查询。公积金可到公积金管理中心打印。这些是计算赔偿金的重要依据。' },
    { id: 4, title: '考勤记录', desc: '证明工作时间加班情况', content: '考勤记录包括打卡记录、加班审批单、调休记录等。加班费维权需要提供充分证据，建议平时注意保留。' },
    { id: 5, title: '解除劳动合同通知', desc: '证明离职原因和时间', content: '包括公司出具的书面解除通知、邮件通知、微信聊天记录等。口头通知需录音取证，明确记录离职时间和原因。' },
    { id: 6, title: '工作证/工牌/名片', desc: '证明工作身份', content: '工作证、工牌、名片等可以证明你在公司的职位和工作年限。' },
    { id: 7, title: '绩效考核文件', desc: '证明工作表现', content: '包括绩效考核表、评估报告、PIP文件等。注意不要签署"不符合录用条件"的评估。' },
    { id: 8, title: '调岗调薪通知', desc: '证明岗位变动', content: '任何岗位调整、工资变动都需要书面确认。保留相关审批单、通知邮件等。' },
    { id: 9, title: '加班申请/审批记录', desc: '证明加班事实', content: '加班需要公司审批的，保留加班申请表、审批邮件等。口头加班需录音或聊天记录作证。' },
    { id: 10, title: '公司规章制度', desc: '了解离职程序', content: '公司的员工手册、考勤制度、绩效考核制度等，了解合法离职程序和赔偿标准。' }
];

// 热门话题数据（完整版 - 2024最新）
var TopicData = [
    { id: 'n1', category: '赔偿', title: 'N和N+1的区别', desc: '经济补偿金与代通知金', content: 'N是指经济补偿金，按劳动者在本单位工作的年限，每满一年支付一个月工资。<br><br>N+1是指经济补偿金+代通知金，公司未提前30天通知需额外支付一个月工资。<br><br><strong>2024年新变化：</strong>部分地区对高工资员工有3倍社平工资封顶限制。',
      cases: [{ platform: '脉脉', summary: '入职3年，被公司以"组织架构优化"裁员，HR最初只肯给N，沟通后拿到N+1', result: 'N+1' }, { platform: '小红书', summary: '工作5年，月薪2万，公司口头通知裁员，最终仲裁拿到2N赔偿40万', result: '2N 40万' }] },
    { id: '2n', category: '赔偿', title: '2N赔偿金条件', desc: '违法解除劳动合同的赔偿', content: '2N是赔偿金，适用于违法解除劳动合同的情况，金额是经济补偿金的2倍。<br><br><strong>常见违法解除情形：</strong><br>• 没有任何正当理由解除合同<br>• 未提前30天书面通知<br>• 以"不能胜任"为由但无证据<br>• 孕期、产期、哺乳期女职工<br><br><strong>维权建议：</strong>先协商，协商不成可申请劳动仲裁。',
      cases: [{ platform: '知乎', summary: '孕期被公司以"绩效不合格"辞退，仲裁成功拿到2N赔偿', result: '2N' }, { platform: '脉脉', summary: '无任何理由被裁员，公司无法举证合法性，最终判赔2N', result: '2N' }] },
    { id: 'pip', category: '谈判', title: 'PIP绩效改进计划', desc: '如何应对绩效改进计划', content: 'PIP是绩效改进计划，常被用作变相裁员的手段。<br><br><strong>应对方法：</strong><br>• 要求明确具体的绩效标准<br>• 保留所有沟通记录<br>• 拒绝签署不合理的PIP文件<br>• 必要时可拒绝签字并书面说明理由<br><br><strong>重要：</strong>PIP本身不违法，但以此为由裁员需要提供充分证据。',
      cases: [{ platform: '小红书', summary: '入职8个月突遭PIP，拒绝签字后公司以"不符合录用条件"辞退，最终仲裁败诉', result: 'N/A 败诉' }, { platform: '脉脉', summary: '被PIP后收集证据证明考核标准不合理，谈判成功拿到N+1.5', result: 'N+1.5' }] },
    { id: 'sign', category: '合同', title: '试用期转正陷阱', desc: '试用期违规解除的识别', content: '试用期被裁员同样有赔偿！<br><br>• 工作不满6个月，按0.5个月工资计算N<br>• 违法解除同样可以主张2N<br><br><strong>注意：</strong>不要签署"不符合录用条件"的评估表，这可能成为公司合法解除的依据。',
      cases: [{ platform: '脉脉', summary: '试用期第5个月被以"不符合录用条件"辞退，未签评估表，仲裁拿回1个月工资', result: '1个月工资' }, { platform: '小红书', summary: '应届生试用期被裁，HR威胁不签自愿离职就写差评，最终坚持仲裁拿到N+1', result: 'N+1' }] },
    { id: 'contract1', category: '合同', title: '这些字千万别签', desc: '离职协议的自愿离职申请', content: '签字前务必谨慎，以下文件不要轻易签字：<br><br>❌ <strong>《离职协议》</strong> - 确认补偿金额是否合理<br><br>❌ <strong>《自愿离职申请》</strong> - 签了等于自愿，没有赔偿<br><br>❌ <strong>《绩效考核确认书》</strong> - 可能成为"不能胜任"的证据<br><br>❌ <strong>《竞业限制协议》</strong> - 可能影响后续就业',
      cases: [{ platform: '知乎', summary: '签署《自愿离职申请》后后悔，因无法证明胁迫，仲裁败诉', result: '0 败诉' }, { platform: '脉脉', summary: '拒签《离职协议》后公司妥协，最终拿到N+2', result: 'N+2' }] },
    { id: 'process1', category: '流程', title: '劳动仲裁流程', desc: '申请仲裁的全流程指引', content: '劳动仲裁流程：<br><br>1. 提交仲裁申请<br>2. 仲裁委5日内决定是否受理<br>3. 开庭审理<br>4. 调解（如有）<br>5. 裁决<br><br><strong>注意：</strong>劳动仲裁免费，一般45天内结案。不服裁决可在15日内向法院起诉。',
      cases: [{ platform: '知乎', summary: '全程自己打仲裁，提交12项证据，最终胜诉拿到18万赔偿', result: '胜诉 18万' }, { platform: '小红书', summary: '仲裁到执行用了6个月，公司已无财产可执行，提醒大家早行动', result: '执行难' }] },
    { id: 'overtime', category: '赔偿', title: '加班费怎么算？', desc: '加班工资计算标准', content: '加班费计算标准：<br><br>• 工作日加班：1.5倍工资<br>• 休息日加班：2倍工资（可安排补休）<br>• 法定节假日加班：3倍工资<br><br><strong>2024年新规：</strong>加班费计入社保缴费基数，节假日加班需支付300%工资且不能以调休替代。',
      cases: [{ platform: '脉脉', summary: '保留3年加班记录，仲裁成功追回加班费12万', result: '12万' }, { platform: '小红书', summary: '只有口头要求加班无证据，仲裁败诉，提醒大家注意留痕', result: '0 败诉' }] },
    { id: 'social', category: '赔偿', title: '社保断缴怎么办？', desc: '社保公积金维权', content: '公司未足额缴纳社保公积金，可以：<br><br>1. <strong>向社保局投诉</strong> - 要求公司补缴<br>2. <strong>申请劳动仲裁</strong> - 通过仲裁追缴<br><br><strong>注意：</strong>• 补缴不受1年时效限制<br>• 需要提供劳动关系证明<br>• 个人部分也需要补缴<br><br><strong>建议：</strong>先协商，协商不成再投诉。',
      cases: [{ platform: '脉脉', summary: '投诉后公司补缴3年社保，个人部分自己出了2万', result: '补缴成功' }, { platform: '小红书', summary: '仲裁追缴公积金，成功补缴6万', result: '6万' }] }
];

// 知识库数据（完整版 - 2024最新劳动法）
var KnowledgeData = [
    {
        id: 1,
        title: '什么是N、N+1、2N？',
        desc: '经济补偿金与赔偿金的区别',
        content: 'N = 经济补偿金，按劳动者在本单位工作的年限，每满一年支付一个月工资。<br><br>N+1 = 经济补偿金 + 代通知金，公司未提前30天书面通知需额外支付一个月工资。<br><br>2N = 赔偿金，适用于违法解除劳动合同的情况，金额是经济补偿金的2倍。'
    },
    {
        id: 2,
        title: '哪些情况属于违法解除？',
        desc: '违法解除劳动合同的认定标准',
        content: '以下情况属于违法解除劳动合同：<br><br>• 没有任何正当理由解除合同<br>• 未按照法定程序（如未提前30天通知）<br>• 以"不能胜任工作"为由但无证据证明<br>• 孕期、产期、哺乳期女职工（特殊保护）<br>• 患职业病或因工负伤并丧失劳动能力<br>• 在规定的医疗期内解除合同<br>• 劳务派遣员工被退回无合理安排'
    },
    {
        id: 3,
        title: '试用期被裁员有赔偿吗？',
        desc: '试用期解除劳动合同的赔偿',
        content: '试用期被裁员同样有赔偿！<br><br>• 试用期也受《劳动合同法》保护<br>• 工作不满6个月，按0.5个月工资计算N<br>• 如果违法解除，同样可以主张2N<br>• 试用期离职也需要出具书面证明<br><br><strong>注意：</strong>不要签署任何"不符合录用条件"的评估表，这可能成为公司合法解除的依据。'
    },
    {
        id: 4,
        title: '这些字千万别签！',
        desc: '离职文件签署注意事项',
        content: '签字前务必谨慎，以下文件不要轻易签字：<br><br>❌ <strong>《离职协议》</strong> - 确认补偿金额是否合理<br><br>❌ <strong>《自愿离职申请》</strong> - 签了等于自愿，没有赔偿<br><br>❌ <strong>《绩效考核确认书》</strong> - 可能成为"不能胜任"的证据<br><br>❌ <strong>《竞业限制协议》</strong> - 可能影响后续就业且可能有违约金<br><br>❌ <strong>《解除劳动合同证明》</strong> - 注意解除原因一栏'
    },
    {
        id: 5,
        title: '劳动仲裁需要什么证据？',
        desc: '劳动仲裁证据清单',
        content: '关键证据清单：<br><br>📄 <strong>劳动合同</strong>（最重要）<br><br>💰 <strong>工资流水</strong>、社保缴费记录<br><br>📅 <strong>考勤记录</strong><br><br>📧 <strong>裁员通知</strong>、沟通记录（微信、邮件、录音）<br><br>📛 <strong>工作证</strong>、工牌、名片<br><br>💬 <strong>微信/邮件</strong>工作沟通记录<br><br><strong>提示：</strong>尽量保留原件，复印件要清晰完整；录音录像要保存原始载体。'
    },
    {
        id: 6,
        title: '劳动仲裁流程是怎样的？',
        desc: '申请仲裁的全流程指引',
        content: '仲裁流程：<br><br>1. <strong>提交仲裁申请</strong> - 向劳动合同履行地或用人单位所在地的劳动仲裁委员会提交申请书<br><br>2. <strong>受理后等待</strong> - 仲裁委会在5日内决定是否受理<br><br>3. <strong>开庭审理</strong> - 双方到庭陈述事实和理由<br><br>4. <strong>调解</strong> - 仲裁委会先组织调解<br><br>5. <strong>裁决</strong> - 调解不成，依法作出裁决<br><br><strong>注意：</strong>劳动仲裁免费，一般45天内结案。不服裁决可在15日内向法院起诉。'
    },
    {
        id: 7,
        title: '经济性裁员有什么特殊规定？',
        desc: '企业经济性裁员的法定条件',
        content: '经济性裁员条件（根据《劳动合同法》第41条）：<br><br>需要符合以下条件之一：<br>• 依照企业破产法规定进行重整的<br>• 生产经营发生严重困难的<br>• 企业转产、重大技术革新或者经营方式调整<br>• 其他因劳动合同订立时所依据的客观经济情况发生重大变化<br><br><strong>程序要求：</strong><br>• 提前30天向工会或全体职工说明情况<br>• 听取工会或职工意见后<br>• 向劳动行政部门报告裁员方案<br><br><strong>优先留用人员：</strong>签订无固定期限劳动合同、家庭无其他就业人员、有需要扶养的老人或未成年人。'
    }
];

// ==================== 初始化 ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log('裁神来了 - DOM加载完成');

    // 初始化数据渲染
    initLandingPage();

    // 加载保存的报告历史
    loadSavedReports();
    loadUnlockState();

    // 自动登录检查
    var localPhone = localStorage.getItem('userPhone');
    if (localPhone) {
        AppState.isLoggedIn = true;
        AppState.userData.phone = localPhone;
        AppState.userData.name = localStorage.getItem('userName') || '微信用户';
        AppState.userData.avatar = localStorage.getItem('userAvatar') || 'https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0KlMECNjjGxQUq24ZEaGT4poC6icRiccVGKSyXwibcPq4BWmiaIGuG1icwxaQX6grC9VemZoJ8rg/132';
        updateLoginState();
        updateProfileDisplay();
        
        // 检查是否有刚授权完回来的状态，并且有待处理的动作
        if (localStorage.getItem('just_authed') === 'true') {
            localStorage.removeItem('just_authed');
            var pendingAction = localStorage.getItem('pendingAction');
            if (pendingAction && typeof window[pendingAction] === 'function') {
                console.log('自动恢复执行被中断的操作:', pendingAction);
                localStorage.removeItem('pendingAction');
                // 稍微延迟执行，确保DOM和状态已完全初始化
                setTimeout(function() {
                    window[pendingAction]();
                }, 500);
            }
        }
    }

    // 绑定事件监听器
    initEventListeners();
});

// 初始化首页展示
function initLandingPage() {
    // 渲染话术库预览（前3条）
    renderScriptPreview();
    // 渲染证据清单预览（前3条）
    renderEvidencePreview();
    // 渲染热门话题预览（前3条）
    renderTopicPreview();
    // 渲染知识库预览（前3条）
    renderKnowledgePreview();
}

// 渲染话术库预览
function renderScriptPreview() {
    var container = document.getElementById('script-library-content');
    if (!container) return;

    var html = '';
    var previewData = ScriptData.slice(0, 3); // 只取前3条

    previewData.forEach(function(item) {
        html += '<div class="topic-item" onclick="showScriptDetail(' + item.id + ')">' +
            '<div class="topic-icon">📝</div>' +
            '<div class="topic-info">' +
            '<h3>' + item.title + '</h3>' +
            '<p>' + item.desc + '</p>' +
            '</div>' +
            '<div class="topic-arrow">›</div>' +
            '</div>';
    });

    container.innerHTML = html;
}

// 渲染证据清单预览
function renderEvidencePreview() {
    // 证据清单在前3条逻辑类似
    console.log('证据清单预览渲染完成');
}

// 渲染热门话题预览
function renderTopicPreview(filterCategory) {
    var container = document.querySelector('.topics-section .topics-list');
    if (!container) return;

    var html = '';
    var filteredData = TopicData;

    // 如果有筛选分类，则过滤数据
    if (filterCategory && filterCategory !== '全部') {
        filteredData = TopicData.filter(function(item) {
            return item.category === filterCategory;
        });
    }

    var previewData = filteredData;

    previewData.forEach(function(item) {
        html += '<div class="topic-item" onclick="showTopicDetail(\'' + item.id + '\')">' +
            '<div class="topic-icon">💡</div>' +
            '<div class="topic-info">' +
            '<h3>' + item.title + '</h3>' +
            '<p>' + item.desc + '</p>' +
            '</div>' +
            '<div class="topic-arrow">›</div>' +
            '</div>';
    });

    container.innerHTML = html;
}

// 渲染热门话题页面（全量数据+分类筛选）
function getTopicIdentityParams() {
    var params = [];
    var userId = (AppState.userData && AppState.userData.phone) || '';
    if (userId) {
        params.push('userId=' + encodeURIComponent(userId));
    }
    var openid = '';
    try {
        openid = getOpenIdFromUrl() || localStorage.getItem('wechatOpenId') || '';
    } catch (e) {}
    if (openid) {
        params.push('openid=' + encodeURIComponent(openid));
    }
    return params;
}

function fetchTopicList(filterCategory) {
    var params = getTopicIdentityParams();
    if (filterCategory && filterCategory !== '全部') {
        params.push('category=' + encodeURIComponent(filterCategory));
    } else {
        params.push('category=' + encodeURIComponent('全部'));
    }
    var query = params.length > 0 ? '?' + params.join('&') : '';
    return fetch(API_BASE_URL + '/api/topics' + query, {
        method: 'GET',
        credentials: 'include'
    }).then(function(res) {
        return res.json();
    });
}

function fetchTopicDetail(topicId) {
    var params = getTopicIdentityParams();
    var query = params.length > 0 ? '?' + params.join('&') : '';
    return fetch(API_BASE_URL + '/api/topics/' + encodeURIComponent(topicId) + query, {
        method: 'GET',
        credentials: 'include'
    }).then(function(res) {
        return res.json().then(function(data) {
            data._httpStatus = res.status;
            return data;
        });
    });
}

function renderTopicPage(filterCategory) {
    var container = document.getElementById('topic-list-container');
    var paywall = document.getElementById('topic-paywall');
    if (!container) return;

    var list = TopicData;
    if (filterCategory && filterCategory !== '全部') {
        list = TopicData.filter(function(item) {
            return item.category === filterCategory;
        });
    }

    var displayList = AppState.hasTopicPackage ? list : list.slice(0, 4);
    var html = '<div class="topic-list" style="background-color: #1a1b23 !important; padding: 20px; border-radius: 12px; color: #fff !important;">';
    
    if (AppState.hasTopicPackage) {
        var categories = ['全部', '赔偿', '合同', '流程', '谈判'];
        html += '<div class="topic-filter" style="display: flex; gap: 10px; margin-bottom: 20px; overflow-x: auto; padding-bottom: 5px;">';
        categories.forEach(function(cat) {
            var activeClass = (filterCategory === cat || (!filterCategory && cat === '全部')) ? 'background-color: #406eff; color: white;' : 'background-color: #2a2b36 !important; color: #8a8b94;';
            html += '<span class="filter-chip" style="padding: 6px 12px; border-radius: 16px; font-size: 14px; white-space: nowrap; cursor: pointer; ' + activeClass + '" onclick="filterTopic(\'' + cat + '\')">' + cat + '</span>';
        });
        html += '</div>';
    }

    displayList.forEach(function(item) {
        html += '<div class="topic-item topic-list-item" onclick="showTopicDetail(\'' + item.id + '\')" style="display: flex; align-items: flex-start; margin-bottom: 20px; cursor: pointer; border-bottom: 1px solid #2a2b36 !important; padding-bottom: 15px;">' +
            '<div class="topic-tag" style="background-color: rgba(255, 122, 104, 0.15); color: #ff7a68; padding: 4px 8px; border-radius: 4px; font-size: 12px; margin-right: 12px; flex-shrink: 0;">' + item.category + '</div>' +
            '<div class="topic-info" style="flex: 1;">' +
            '<h3 style="font-size: 16px; font-weight: bold; margin-bottom: 8px; margin-top: 0; color: #fff !important;">' + item.title + '</h3>' +
            '<p style="font-size: 14px; color: #8a8b94; margin: 0;">' + item.desc + '</p>' +
            '</div>' +
            '</div>';
    });

    if (!AppState.hasTopicPackage && list.length > 4) {
        html += `
            <div class="view-more-container" style="text-align:center; padding: 20px 0; position: relative; margin-top: -10px;">
                <div style="position: absolute; top: -60px; left: 0; right: 0; height: 60px; background: linear-gradient(to bottom, rgba(26,27,35,0), rgba(26,27,35,1)); z-index: 1; pointer-events: none;"></div>
                <div style="position: relative; z-index: 2; margin-bottom: 15px; color: #8a8b94; font-size: 12px; display: flex; align-items: center; justify-content: center;">
                    <span style="flex: 1; height: 1px; background: #2a2b36 !important; margin-right: 10px;"></span>
                    付费解锁更多话题
                    <span style="flex: 1; height: 1px; background: #2a2b36 !important; margin-left: 10px;"></span>
                </div>
                <button class="btn-primary" onclick="showPaymentModal('topic_package', 4.9)" style="position: relative; z-index: 2; border-radius: 24px; padding: 12px 30px; font-size: 16px; width: 100%; background: #406eff; color: white; border: none;">
                    🔒 解锁全部话题（¥4.9）
                </button>
            </div>
        `;
    }

    html += '</div>';
    container.innerHTML = html || '<div class="empty-tip" style="text-align: center; color: #8a8b94; padding: 30px;">暂无话题</div>';

    if (paywall) paywall.style.display = 'none';
}

// 筛选话题
window.filterTopic = function(category) {
    renderTopicPage(category);
};

// 渲染知识库预览
function renderKnowledgePreview() {
    var container = document.querySelector('.knowledge-content');
    if (!container) return;

    var html = '';
    var previewData = KnowledgeData; // 只取前3条

    previewData.forEach(function(item) {
        html += '<div class="knowledge-item" onclick="showKnowledgeDetail(' + item.id + ')">' +
            '<div class="knowledge-icon">📚</div>' +
            '<div class="knowledge-info">' +
            '<h3>' + item.title + '</h3>' +
            '<p>' + item.desc + '</p>' +
            '</div>' +
            '</div>';
    });

    container.innerHTML = html;
}

// ==================== 事件绑定 ====================
function initEventListeners() {
    // 使用事件委托绑定所有按钮点击

    // 进入体验按钮
    var enterBtn = document.querySelector('#splash-screen .btn-primary');
    if (enterBtn) {
        enterBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // 检查是否在微信小程序环境中
            if (typeof wx !== 'undefined' && wx.miniProgram) {
                // 如果未登录，跳转到小程序授权页面
                if (!AppState.isLoggedIn && !localStorage.getItem('userPhone')) {
                    wx.miniProgram.navigateTo({
                        url: '/pages/auth/auth'
                    });
                    return;
                }
            }
            
            enterApp();
        });
    }

    // Tab导航
    document.querySelectorAll('.nav-item').forEach(function(item) {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            var tabName = this.getAttribute('data-tab');
            switchTab(tabName);
        });
    });

    // 首页功能卡片
    var diagnosisCard = document.querySelector('.premium-diagnosis-card');
    if (diagnosisCard) {
        diagnosisCard.addEventListener('click', function(e) {
            e.preventDefault();
            startDiagnosis();
        });
    }

    var calcCard = document.querySelectorAll('.feature-card-small');
    calcCard.forEach(function(card, index) {
        card.addEventListener('click', function(e) {
            e.preventDefault();
            if (index === 0) openCalculator();
            else if (index === 1) openEvidenceGuide();
            else if (index === 2) openScriptLibrary();
            else if (index === 3) openKnowledgeBase();
        });
    });

    // 用户头像
    var userAvatar = document.getElementById('user-avatar');
    if (userAvatar) {
        userAvatar.addEventListener('click', function(e) {
            e.preventDefault();
            showUserMenu();
        });
    }

    // 登录按钮
    var loginBtn = document.querySelector('#logged-out-content .btn-primary');
    if (loginBtn) {
        loginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            // 检查是否在微信小程序环境中
            if (typeof wx !== 'undefined' && wx.miniProgram) {
                wx.miniProgram.navigateTo({
                    url: '/pages/auth/auth'
                });
            } else if (window.__wxjs_environment === 'miniprogram') {
                wx.miniProgram.navigateTo({
                    url: '/pages/auth/auth'
                });
            } else {
                showAuthModal();
            }
        });
    }
}

// ==================== 全局函数（绑定到window） ====================

// 进入应用
window.enterApp = function() {
    var splashScreen = document.getElementById('splash-screen');
    var mainContent = document.getElementById('main-content');
    
    // 隐藏引导页
    if (splashScreen) {
        splashScreen.style.display = 'none';
    }
    
    // 显示主界面
    if (mainContent) {
        mainContent.classList.remove('hidden');
        mainContent.style.display = 'block';
    }
    
    // 只有在非小程序环境且未登录时，才弹出模拟授权
    // 小程序环境下，不应该显示模拟授权弹窗
    // if (typeof wx === 'undefined' && !AppState.isLoggedIn) {
    //    showAuthModal();
    // }
};

// Tab切换
window.switchTab = function(tabName) {
    // 更新导航状态
    var navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(function(item) {
        if (item.dataset.tab === tabName) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });

    // 显示对应内容
    var tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(function(content) {
        var contentId = tabName + '-tab';
        if (content.id === contentId) {
            content.classList.add('active');
        } else {
            content.classList.remove('active');
        }
    });

    AppState.currentTab = tabName;
};

// 诊断功能
window.startDiagnosis = function() {
    // 诊断前必须强制检查登录，确保是已授权用户才能使用
    /* if (!checkLogin()) return; disabled */

    // 显示诊断弹窗（底部弹窗形式）
    var modal = document.getElementById('diagnosis-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
        modal.style.zIndex = '1050'; // 确保支付弹窗始终在最上层
    }

    AppState.diagnosisStep = 1;

    // 重置用户数据
    AppState.userData.entryDate = null;
    AppState.userData.leaveDate = null;
    AppState.userData.avgSalary = null;
    AppState.userData.reason = null;
    AppState.userData.notice = null;
    AppState.userData.employmentType = null;
    AppState.userData.companyNature = null;
    AppState.userData.pregnancy = null;
    AppState.calculatedData.years = 0;

    // 重置表单控件
    var entryYear = document.getElementById('entry-year');
    var entryMonth = document.getElementById('entry-month');
    var entryDay = document.getElementById('entry-day');
    var leaveYear = document.getElementById('leave-year');
    var leaveMonth = document.getElementById('leave-month');
    var leaveDay = document.getElementById('leave-day');
    var avgSalary = document.getElementById('avg-salary');
    var entryDate = document.getElementById('entry-date');
    var leaveDate = document.getElementById('leave-date');

    if (entryYear) entryYear.value = '';
    if (entryMonth) entryMonth.value = '';
    if (entryDay) entryDay.value = '';
    if (leaveYear) leaveYear.value = '';
    if (leaveMonth) leaveMonth.value = '';
    if (leaveDay) leaveDay.value = '';
    if (avgSalary) avgSalary.value = '';
    if (entryDate) entryDate.value = '';
    if (leaveDate) leaveDate.value = '';

    // 重置选项选中状态
    var optionItems = document.querySelectorAll('.input-step .option-item');
    optionItems.forEach(function(item) {
        item.classList.remove('selected');
    });

    updateDiagnosisProgress();
    // 初始化日期选择器
    initDatePickers();
};

window.closeDiagnosis = function() {
    // 关闭诊断弹窗
    var modal = document.getElementById('diagnosis-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

window.nextStep = function() {
    // 验证当前步骤是否完成
    if (!validateCurrentStep()) {
        return;
    }

    if (AppState.diagnosisStep < AppState.totalSteps) {
        AppState.diagnosisStep++;
        updateDiagnosisProgress();
    } else {
        submitDiagnosis();
    }
};

// 验证当前步骤是否完成
function validateCurrentStep() {
    var step = AppState.diagnosisStep;
    var isValid = false;
    var errorMsg = '';

    switch(step) {
        case 1: // 入职时间
            var entryDate = document.getElementById('entry-date');
            isValid = entryDate && entryDate.value && entryDate.value.length > 0;
            errorMsg = '请选择入职时间';
            break;
        case 2: // 离职时间
            var leaveDate = document.getElementById('leave-date');
            isValid = leaveDate && leaveDate.value && leaveDate.value.length > 0;
            errorMsg = '请选择离职时间';
            break;
        case 3: // 平均工资
            var salary = document.getElementById('avg-salary');
            isValid = salary && salary.value && parseFloat(salary.value) > 0;
            errorMsg = '请输入平均工资';
            break;
        case 4: // 裁员原因
            isValid = AppState.userData.reason && AppState.userData.reason.length > 0;
            errorMsg = '请选择裁员原因/场景';
            break;
        case 5: // 通知情况
            isValid = AppState.userData.notice && AppState.userData.notice.length > 0;
            errorMsg = '请选择通知情况';
            break;
        case 6: // 用工性质
            isValid = AppState.userData.employmentType && AppState.userData.employmentType.length > 0;
            errorMsg = '请选择用工性质';
            break;
        case 7: // 公司性质
            isValid = AppState.userData.companyNature && AppState.userData.companyNature.length > 0;
            errorMsg = '请选择公司性质';
            break;
        default:
            isValid = true;
    }

    if (!isValid) {
        showToast(errorMsg);
    }

    return isValid;
}

window.prevStep = function() {
    if (AppState.diagnosisStep > 1) {
        AppState.diagnosisStep--;
        updateDiagnosisProgress();
    }
};

function updateDiagnosisProgress() {
    var progressFill = document.getElementById('progress-fill');
    var progressCurrent = document.getElementById('progress-current');
    var prevBtn = document.getElementById('prev-btn');
    var nextBtn = document.getElementById('next-btn');

    if (progressFill) {
        var percentage = (AppState.diagnosisStep / AppState.totalSteps) * 100;
        progressFill.style.width = percentage + '%';
    }
    if (progressCurrent) {
        progressCurrent.textContent = AppState.diagnosisStep;
    }
    if (prevBtn) {
        prevBtn.disabled = AppState.diagnosisStep === 1;
    }
    if (nextBtn) {
        nextBtn.textContent = AppState.diagnosisStep === AppState.totalSteps ? '提交诊断' : '下一步';
    }

    // 显示当前步骤的内容，隐藏其他步骤
    var allSteps = document.querySelectorAll('.input-step');
    allSteps.forEach(function(step) {
        var stepNum = parseInt(step.getAttribute('data-step'));
        if (stepNum === AppState.diagnosisStep) {
            step.classList.add('active');
            step.style.display = 'block';
        } else {
            step.classList.remove('active');
            step.style.display = 'none';
        }
    });
}

window.selectOption = function(field, value, element) {
    AppState.userData[field] = value;

    var parent = element.parentElement;
    if (parent) {
        var options = parent.querySelectorAll('.option-item');
        options.forEach(function(opt) {
            opt.classList.remove('selected');
        });
    }
    element.classList.add('selected');

    setTimeout(function() {
        nextStep();
    }, 300);
};

// 调用后端生成诊断报告
function fetchDiagnosisReport() {
    return new Promise(function(resolve, reject) {
        // 确保 API_BASE_URL 已定义，如果没有则默认为空字符串（相对路径）
        var baseUrl = (typeof API_BASE_URL !== 'undefined') ? API_BASE_URL : '';
        var apiUrl = baseUrl + '/api/diagnosis/generate';
        
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(AppState.userData)
        })
        .then(function(res) { return res.json(); })
        .then(function(data) {
            if (data.success) {
                AppState.currentReport = data.report;
                AppState.reportId = data.report_id;
                console.log('报告生成成功:', data.report);
                resolve(data.report);
            } else {
                console.error('生成报告失败:', data.error);
                reject(data.error);
            }
        })
        .catch(function(err) {
            console.error('生成报告请求失败:', err);
            reject(err);
        });
    });
}

window.submitDiagnosis = function() {
    closeDiagnosis();
    
    // 调用后端生成报告
    // 我们不等待它完成，而是让它在后台运行，因为支付弹窗会给它足够的时间
    fetchDiagnosisReport().catch(function(err) {
        console.log('后台生成报告失败，将降级使用前端计算');
    });
    
    // 如果已登录，直接显示支付弹窗
    showPaymentModal();
};

// 支付功能
window.showPaymentModal = function(productType, price) {
    var modal = document.getElementById('payment-modal');
    if (modal) {
        productType = productType || 'diagnosis_report';
        
        // 恢复真实金额显示
        if (productType === 'diagnosis_report') {
            price = 9.9;
        } else if (productType === 'tool_package' || productType === 'topic_package') {
            price = 4.9;
        } else {
            price = price || 9.9;
        }

        AppState.currentPayment = {
            type: productType,
            price: price
        };
        
        var titleEl = modal.querySelector('.payment-header h2');
        var priceEl = modal.querySelector('.price');
        var btnEl = modal.querySelector('.btn-payment');
        var skipBtn = modal.querySelector('.btn-text');
        
        if (productType === 'tool_package' || productType === 'script') {
            if (titleEl) titleEl.textContent = '解锁谈判话术库';
            if (priceEl) priceEl.textContent = '¥' + price;
            if (btnEl) btnEl.innerHTML = '<span class="btn-icon">💳</span> 立即支付 ¥' + price;
            if (skipBtn) skipBtn.style.display = 'none';
        } else if (productType === 'topic_package' || productType === 'topic') {
            if (titleEl) titleEl.textContent = '解锁热门话题';
            if (priceEl) priceEl.textContent = '¥' + price;
            if (btnEl) btnEl.innerHTML = '<span class="btn-icon">💳</span> 立即支付 ¥' + price;
            if (skipBtn) skipBtn.style.display = 'none';
        } else {
            if (titleEl) titleEl.textContent = '解锁完整报告';
            if (priceEl) priceEl.textContent = '¥' + price;
            if (btnEl) btnEl.innerHTML = '<span class="btn-icon">💳</span> 立即支付 ¥' + price;
            if (skipBtn) skipBtn.style.display = 'block';
        }

        modal.classList.remove('hidden');
        modal.style.display = 'flex';
        modal.style.zIndex = '10000'; // 提高z-index确保在所有弹窗之上
    }
};

window.closePaymentModal = function(e) {
    if (e) {
        e.stopPropagation();
        e.preventDefault();
    }
    var modal = document.getElementById('payment-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

window.completePayment = function() {
    // 获取当前支付信息
    var productType = (AppState.currentPayment && AppState.currentPayment.type) || 'diagnosis_report';
    var price = (AppState.currentPayment && AppState.currentPayment.price) || 9.9;
    
    // 映射到后端productId
    var productId = productType;
    if (productType === 'script') productId = 'tool_package';
    
    // 如果是测试环境，并且后端支持通过传参覆盖价格（测试用），可以在这里加。但通常后端以productId为准。
    // 我们确保UI显示的price和传入后端的逻辑一致即可。

    // 显示加载状态
    var payBtn = document.querySelector('.btn-payment');
    if (payBtn) {
        payBtn.disabled = true;
        payBtn.innerHTML = '处理中...';
    }

    // 先获取openid
    window.getUserOpenId().then(function(openid) {
        // 构建请求URL
        // 如果是本地开发环境，使用localhost；如果是生产环境，使用相对路径或配置的域名
        var apiUrl = API_BASE_URL + '/api/payment/create';
        
        // 调用后端创建支付订单
        fetch(apiUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                productId: productId,
                userId: AppState.userData.phone || 'anonymous',
                openid: openid || ''
            })
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            // 恢复按钮状态
            if (payBtn) {
                payBtn.disabled = false;
                payBtn.innerHTML = '<span class="btn-icon">💳</span> 立即支付 ¥' + price;
            }

            if (data.success) {
                console.log('订单创建成功:', data);
                console.log('支付参数:', data);
                var hasStandardPaymentParams = !!(data.timeStamp && data.nonceStr && data.package && data.paySign);
                var hasVirtualPaymentParams = !!(data.signData && (data.paySig || data.signature));
                var hasOrderForPolling = !!(data.order_id || data.outTradeNo);

                if (hasStandardPaymentParams || hasVirtualPaymentParams || hasOrderForPolling) {
                    // 检测是否在小程序webview中
                    // 方法1: 检查wx.miniProgram
                    // 方法2: 检查URL中是否有openid参数（说明在小程序中）
                    // 方法3: 检查referer（微信小程序webview会设置referer）
                    var searchStr = window.location.search || '';
                    var hasOpenIdInUrl = searchStr.indexOf('openid=') > -1;
                    var hasWx = typeof wx !== 'undefined';
                    var hasMiniProgram = hasWx && wx && typeof wx.miniProgram !== 'undefined';

                    // 如果有openid参数，强制认为在小程序环境中
                    // 即使wx.miniProgram不可用，也可以通过其他方式处理
                    var isInMiniProgram = hasOpenIdInUrl || (hasWx && hasMiniProgram);

                    console.log('========== 微信环境检测 ==========');
                    console.log('hasWx:', hasWx);
                    console.log('wx对象存在:', !!wx);
                    console.log('hasMiniProgram:', hasMiniProgram);
                    console.log('hasOpenIdInUrl:', hasOpenIdInUrl);
                    console.log('isInMiniProgram:', isInMiniProgram);
                    console.log('searchStr:', searchStr);
                    console.log('URL:', window.location.href);
                    console.log('data.timeStamp:', data.timeStamp);
                    console.log('data.package:', data.package);
                    console.log('===================================');

                    // 详细诊断
                    if (!hasWx) {
                        console.log('注意: wx 对象未定义');
                    } else if (!hasMiniProgram) {
                        console.log('注意: wx.miniProgram 不可用');
                    }

                    // 如果有openid参数，优先尝试使用小程序支付
                    // 这是关键：有openid说明确实在小程序环境中
                    if (hasOpenIdInUrl) {
                        console.log('检测到openid，尝试使用小程序支付');

                        // 准备支付数据
                        var payData = {
                            timeStamp: data.timeStamp,
                            nonceStr: data.nonceStr,
                            package: data.package,
                            signType: data.signType || 'MD5',
                            paySign: data.paySign,
                            signData: data.signData,
                            mode: data.mode,
                            paySig: data.paySig || data.signature,
                            signature: data.signature,
                            outTradeNo: data.outTradeNo,
                            orderId: data.order_id || ''
                        };

                        // 构建显示的标题
                        var displayTitle = '解锁完整报告';
                        if (productType === 'script' || productType === 'tool_package') {
                            displayTitle = '解锁谈判话术库';
                        } else if (productType === 'topic_package') {
                            displayTitle = '解锁热门话题';
                        }

                        // 构建跳转URL，携带完整参数
                        var targetUrl = '/pages/payment/payment?data=' + encodeURIComponent(JSON.stringify(payData)) +
                            '&productId=' + encodeURIComponent(productId) +
                            '&type=' + encodeURIComponent(productType) +
                            '&price=' + encodeURIComponent(price) +
                            '&title=' + encodeURIComponent(displayTitle);

                        // 关闭支付弹窗
                        // 这里不需要关闭，跳转后会自动处理
                        // closePaymentModal();

                        // 尝试使用 wx.miniProgram
                        if (wx && wx.miniProgram) {
                            console.log('使用 wx.miniProgram 跳转');
                            wx.miniProgram.navigateTo({
                                url: targetUrl,
                                success: function() {
                                    console.log('跳转支付页面成功');
                                },
                                fail: function(err) {
                                    console.log('wx.miniProgram跳转失败:', err);
                                    // 尝试使用URL scheme
                                    handlePaymentFallback(payData);
                                }
                            });
                        } else {
                            // wx.miniProgram不可用，使用备用方案
                            console.log('wx.miniProgram不可用，使用备用方案');
                            handlePaymentFallback(payData);
                        }

                        // 添加支付状态检查
                        setupPaymentStatusCheck(data.order_id || '', productType);

                        return;
                    }

                    // 优先使用 wx.miniProgram，如果可用
                    if (hasMiniProgram && wx && wx.miniProgram) {
                        // 在小程序webview中，跳转到小程序支付页面
                        console.log('检测到小程序环境，跳转到支付页面');
                        // 将支付参数传递给小程序支付页面
                        var payData = {
                            timeStamp: data.timeStamp,
                            nonceStr: data.nonceStr,
                            package: data.package,
                            signType: data.signType || 'MD5',
                            paySign: data.paySign,
                            signData: data.signData,
                            mode: data.mode,
                            paySig: data.paySig || data.signature,
                            signature: data.signature,
                            outTradeNo: data.outTradeNo,
                            orderId: data.order_id || ''
                        };

                        // 构建显示的标题
                        var displayTitle = '解锁完整报告';
                        if (productType === 'script' || productType === 'tool_package') {
                            displayTitle = '解锁谈判话术库';
                        } else if (productType === 'topic_package') {
                            displayTitle = '解锁热门话题';
                        }

                        // 构建跳转URL，携带完整参数
                        var targetUrl = '/pages/payment/payment?data=' + encodeURIComponent(JSON.stringify(payData)) +
                            '&productId=' + encodeURIComponent(productId) +
                            '&type=' + encodeURIComponent(productType) +
                            '&price=' + encodeURIComponent(price) +
                            '&title=' + encodeURIComponent(displayTitle);

                        // 关闭支付弹窗，准备跳转
                        closePaymentModal();

                        // 跳转到小程序支付页面
                        wx.miniProgram.navigateTo({
                            url: targetUrl,
                            success: function() {
                                console.log('跳转支付页面成功');
                            },
                            fail: function(err) {
                                console.log('跳转支付页失败:', err);
                                alert('支付页面跳转失败，请重试');
                                // 恢复按钮状态
                                if (payBtn) {
                                    payBtn.disabled = false;
                                    payBtn.innerHTML = '<span class="btn-icon">💳</span> 立即支付 ¥' + price;
                                }
                            }
                        });

                        // 监听用户从支付页面返回
                        // 添加一个定时器检查支付结果
                        setupPaymentStatusCheck(data.order_id || '', productType);

                        return; // 结束处理，不执行后面的代码
                    } else if (typeof wx !== 'undefined' && wx.requestPayment && hasStandardPaymentParams) {
                        // 微信外部浏览器环境，直接调起支付
                        console.log('微信浏览器环境，直接调起支付');
                        
                        // 先启动轮询（确保支付回调能被捕获）
                        setupPaymentStatusCheck(data.order_id || '', productType);
                        
                        wx.requestPayment({
                            timeStamp: data.timeStamp,
                            nonceStr: data.nonceStr,
                            package: data.package,
                            signType: data.signType || 'MD5',
                            paySign: data.paySign,
                            success: function(res) {
                                console.log('JSAPI支付回调成功:', res);
                                closePaymentModal();
                                handlePaymentSuccess(productType);
                            },
                            fail: function(err) {
                                console.log('JSAPI支付失败/取消:', err);
                                
                                // 如果是用户取消支付
                                if (err.errMsg && (err.errMsg.indexOf('cancel') > -1 || err.errMsg.indexOf('取消') > -1)) {
                                    console.log('用户取消支付');
                                    // 对于诊断报告，跳转到简易版
                                    if (productType === 'diagnosis_report' && !AppState.hasDiagnosisReport) {
                                        skipPayment();
                                        return;
                                    }
                                } else {
                                    alert('支付失败: ' + (err.errMsg || '未知错误'));
                                }
                            }
                        });
                    } else {
                        // 非微信环境，模拟支付成功
                        console.log('非微信环境，模拟支付成功');
                        closePaymentModal();
                        handlePaymentSuccess(productType);
                        alert('（非微信环境，模拟支付成功）');
                    }
                } else {
                    // 模拟支付成功（非微信环境）
                    console.log('非微信环境，模拟支付成功');
                    closePaymentModal();
                    handlePaymentSuccess(productType);
                    alert('（非微信环境，模拟支付成功）');
                }
            } else {
                console.error('订单创建失败:', data.error);
                alert('支付创建失败: ' + (data.error || '请重试'));
            }
        })
        .catch(function(error) {
            console.error('支付请求失败:', error);
            // 恢复按钮状态
            if (payBtn) {
                payBtn.disabled = false;
                payBtn.innerHTML = '<span class="btn-icon">💳</span> 立即支付 ¥' + price;
            }
            // 显示更详细的错误信息
            var errorMsg = '支付请求失败，请检查网络';
            if (error.message) {
                errorMsg += '\n错误: ' + error.message;
            }
            if (error.stack) {
                console.log('详细错误:', error.stack);
            }
            alert(errorMsg);
        });
    });
};

window.skipPayment = function() {
    closePaymentModal();
    
    // 只有诊断报告才允许跳过支付查看简易版
    var productType = (AppState.currentPayment && AppState.currentPayment.type) || 'diagnosis_report';
    if (productType !== 'diagnosis_report') {
        return;
    }

    // 保存报告到历史记录，标记为未付费
    saveReportToHistory(false);
    showReport();
};

// 支付失败时的备用方案
window.handlePaymentFallback = function(payData) {
    console.log('执行备用支付方案');

    // 显示提示信息
    alert('正在跳转支付页面...如未跳转，请重试');

    // 尝试使用微信URL scheme
    try {
        var appId = 'wx466f15c87c417cb8';
        var payDataStr = encodeURIComponent(JSON.stringify(payData));

        // 尝试使用小程序页面URL scheme
        // 这个scheme需要在微信小程序后台配置
        var schemeUrl = 'weixin://dl/business/?appid=' + appId + '&path=pages/payment/payment&query=data=' + payDataStr;
        console.log('尝试URL scheme:', schemeUrl);

        // 尝试跳转
        window.location.href = schemeUrl;
    } catch (e) {
        console.log('URL scheme跳转失败:', e);
    }
};

// 设置支付状态检查
window.setupPaymentStatusCheck = function(orderId, productType) {
    if (!orderId) {
        console.log('没有orderId，跳过支付状态检查');
        return;
    }

    // 默认为诊断报告
    productType = productType || 'diagnosis_report';

    console.log('设置支付状态检查, orderId:', orderId, 'productType:', productType);

    var checkCount = 0;
    var maxChecks = 15; // 轮询15次
    var checkInterval;

    var checkPaymentStatus = function() {
        if (checkCount >= maxChecks) {
            clearInterval(checkInterval);
            console.log('支付状态检查超时');
            return;
        }
        
        checkCount++;
        window.getUserOpenId().then(function(openid) {
            var apiUrl = API_BASE_URL + '/api/payment/query/' + orderId;
            fetch(apiUrl, {
                method: 'GET',
                credentials: 'include'
            })
            .then(function(res) { return res.json(); })
            .then(function(statusData) {
                console.log('支付状态检查结果 (' + checkCount + '/' + maxChecks + '):', statusData);
                if (statusData.success && (statusData.paid || statusData.status === 'paid')) {
                    console.log('检测到支付已成功');
                    clearInterval(checkInterval);
                    handlePaymentSuccess(productType);
                }
            })
            .catch(function(err) {
                console.log('查询支付状态失败:', err);
            });
        });
    };

    // 立即检查一次
    checkPaymentStatus();
    
    // 设置持续轮询，每2秒查一次
    checkInterval = setInterval(checkPaymentStatus, 2000);

    // 设置页面可见性监听 (用户从小程序支付完返回H5时触发)
    var visibilityHandler = function() {
        if (document.visibilityState === 'visible') {
            console.log('页面重新可见，立即检查支付状态');
            // 重新开始轮询，增加检查次数
            checkCount = 0;
            checkPaymentStatus();
        }
    };
    
    document.addEventListener('visibilitychange', visibilityHandler);
    
    // 30秒后自动移除监听器，避免内存泄漏
    setTimeout(function() {
        clearInterval(checkInterval);
        document.removeEventListener('visibilitychange', visibilityHandler);
    }, 30000);
};

// 渲染报告中的证据清单
function renderEvidenceListInReport() {
    var container = document.getElementById('evidence-list');
    if (!container) return;

    // 优先使用后端生成的数据
    var evidenceData = (AppState.currentReport && AppState.currentReport.evidence_checklist) || [
        { title: '劳动合同原件', desc: '证明劳动关系和工资标准' },
        { title: '工资条/银行流水', desc: '证明实际工资收入' },
        { title: '社保公积金缴费记录', desc: '证明缴费基数和年限' },
        { title: '考勤记录', desc: '证明工作时间加班情况' },
        { title: '解除劳动合同通知', desc: '证明离职原因和时间' }
    ];

    var html = '';
    evidenceData.forEach(function(item, index) {
        html += '<div class="evidence-item">' +
            '<div class="evidence-number">' + (index + 1) + '</div>' +
            '<div class="evidence-text">' +
            '<div class="evidence-title">' + item.title + '</div>' +
            '<div class="evidence-desc">' + item.desc + '</div>' +
            '</div>' +
            '</div>';
    });

    container.innerHTML = html;
}

// 渲染谈判话术
function renderNegotiationTips() {
    var container = document.querySelector('.script-box .script-content');
    if (!container) return;
    
    // 如果没有后端数据，不做修改（保留HTML中的默认内容）
    if (!AppState.currentReport || !AppState.currentReport.negotiation_tips || AppState.currentReport.negotiation_tips.length === 0) {
        return;
    }
    
    var tips = AppState.currentReport.negotiation_tips;
    var html = '<p><strong>建议回复：</strong></p>';
    
    // 将数组转换为列表或段落
    if (Array.isArray(tips)) {
        tips.forEach(function(tip) {
            html += '<p>• ' + tip + '</p>';
        });
    } else {
        html += '<p>' + tips + '</p>';
    }
    
    container.innerHTML = html;
    
    // 同时更新场景描述（如果后端没给，暂时不更新或隐藏）
    // var scenarioEl = document.querySelector('.script-scenario');
    // if (scenarioEl) scenarioEl.textContent = '场景：根据您的离职原因分析';
}

// 报告功能
// 计算工龄补偿系数 N
window.calculateNValue = function(entryStr, leaveStr) {
    if (!entryStr || !leaveStr) return 0;
    
    var parseDate = function(str) {
        if (typeof str === 'string') {
            var parts = str.split('-');
            if (parts.length === 3) {
                return new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
            }
        }
        return new Date(str);
    };
    
    var entry = parseDate(entryStr);
    var leave = parseDate(leaveStr);
    
    if (isNaN(entry.getTime()) || isNaN(leave.getTime())) return 0;
    
    // 1. 计算整年
    var years = leave.getFullYear() - entry.getFullYear();
    
    // 构造当年的入职纪念日
    var currentAnniversary = new Date(leave.getFullYear(), entry.getMonth(), entry.getDate());
    
    // 处理入职日是闰年2.29的情况
    if (entry.getMonth() === 1 && entry.getDate() === 29) {
        var isLeap = (leave.getFullYear() % 4 === 0 && leave.getFullYear() % 100 !== 0) || (leave.getFullYear() % 400 === 0);
        if (!isLeap) {
             currentAnniversary = new Date(leave.getFullYear(), 1, 28);
        }
    }
    
    // 如果离职日期早于当年的入职纪念日，说明不满这一整年
    if (leave < currentAnniversary) {
        years--;
    }
    
    // 计算上一周年的日期（即最近的一个入职纪念日）
    var lastAnniversaryYear = leave < currentAnniversary ? leave.getFullYear() - 1 : leave.getFullYear();
    var lastAnniversary = new Date(lastAnniversaryYear, entry.getMonth(), entry.getDate());
    
    // 处理入职日是闰年2.29的情况
    if (entry.getMonth() === 1 && entry.getDate() === 29) {
        var isLeapLast = (lastAnniversaryYear % 4 === 0 && lastAnniversaryYear % 100 !== 0) || (lastAnniversaryYear % 400 === 0);
        if (!isLeapLast) {
            lastAnniversary = new Date(lastAnniversaryYear, 1, 28);
        }
    }
    
    // 计算 lastAnniversary + 6 months
    var targetYear = lastAnniversary.getFullYear();
    var targetMonth = lastAnniversary.getMonth() + 6;
    if (targetMonth > 11) {
        targetYear++;
        targetMonth -= 12;
    }
    
    // 获取目标月份的最大天数
    var daysInTargetMonth = new Date(targetYear, targetMonth + 1, 0).getDate();
    // 目标日期取 min(原日期, 月末)
    var originalDay = entry.getDate();
    // 如果入职是2.29，而当年不是闰年，lastAnniversary已经是2.28了。加6个月（8月）应该是8.29还是8.28？
    // 通常按对日。8月有31天，所以应该是8.29。
    // 如果入职是8.31，加6个月是2月，应该是2.28/2.29。
    var targetDay = Math.min(originalDay, daysInTargetMonth);
    
    var sixMonthsDate = new Date(targetYear, targetMonth, targetDay);
    
    var n = years;
    
    if (leave >= sixMonthsDate) {
        n += 1;
    } else if (leave > lastAnniversary) {
        n += 0.5;
    }
    
    return n;
};

window.showReport = function() {
    var modal = document.getElementById('report-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
        modal.style.zIndex = '1040'; // 确保在其他列表元素之上
    }

    // 计算工龄
    var years = 0;
    if (AppState.userData.entryDate && AppState.userData.leaveDate) {
        try {
            var entryParts = AppState.userData.entryDate.split('-');
            var leaveParts = AppState.userData.leaveDate.split('-');
            var entryTime = new Date(parseInt(entryParts[0]), parseInt(entryParts[1]) - 1, parseInt(entryParts[2]));
            var leaveTime = new Date(parseInt(leaveParts[0]), parseInt(leaveParts[1]) - 1, parseInt(leaveParts[2]));
            var diffTime = leaveTime - entryTime;
            years = diffTime / (1000 * 60 * 60 * 24 * 365);
            years = Math.round(years * 10) / 10; // 保留一位小数
            if (years < 0) years = 0;
        } catch (e) {
            console.error('计算工龄出错:', e);
            years = 0;
        }
    }

    // 更新全局状态
    AppState.calculatedData.years = years;

    // 计算赔偿金
    var avgSalary = parseFloat(AppState.userData.avgSalary) || 0;
    // 使用新逻辑计算 N
    var n = calculateNValue(AppState.userData.entryDate, AppState.userData.leaveDate);
    var n1 = n + 1; // N+1
    var twoN = n * 2; // 2N

    var entryEl = document.getElementById('report-entry');
    var leaveEl = document.getElementById('report-leave');
    var yearsEl = document.getElementById('report-years');
    var salaryEl = document.getElementById('report-salary');

    // 更新赔偿金额显示
    var nEl = document.getElementById('comp-n');
    var n1El = document.getElementById('comp-n1');
    var twoNEl = document.getElementById('comp-2n');

    if (entryEl) entryEl.textContent = AppState.userData.entryDate || '-';
    if (leaveEl) leaveEl.textContent = AppState.userData.leaveDate || '-';
    if (yearsEl) yearsEl.textContent = years + '年';
    if (salaryEl) salaryEl.textContent = '¥' + avgSalary.toLocaleString();

    // 显示计算结果
    if (nEl) {
        nEl.textContent = avgSalary > 0 && years > 0 ? '¥' + (avgSalary * n).toLocaleString() : '-';
    }
    if (n1El) {
        n1El.textContent = avgSalary > 0 && years > 0 ? '¥' + (avgSalary * n1).toLocaleString() : '-';
    }
    if (twoNEl) {
        twoNEl.textContent = avgSalary > 0 && years > 0 ? '¥' + (avgSalary * twoN).toLocaleString() : '-';
    }

    // 根据是否已付费，控制内容显示
    // 检查是否有诊断报告权限
    var hasAccess = AppState.hasDiagnosisReport;
    
    // 控制区域显示
    var evidenceSection = document.getElementById('report-evidence-section');
    var scriptSection = document.getElementById('report-script-section');
    var timelineSection = document.getElementById('report-timeline-section');
    
    // 控制按钮显示
    var saveBtn = document.getElementById('save-report-btn');
    var payBtn = document.getElementById('pay-report-btn');

    if (hasAccess) {
        // 已付费：显示所有内容
        if (evidenceSection) evidenceSection.style.display = 'block';
        if (scriptSection) scriptSection.style.display = 'block';
        if (timelineSection) timelineSection.style.display = 'block';
        
        // 生成详细内容
        renderEvidenceListInReport();
        renderNegotiationTips();
        
        // 显示保存按钮，隐藏支付按钮
        if (saveBtn) saveBtn.style.display = 'block';
        if (payBtn) payBtn.style.display = 'none';
    } else {
        // 未付费：隐藏详细内容
        if (evidenceSection) evidenceSection.style.display = 'none';
        if (scriptSection) scriptSection.style.display = 'none';
        if (timelineSection) timelineSection.style.display = 'none';
        
        // 隐藏保存按钮，显示支付按钮
        if (saveBtn) saveBtn.style.display = 'none';
        if (payBtn) payBtn.style.display = 'block';
        
        // 确保支付按钮文字正确
        if (payBtn) {
            payBtn.innerHTML = '<span class="btn-icon">💳</span> 支付9.9 查看完整报告';
        }
    }

    // 显示孕期信息
    var pregnancyRow = document.getElementById('report-pregnancy-row');
    var pregnancyEl = document.getElementById('report-pregnancy');
    if (AppState.userData.pregnancy && AppState.userData.pregnancy !== 'no') {
        var pregnancyText = {
            'pregnant': '孕期',
            'maternity': '产期',
            'nursing': '哺乳期'
        };
        if (pregnancyRow) pregnancyRow.style.display = 'flex';
        if (pregnancyEl) pregnancyEl.textContent = pregnancyText[AppState.userData.pregnancy] || '-';
    } else if (pregnancyRow) {
        pregnancyRow.style.display = 'none';
    }

    // 违法解除劳动合同判定
    var isIllegalTermination = false;
    var illegalReason = '';
    var legalReferences = [];
    var highlightType = 'none'; // 'n', 'n1', '2n', 'none'

    // 判定逻辑：基于用户输入判断是否为违法解除
    if (AppState.userData.pregnancy && AppState.userData.pregnancy !== 'no') {
        // 三期女职工被辞退属于违法解除
        isIllegalTermination = true;
        highlightType = '2n';
        var periodText = {
            'pregnant': '孕期',
            'maternity': '产期',
            'nursing': '哺乳期'
        };
        illegalReason = '根据《劳动合同法》第四十二条，您处于' + periodText[AppState.userData.pregnancy] + '，用人单位不得依据第四十条、第四十一条规定解除劳动合同';
        legalReferences = [
            { article: '第四十二条', content: '劳动者有下列情形之一的，用人单位不得依照本法第四十条、第四十一条的规定解除劳动合同：（四）女职工在孕期、产期、哺乳期的' },
            { article: '第八十七条', content: '用人单位违反本法规定解除或者终止劳动合同的，应当依照本法第四十七条规定的经济补偿标准的二倍向劳动者支付赔偿金' }
        ];
    } else if (AppState.userData.reason === 'unknown') {
        // 其他问题/无明确理由，可能违法解除
        isIllegalTermination = true;
        highlightType = '2n';
        illegalReason = '公司未能提供合法解除劳动合同的依据';
        legalReferences = [
            { article: '第八十七条', content: '用人单位违反本法规定解除或者终止劳动合同的，应当依照本法第四十七条规定的经济补偿标准的二倍向劳动者支付赔偿金' }
        ];
    } else if (AppState.userData.reason && AppState.userData.notice) {
        // 有合理理由（裁员/合同到期等），判断是否提前30天通知
        // 根据《劳动合同法》第40条：提前30天通知或支付一个月工资代通知金
        if (AppState.userData.notice === 'yes') {
            // 已提前30天通知 - 合法解除
            highlightType = 'n';
            isIllegalTermination = false;
        } else {
            // 未提前30天通知（包括口头、未通知、不确定）- 需要支付代通知金
            highlightType = 'n1';
            isIllegalTermination = false;
        }
    }

    // 更新违法解除显示
    var illegalWarningEl = document.getElementById('illegal-warning');
    var illegalReasonEl = document.getElementById('illegal-reason');
    var legalRefEl = document.getElementById('legal-reference');
    var compensationTable = document.querySelector('.compensation-table');

    // 首先清除所有高亮
    if (nEl) {
        nEl.classList.remove('highlight');
        nEl.parentElement.classList.remove('highlight');
    }
    if (n1El) {
        n1El.classList.remove('highlight');
        n1El.parentElement.classList.remove('highlight');
    }
    if (twoNEl) {
        twoNEl.classList.remove('highlight');
        twoNEl.parentElement.classList.remove('highlight');
    }
    if (compensationTable) {
        compensationTable.parentElement.classList.remove('illegal-termination');
    }

    if (isIllegalTermination) {
        // 显示违法解除警告
        if (illegalWarningEl) illegalWarningEl.style.display = 'block';
        if (illegalReasonEl) illegalReasonEl.textContent = illegalReason;

        // 显示法律依据
        if (legalRefEl) {
            var refHtml = '';
            legalReferences.forEach(function(ref) {
                refHtml += '<div class="legal-ref-item">';
                refHtml += '<div class="legal-ref-article">《劳动合同法》第' + ref.article + '条</div>';
                refHtml += '<div class="legal-ref-content">' + ref.content + '</div>';
                refHtml += '</div>';
            });
            legalRefEl.innerHTML = refHtml;
        }

        // 高亮显示2N赔偿
        if (twoNEl) {
            twoNEl.classList.add('highlight');
            twoNEl.parentElement.classList.add('highlight');
        }

        // 添加红色警示背景
        if (compensationTable) {
            compensationTable.parentElement.classList.add('illegal-termination');
        }
    } else {
        // 合法解除：根据是否提前30天通知高亮对应赔偿金
        if (illegalWarningEl) illegalWarningEl.style.display = 'none';

        if (highlightType === 'n') {
            // 提前30天通知 - 高亮N
            if (nEl) {
                nEl.classList.add('highlight');
                nEl.parentElement.classList.add('highlight');
            }
        } else if (highlightType === 'n1') {
            // 未提前30天通知 - 高亮N+1
            if (n1El) {
                n1El.classList.add('highlight');
                n1El.parentElement.classList.add('highlight');
            }
        } else if (highlightType === '2n') {
            // 违法解除 - 高亮2N
            if (twoNEl) {
                twoNEl.classList.add('highlight');
                twoNEl.parentElement.classList.add('highlight');
            }
            if (illegalWarningEl) illegalWarningEl.style.display = 'block';
            if (illegalReasonEl) illegalReasonEl.textContent = illegalReason;
            if (legalRefEl) {
                var refHtml = '';
                legalReferences.forEach(function(ref) {
                    refHtml += '<div class="legal-ref-item">';
                    refHtml += '<div class="legal-ref-article">《劳动合同法》第' + ref.article + '条</div>';
                    refHtml += '<div class="legal-ref-content">' + ref.content + '</div>';
                    refHtml += '</div>';
                });
                legalRefEl.innerHTML = refHtml;
            }
            if (compensationTable) {
                compensationTable.parentElement.classList.add('illegal-termination');
            }
        }
    }

    // 更新风险评估
    updateRiskAssessment(isIllegalTermination, highlightType);

    // 渲染证据清单
    renderEvidenceListInReport();

    // 再次强制检查按钮状态（防止被其他逻辑覆盖）
    var hasAccess = AppState.hasDiagnosisReport;
    var saveBtn = document.getElementById('save-report-btn');
    var payBtn = document.getElementById('pay-report-btn');
    var evidenceSection = document.querySelector('.report-section:nth-child(4)'); // 证据清单
    var scriptSection = document.querySelector('.report-section:nth-child(5)');   // 谈判话术
    var timelineSection = document.querySelector('.report-section:nth-child(6)'); // 时间轴

    if (hasAccess) {
        if (saveBtn) saveBtn.style.display = 'block';
        if (payBtn) payBtn.style.display = 'none';
        if (evidenceSection) evidenceSection.style.display = 'block';
        if (scriptSection) scriptSection.style.display = 'block';
        if (timelineSection) timelineSection.style.display = 'block';
    } else {
        if (saveBtn) saveBtn.style.display = 'none';
        if (payBtn) payBtn.style.display = 'block';
        if (evidenceSection) evidenceSection.style.display = 'none';
        if (scriptSection) scriptSection.style.display = 'none';
        if (timelineSection) timelineSection.style.display = 'none';
    }
};

// 更新风险评估
function updateRiskAssessment(isIllegalTermination, highlightType) {
    var riskLevelEl = document.getElementById('risk-level');
    var riskDescEl = document.getElementById('risk-description');

    if (!riskLevelEl || !riskDescEl) return;

    var riskLevel = 'medium';
    var riskDesc = '';
    var reason = AppState.userData.reason || '';
    var notice = AppState.userData.notice || '';

    if (isIllegalTermination) {
        // 违法解除 - 高风险
        riskLevel = 'high';
        riskDescEl.className = 'risk-description risk-high';

        if (AppState.userData.pregnancy && AppState.userData.pregnancy !== 'no') {
            // 三期女职工
            var periodText = {
                'pregnant': '孕期',
                'maternity': '产期',
                'nursing': '哺乳期'
            };
            riskDesc = '根据《劳动合同法》第四十二条，您处于' + periodText[AppState.userData.pregnancy] + '，用人单位不得解除劳动合同。公司在此期间辞退您属于违法解除，您有权要求2N赔偿金。';
        } else if (reason === 'unknown') {
            // 无明确理由
            riskDesc = '公司未能提供合法解除劳动合同的依据，属于违法解除。您有权要求2N赔偿金。建议立即收集相关证据，包括劳动合同、工资流水、沟通记录等。';
        } else {
            riskDesc = '公司解除劳动合同存在程序违法或实体违法，属于违法解除。您有权要求2N赔偿金。建议通过劳动仲裁维护合法权益。';
        }
    } else {
        // 合法解除
        riskLevelEl.className = 'risk-level';

        if (highlightType === 'n') {
            // 提前30天通知 - 低风险
            riskLevel = 'low';
            riskDescEl.className = 'risk-description risk-low';
            riskDesc = '公司已提前30天通知您离职，程序合法。根据《劳动合同法》第四十六条、第四十七条，您可获得N个月工资的经济补偿。建议与公司确认补偿金额后签署解除协议。';
        } else if (highlightType === 'n1') {
            // 未提前30天通知 - 中风险
            riskLevel = 'medium';
            riskDescEl.className = 'risk-description risk-medium';
            riskDesc = '公司未提前30天书面通知，根据《劳动合同法》第四十条，您可获得N+1个月工资的赔偿（含一个月代通知金）。建议与公司协商确认补偿金额，如协商不成可申请劳动仲裁。';
        } else {
            // 默认
            riskLevel = 'medium';
            riskDescEl.className = 'risk-description';
            riskDesc = '根据您提供的情况，建议与公司协商确定补偿金额。如有争议可申请劳动仲裁维护权益。';
        }
    }

    // 更新风险等级显示
    var levelText = {
        'low': '低风险',
        'medium': '中风险',
        'high': '高风险'
    };
    var levelIcon = {
        'low': '✅',
        'medium': '⚠️',
        'high': '🔴'
    };

    riskLevelEl.className = 'risk-level ' + riskLevel;
    riskLevelEl.textContent = levelIcon[riskLevel] + ' ' + levelText[riskLevel];
    riskDescEl.textContent = riskDesc;
}

window.closeReport = function() {
    var modal = document.getElementById('report-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 平均工资计算器
window.openCalculator = function() {
    /* if (!checkLogin()) return; disabled */
    var modal = document.getElementById('calculator-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
    // 重置表单
    resetCalculatorForm();
};

window.resetCalculatorForm = function() {
    // 重置步骤
    var section1 = document.getElementById('calc-section-1');
    var section2 = document.getElementById('calc-section-2');
    var step1 = document.getElementById('step1-indicator');
    var step2 = document.getElementById('step2-indicator');

    if (section1) section1.classList.remove('hidden');
    if (section2) section2.classList.add('hidden');
    if (step1) step1.classList.add('active');
    if (step2) step2.classList.remove('active');

    // 清空输入
    document.getElementById('calc-basic-salary').value = '';
    document.getElementById('calc-performance').value = '';
    document.getElementById('calc-yearend').value = '';
    document.getElementById('calc-overtime').value = '';
    document.getElementById('calc-allowance').value = '';

    // 取消所有"无"选项
    document.getElementById('calc-performance-none').checked = false;
    document.getElementById('calc-yearend-none').checked = false;
    document.getElementById('calc-overtime-none').checked = false;
    document.getElementById('calc-allowance-none').checked = false;
};

window.closeCalculator = function() {
    var modal = document.getElementById('calculator-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

window.calculateAvgSalary = function() {
    // 计算平均工资
    var basicSalary = parseFloat(document.getElementById('calc-basic-salary').value) || 0;
    var performance = document.getElementById('calc-performance-none').checked ? 0 : (parseFloat(document.getElementById('calc-performance').value) || 0);
    var yearend = document.getElementById('calc-yearend-none').checked ? 0 : (parseFloat(document.getElementById('calc-yearend').value) || 0);
    var overtime = document.getElementById('calc-overtime-none').checked ? 0 : (parseFloat(document.getElementById('calc-overtime').value) || 0);
    var allowance = document.getElementById('calc-allowance-none').checked ? 0 : (parseFloat(document.getElementById('calc-allowance').value) || 0);

    // 年终奖按月折算
    var yearendMonthly = yearend / 12;

    // 计算月平均工资
    var monthlyAvg = basicSalary + performance + yearendMonthly + overtime + allowance;

    // 保存到状态
    AppState.calculatedData.avgSalary = monthlyAvg;
    AppState.calculatedData.basicSalary = basicSalary;
    AppState.calculatedData.performance = performance;
    AppState.calculatedData.yearend = yearend;
    AppState.calculatedData.overtime = overtime;
    AppState.calculatedData.allowance = allowance;
};

window.toggleSalaryInput = function(type) {
    var checkbox = document.getElementById('calc-' + type + '-none');
    var input = document.getElementById('calc-' + type);

    if (checkbox && input) {
        if (checkbox.checked) {
            input.value = '';
            input.disabled = true;
        } else {
            input.disabled = false;
        }
        calculateAvgSalary();
    }
};

window.goToSalaryStep2 = function() {
    // 验证第一步是否填写
    var basicSalary = document.getElementById('calc-basic-salary');
    if (!basicSalary || !basicSalary.value) {
        alert('请先输入基本工资');
        return;
    }

    var section1 = document.getElementById('calc-section-1');
    var section2 = document.getElementById('calc-section-2');
    var step1 = document.getElementById('step1-indicator');
    var step2 = document.getElementById('step2-indicator');

    if (section1) section1.classList.add('hidden');
    if (section2) section2.classList.remove('hidden');
    if (step1) step1.classList.remove('active');
    if (step2) step2.classList.add('active');
};

window.goToSalaryStep1 = function() {
    var section1 = document.getElementById('calc-section-1');
    var section2 = document.getElementById('calc-section-2');
    var step1 = document.getElementById('step1-indicator');
    var step2 = document.getElementById('step2-indicator');

    if (section1) section1.classList.remove('hidden');
    if (section2) section2.classList.add('hidden');
    if (step1) step1.classList.add('active');
    if (step2) step2.classList.remove('active');
};

window.finishSalaryCalculation = function() {
    // 计算最终平均工资
    calculateAvgSalary();

    var avgSalary = AppState.calculatedData.avgSalary || 0;

    if (avgSalary <= 0) {
        alert('请至少输入基本工资');
        return;
    }

    // 关闭计算器弹窗
    closeCalculator();

    // 显示计算结果弹窗
    showSalaryResultModal();
};

function showSalaryResultModal() {
    var avgSalary = AppState.calculatedData.avgSalary || 0;
    var basicSalary = AppState.calculatedData.basicSalary || 0;
    var performance = AppState.calculatedData.performance || 0;
    var yearend = AppState.calculatedData.yearend || 0;
    var overtime = AppState.calculatedData.overtime || 0;
    var allowance = AppState.calculatedData.allowance || 0;

    var yearendMonthly = yearend / 12;

    // 创建结果弹窗
    var modalHtml = `
        <div id="salary-result-modal" class="modal" style="display:flex;">
            <div class="modal-content calc-result-modal">
                <div class="modal-header">
                    <h2>📊 平均工资计算结果</h2>
                    <button class="modal-close" onclick="closeSalaryResultModal()">×</button>
                </div>
                <div class="calc-result-content">
                    <div class="salary-summary">
                        <div class="salary-main">
                            <span class="salary-label">过去12个月平均工资</span>
                            <span class="salary-value">¥${Math.round(avgSalary).toLocaleString()}</span>
                            <span class="salary-unit">/月</span>
                        </div>
                        <p class="salary-note">💡 根据《劳动合同法》第四十七条，经济补偿金按劳动者离职前12个月平均工资计算</p>
                    </div>

                    <div class="salary-breakdown">
                        <h4>工资构成明细</h4>
                        <div class="breakdown-item">
                            <span class="breakdown-label">基本工资</span>
                            <span class="breakdown-value">¥${basicSalary.toLocaleString()}/月</span>
                        </div>
                        ${performance > 0 ? '<div class="breakdown-item"><span class="breakdown-label">绩效工资</span><span class="breakdown-value">¥' + performance.toLocaleString() + '/月</span></div>' : ''}
                        ${yearend > 0 ? '<div class="breakdown-item"><span class="breakdown-label">年终奖（折算）</span><span class="breakdown-value">¥' + Math.round(yearendMonthly).toLocaleString() + '/月</span></div>' : ''}
                        ${overtime > 0 ? '<div class="breakdown-item"><span class="breakdown-label">加班费</span><span class="breakdown-value">¥' + overtime.toLocaleString() + '/月</span></div>' : ''}
                        ${allowance > 0 ? '<div class="breakdown-item"><span class="breakdown-label">补助补贴</span><span class="breakdown-value">¥' + allowance.toLocaleString() + '/月</span></div>' : ''}
                    </div>

                    <div class="salary-tip">
                        <h4>💡 温馨提示</h4>
                        <p>根据《劳动合同法实施条例》第二十七条，月工资包括计时工资、计件工资、奖金、津贴和补贴等劳动报酬。</p>
                        <p>如果您的工资超过当地上年度职工月平均工资的3倍，经济补偿金将按3倍封顶计算。</p>
                    </div>

                    <div class="salary-cta">
                        <p class="cta-text">想知道自己能拿多少赔偿金？</p>
                        <button class="btn-primary" onclick="goToDiagnosis()">
                            📝 开始诊断计算赔偿金
                        </button>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn-secondary" onclick="closeSalaryResultModal()">关闭</button>
                </div>
            </div>
        </div>
    `;

    // 移除已存在的弹窗
    var existingModal = document.getElementById('salary-result-modal');
    if (existingModal) {
        existingModal.remove();
    }

    // 添加弹窗到页面
    document.body.insertAdjacentHTML('beforeend', modalHtml);
}

window.closeSalaryResultModal = function() {
    var modal = document.getElementById('salary-result-modal');
    if (modal) {
        modal.remove();
    }
};

window.goToDiagnosis = function() {
    // 关闭结果弹窗
    closeSalaryResultModal();

    // 将平均工资填入用户数据
    if (AppState.calculatedData.avgSalary) {
        AppState.userData.avgSalary = AppState.calculatedData.avgSalary;
    }

    // 跳转到首页并触发诊断
    switchTab('home');
    setTimeout(function() {
        startDiagnosis();
    }, 300);
};

// 旧版计算结果弹窗（保留用于兼容）
function showCalcResultModal() {
    // 创建结果弹窗
    var modalHtml = `
        <div id="calc-result-modal" class="modal" style="display:flex;">
            <div class="modal-content calc-result-modal">
                <div class="modal-header">
                    <h2>🧮 计算结果</h2>
                    <button class="modal-close" onclick="closeCalcResultModal()">×</button>
                </div>
                <div class="calc-result-content">
                    <div class="result-summary">
                        <div class="result-item">
                            <div class="result-label">平均工资</div>
                            <div class="result-value" id="result-avg">¥0/月</div>
                        </div>
                        <div class="result-item">
                            <div class="result-label">工龄</div>
                            <div class="result-value" id="result-years">0年</div>
                        </div>
                    </div>
                    <div class="result-detail">
                        <div class="result-row">
                            <span class="result-type">N (经济补偿)</span>
                            <span class="result-amount" id="result-n">¥0</span>
                        </div>
                        <div class="result-row highlight">
                            <span class="result-type">N+1 (代通知金)</span>
                            <span class="result-amount" id="result-n1">¥0</span>
                        </div>
                        <div class="result-row">
                            <span class="result-type">2N (违法解除)</span>
                            <span class="result-amount" id="result-2n">¥0</span>
                        </div>
                    </div>
                    <p class="result-note">* 2N适用于违法解除劳动合同的情况</p>
                </div>
                <div class="modal-footer">
                    <button class="btn-primary" onclick="closeCalcResultModal()">确定</button>
                </div>
            </div>
        </div>
    `;

    // 移除已存在的弹窗
    var existingModal = document.getElementById('calc-result-modal');
    if (existingModal) {
        existingModal.remove();
    }

    // 添加弹窗到页面
    document.body.insertAdjacentHTML('beforeend', modalHtml);

    // 填充计算结果
    var avgSalary = document.getElementById('calc-display-avg');
    var years = document.getElementById('calc-years');
    var n = document.getElementById('calc-n');
    var n1 = document.getElementById('calc-n1');
    var twoN = document.getElementById('calc-2n');

    document.getElementById('result-avg').textContent = avgSalary ? avgSalary.textContent : '¥0/月';
    document.getElementById('result-years').textContent = years ? years.textContent : '0年';
    document.getElementById('result-n').textContent = n ? n.textContent : '¥0';
    document.getElementById('result-n1').textContent = n1 ? n1.textContent : '¥0';
    document.getElementById('result-2n').textContent = twoN ? twoN.textContent : '¥0';
}

window.closeCalcResultModal = function() {
    var modal = document.getElementById('calc-result-modal');
    if (modal) {
        modal.remove();
    }
};

// 证据清单 - 渲染函数（免费）
function renderEvidenceList() {
    var container = document.getElementById('evidence-library-content');
    if (!container) return;

    // 证据清单改为免费，全部显示
    var html = '';

    EvidenceData.forEach(function(item) {
        html += '<div class="evidence-detail-item">' +
            '<div class="evidence-detail-header">' +
            '<div class="evidence-icon">📄</div>' +
            '<div class="evidence-title-row">' +
            '<h3>' + item.title + '</h3>' +
            '<p class="evidence-desc">' + item.desc + '</p>' +
            '</div>' +
            '</div>' +
            '<div class="evidence-content">' + item.content + '</div>' +
            '</div>';
    });

    container.innerHTML = html;
}

// 打开证据清单（免费）
window.openEvidenceGuide = function() {
    /* if (!checkLogin()) return; disabled */
    console.log('打开证据清单（免费）');
    var modal = document.getElementById('evidence-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }

    // 渲染证据清单内容
    renderEvidenceList();
};

// 关闭证据清单
window.closeEvidenceGuide = function() {
    var modal = document.getElementById('evidence-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 话术库
window.openScriptLibrary = function() {
    var modal = document.getElementById('script-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }

    // 控制支付墙显示/隐藏
    var paywall = document.getElementById('script-paywall');
    if (paywall) paywall.style.display = 'none';

    renderScriptList();
};

window.closeScriptLibrary = function() {
    var modal = document.getElementById('script-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 解锁工具包（包括话术库、证据清单等）
window.unlockToolPackage = function(type) {
    /* if (!checkLogin()) return; disabled */

    // 设置支付成功后的回调处理
    var currentType = type || 'tool_package';
    
    // 直接调用支付弹窗，不关闭当前功能弹窗，让支付弹窗覆盖在上面
    showPaymentModal(currentType, 4.9);
};



// 知识库
window.openKnowledgeBase = function() {
    var modal = document.getElementById('knowledge-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
    renderKnowledgeList();
};

window.closeKnowledgeModal = function() {
    var modal = document.getElementById('knowledge-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 知识库展开/收起
window.toggleKnowledge = function(element) {
    // 切换展开/收起状态
    if (element) {
        element.classList.toggle('expanded');
    }
};

// 初始化知识库点击事件
function initKnowledgeEvents() {
    var knowledgeItems = document.querySelectorAll('.knowledge-item');
    knowledgeItems.forEach(function(item) {
        item.addEventListener('click', function(e) {
            // 切换展开状态
            this.classList.toggle('expanded');
        });
    });
}

// 在打开知识库时初始化事件
window.openKnowledgeBase = function() {
    var modal = document.getElementById('knowledge-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
    renderKnowledgeList();
    // 重新绑定点击事件
    setTimeout(function() {
        initKnowledgeEvents();
    }, 100);
};

// 别名
window.closeKnowledge = window.closeKnowledgeModal;

function renderKnowledgeList() {
    var container = document.querySelector('.knowledge-content');
    if (!container) return;

    var html = '';
    var data = KnowledgeData;

    data.forEach(function(item) {
        html += '<div class="knowledge-item" onclick="toggleKnowledge(this)">' +
            '<div class="knowledge-title">' +
            '<span class="knowledge-icon">📖</span>' +
            '<span>' + item.title + '</span>' +
            '<span class="knowledge-arrow">▼</span>' +
            '</div>' +
            '<div class="knowledge-answer">' +
            '<p>' + item.content + '</p>' +
            '</div>' +
            '</div>';
    });

    

    container.innerHTML = html;
}

// 热门话题（这个重复定义被删除了）

window.closeTopicList = function() {
    var page = document.getElementById('topic-list-page');
    if (page) {
        page.classList.add('hidden');
        page.style.display = 'none';
    }
};

// 关闭话题详情
window.closeTopicDetail = function() {
    var modal = document.getElementById('topic-detail-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 用户菜单
window.showUserMenu = function() {
    var modal = document.getElementById('user-menu-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
};

window.closeUserMenu = function() {
    var modal = document.getElementById('user-menu-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

window.showEditProfile = function() {
    closeUserMenu();
    var modal = document.getElementById('edit-profile-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';

        // 填充用户信息到编辑表单
        var avatarEl = document.getElementById('edit-avatar');
        var usernameEl = document.getElementById('edit-username');
        var phoneEl = document.getElementById('edit-phone');

        if (avatarEl) {
            var avatarUrl = AppState.userData.avatar;
            var isUrl = avatarUrl && (avatarUrl.startsWith('http') || avatarUrl.startsWith('data:'));
            
            if (isUrl) {
                avatarEl.innerHTML = '<img src="' + avatarUrl + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
            } else {
                avatarEl.textContent = avatarUrl || '👤';
            }
        }
        if (usernameEl) {
            usernameEl.value = AppState.userData.name || '';
        }
        if (phoneEl) {
            phoneEl.value = AppState.userData.phone || '';
        }
    }
};

// 触发选择头像
window.changeAvatar = function() {
    var fileInput = document.getElementById('avatar-input');
    if (fileInput) {
        fileInput.click();
    }
};

// 处理头像文件选择
window.handleAvatarFile = function(input) {
    if (input.files && input.files[0]) {
        var file = input.files[0];
        
        // 限制文件大小 (2MB)
        if (file.size > 2 * 1024 * 1024) {
            alert('图片大小不能超过 2MB');
            return;
        }

        var reader = new FileReader();
        reader.onload = function(e) {
            var base64 = e.target.result;
            
            // 更新编辑框中的头像预览
            var avatarEl = document.getElementById('edit-avatar');
            if (avatarEl) {
                avatarEl.innerHTML = '<img src="' + base64 + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
            }
            
            // 上传到服务器
            // 确保 uploadImageToServer 已定义
            if (typeof uploadImageToServer === 'function') {
                uploadImageToServer(base64, function(url) {
                    if (url) {
                        // 更新全局状态
                        AppState.userData.avatar = url;
                        localStorage.setItem('userAvatar', url);
                        console.log('头像更新成功:', url);
                    } else {
                        // 上传失败，暂时使用base64
                        console.log('头像上传失败，使用本地预览');
                        AppState.userData.avatar = base64;
                        // base64可能太长，不保存到localStorage以免溢出
                    }
                });
            } else {
                console.warn('uploadImageToServer 函数未定义，仅更新本地预览');
                AppState.userData.avatar = base64;
            }
        };
        reader.readAsDataURL(file);
    }
};

window.closeEditProfile = function() {
    var modal = document.getElementById('edit-profile-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

window.saveProfile = function() {
    var username = document.getElementById('edit-username');
    if (username) {
        AppState.userData.name = username.value;
    }
    closeEditProfile();
    updateProfileDisplay();
};

function updateProfileDisplay() {
    var nameEl = document.getElementById('profile-name');
    var phoneEl = document.getElementById('profile-phone');
    var avatarEl = document.getElementById('profile-avatar');
    var headerAvatarEl = document.getElementById('user-avatar');

    var avatarUrl = AppState.userData.avatar;
    var isUrl = avatarUrl && (avatarUrl.startsWith('http') || avatarUrl.startsWith('data:'));

    // 更新个人中心头像
    if (avatarEl) {
        if (isUrl) {
            avatarEl.innerHTML = '<img src="' + avatarUrl + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
        } else {
            avatarEl.textContent = avatarUrl || '👤';
        }
    }

    // 更新首页右上角头像
    if (headerAvatarEl) {
        if (isUrl) {
            headerAvatarEl.innerHTML = '<img src="' + avatarUrl + '" style="width:100%;height:100%;object-fit:cover;border-radius:50%;">';
        } else {
            headerAvatarEl.textContent = avatarUrl || '👤';
        }
    }

    if (nameEl) nameEl.textContent = AppState.userData.name || '用户';
    if (phoneEl) phoneEl.textContent = AppState.userData.phone || '-';
}

// 登录
window.showAuthModal = function() {
    // 如果在小程序环境，直接跳转到原生授权页，不显示H5模拟弹窗
    if (typeof wx !== 'undefined' && wx.miniProgram) {
        wx.miniProgram.navigateTo({
            url: '/pages/auth/auth'
        });
        return;
    }

    var modal = document.getElementById('wechat-auth-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
};

window.handleWechatAllow = function() {
    // 隐藏当前弹窗
    var modal = document.getElementById('wechat-auth-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }

    // 检查是否在微信小程序环境中
    if (typeof wx !== 'undefined' && wx.miniProgram) {
        // 跳转到小程序授权页面
        wx.miniProgram.navigateTo({
            url: '/pages/auth/auth'
        });
        
        // 隐藏当前弹窗
        var modal = document.getElementById('wechat-auth-modal');
        if (modal) {
            modal.classList.add('hidden');
            modal.style.display = 'none';
        }
    } else {
        // 非小程序环境，提示无法获取
        alert('请在微信小程序中使用此功能');
        
        // 隐藏当前弹窗
        var modal = document.getElementById('wechat-auth-modal');
        if (modal) {
            modal.classList.add('hidden');
            modal.style.display = 'none';
        }
    }
};

window.handleWechatReject = function() {
    var modal = document.getElementById('wechat-auth-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
    // 记录用户拒绝授权，后续功能中再次提示
    AppState.hasRejectedAuth = true;
};

function updateLoginState() {
    var loggedInContent = document.getElementById('logged-in-content');
    var loggedOutContent = document.getElementById('logged-out-content');

    if (AppState.isLoggedIn) {
        if (loggedInContent) loggedInContent.style.display = 'block';
        if (loggedOutContent) loggedOutContent.style.display = 'none';
    } else {
        if (loggedInContent) loggedInContent.style.display = 'none';
        if (loggedOutContent) loggedOutContent.style.display = 'block';
    }
}

window.handleLogout = function() {
    AppState.isLoggedIn = false;
    AppState.userData = {
        phone: '',
        name: '',
        avatar: '👤',
        entryDate: null,
        leaveDate: null,
        avgSalary: null,
        reason: null,
        notice: null,
        employmentType: null,
        companyNature: null
    };

    // 清除本地存储的登录状态
    localStorage.removeItem('userPhone');
    localStorage.removeItem('userName');
    localStorage.removeItem('userAvatar');
    localStorage.removeItem('has_authed');
    localStorage.removeItem('just_authed');

    // 如果在小程序环境中，也通知小程序清除状态
    if (typeof wx !== 'undefined' && wx.miniProgram) {
        wx.miniProgram.postMessage({ data: { action: 'logout' } });
    }

    closeUserMenu();
    updateLoginState();
    updateProfileDisplay();
    
    // 切换回首页
    switchTab('home');
    showToast('已退出登录');
};

// 分享
window.showShareModal = function() {
    var modal = document.getElementById('share-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
};

window.closeShareModal = function() {
    var modal = document.getElementById('share-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

window.downloadReport = function() {
    // 获取报告弹窗内容
    var reportModal = document.querySelector('.report-modal');
    if (!reportModal) {
        alert('未找到报告内容');
        return;
    }

    // 显示加载提示
    var loadingToast = document.createElement('div');
    loadingToast.id = 'download-loading';
    loadingToast.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(0,0,0,0.8);color:#fff;padding:20px 40px;border-radius:10px;z-index:10000;';
    loadingToast.textContent = '正在生成报告图片...';
    document.body.appendChild(loadingToast);

    // 保存原始样式
    var originalOverflow = reportModal.style.overflow;
    var originalMaxHeight = reportModal.style.maxHeight;
    var originalPosition = reportModal.style.position;
    var originalHeight = reportModal.style.height;
    var originalTop = reportModal.style.top;
    var originalTransform = reportModal.style.transform;

    // 隐藏按钮和提示（只保存报告内容）
    var reportActions = reportModal.querySelector('.report-actions');
    var privacyNotice = reportModal.querySelector('.privacy-notice');
    var originalActionsDisplay = reportActions ? reportActions.style.display : '';
    var originalPrivacyDisplay = privacyNotice ? privacyNotice.style.display : '';
    if (reportActions) reportActions.style.display = 'none';
    if (privacyNotice) privacyNotice.style.display = 'none';

    // 临时修改样式以捕获完整内容
    reportModal.style.overflow = 'visible';
    reportModal.style.maxHeight = 'none';
    reportModal.style.position = 'relative';
    reportModal.style.height = 'auto';
    reportModal.style.top = '0';
    reportModal.style.transform = 'none';

    // 等待DOM更新
    setTimeout(function() {
        // 使用html2canvas生成图片
        if (typeof html2canvas !== 'undefined') {
            html2canvas(reportModal, {
                scale: 2, // 提高清晰度
                backgroundColor: '#0A0A0F',
                logging: false,
                useCORS: true,
                height: reportModal.scrollHeight, // 设置为实际内容高度
                width: reportModal.scrollWidth
            }).then(function(canvas) {
                // 恢复原始样式
                reportModal.style.overflow = originalOverflow;
                reportModal.style.maxHeight = originalMaxHeight;
                reportModal.style.position = originalPosition;
                reportModal.style.height = originalHeight;
                reportModal.style.top = originalTop;
                reportModal.style.transform = originalTransform;

                // 恢复按钮和提示显示
                if (reportActions) reportActions.style.display = originalActionsDisplay;
                if (privacyNotice) privacyNotice.style.display = originalPrivacyDisplay;

                // 获取图片数据URL
                var imageDataUrl = canvas.toDataURL('image/png');

                // 检查是否在微信小程序环境中
                if (isWeChatMiniProgram()) {
                    // 在小程序环境中，通过消息通道发送图片数据给小程序
                    saveImageInMiniProgram(imageDataUrl, loadingToast);
                } else if (isWeChatBrowser()) {
                    // 在微信浏览器环境中，尝试使用微信JS-SDK保存到相册
                    saveImageToWeChatAlbum(imageDataUrl, loadingToast);
                } else {
                // 非微信环境，使用浏览器下载
                var link = document.createElement('a');
                link.download = '裁神来了_维权诊断报告_' + new Date().toISOString().slice(0, 10) + '.png';
                link.href = imageDataUrl;
                link.click();

                // 移除加载提示
                var toast = document.getElementById('download-loading');
                if (toast) document.body.removeChild(toast);

                showToast('报告已保存到相册！');
            }
        }).catch(function(err) {
            console.error('生成报告图片失败:', err);
            var toast = document.getElementById('download-loading');
            if (toast) document.body.removeChild(toast);
            alert('生成报告失败，请重试');
        });
    } else {
        // 恢复原始样式
        reportModal.style.overflow = originalOverflow;
        reportModal.style.maxHeight = originalMaxHeight;
        reportModal.style.position = originalPosition;
        reportModal.style.height = originalHeight;
        reportModal.style.top = originalTop;
        reportModal.style.transform = originalTransform;

        // 恢复按钮和提示显示
        if (reportActions) reportActions.style.display = originalActionsDisplay;
        if (privacyNotice) privacyNotice.style.display = originalPrivacyDisplay;

        var toast = document.getElementById('download-loading');
        if (toast) document.body.removeChild(toast);
        alert('报告生成功能暂不可用，请确保网络连接');
    }
    }); // 关闭setTimeout

    // 保存报告到历史记录（默认未付费，因为这是下载时保存）
    saveReportToHistory(false);
};

// 保存报告到历史记录
// isPaid: true 表示已付费，false 表示未付费
function saveReportToHistory(isPaid) {
    var reportData = {
        id: 'report_' + Date.now(),
        date: new Date().toLocaleDateString('zh-CN'),
        time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
        userData: Object.assign({}, AppState.userData),
        calculatedData: Object.assign({}, AppState.calculatedData),
        isPaid: isPaid || false
    };

    // 添加到历史记录
    AppState.savedReports.unshift(reportData);

    // 限制最多保存10条记录
    if (AppState.savedReports.length > 10) {
        AppState.savedReports.pop();
    }

    // 保存到localStorage
    try {
        localStorage.setItem('caisheen_reports', JSON.stringify(AppState.savedReports));
    } catch (e) {
        console.log('localStorage不可用');
    }

    // 渲染报告列表
    renderSavedReports();

    // 更新状态 - 仅当支付成功时才设为true，否则为false（简易版）
    AppState.hasDiagnosisReport = isPaid;
}

// 从localStorage加载报告历史
function loadSavedReports() {
    try {
        var saved = localStorage.getItem('caisheen_reports');
        if (saved) {
            AppState.savedReports = JSON.parse(saved);
            renderSavedReports();
        }
    } catch (e) {
        console.log('localStorage不可用');
    }
}

// 渲染"我的报告"列表
function renderSavedReports() {
    var container = document.getElementById('report-list');
    if (!container) return;

    if (AppState.savedReports.length === 0) {
        container.innerHTML = '<div class="empty-tip">暂无报告记录</div>';
        return;
    }

    var html = '';
    AppState.savedReports.forEach(function(report) {
        var reasonText = getReasonText(report.userData.reason);
        // 根据是否付费显示不同状态
        var statusText = report.isPaid ? '已完成' : '待评估';
        var statusClass = report.isPaid ? 'status-completed' : 'status-pending';

        html += '<div class="report-card" onclick="viewReport(\'' + report.id + '\')">' +
            '<div class="report-card-header">' +
            '<span class="report-date">' + report.date + '</span>' +
            '<span class="report-status ' + statusClass + '">' + statusText + '</span>' +
            '</div>' +
            '<div class="report-card-body">' +
            '<div class="report-info-row">' +
            '<span class="info-label">入职时间：</span>' +
            '<span class="info-value">' + (report.userData.entryDate || '-') + '</span>' +
            '</div>' +
            '<div class="report-info-row">' +
            '<span class="info-label">离职时间：</span>' +
            '<span class="info-value">' + (report.userData.leaveDate || '-') + '</span>' +
            '</div>' +
            '<div class="report-info-row">' +
            '<span class="info-label">离职原因：</span>' +
            '<span class="info-value">' + reasonText + '</span>' +
            '</div>' +
            '</div>' +
            '<div class="report-card-footer" style="padding: 10px 15px; border-top: 1px solid #333; text-align: right;">' +
            '<button class="btn-text delete-btn" onclick="event.stopPropagation(); deleteReport(\'' + report.id + '\')" style="color: #ef4444; font-size: 13px;">🗑️ 删除</button>' +
            '</div>' +
            '</div>';
    });

    container.innerHTML = html;
}

// 删除报告
window.deleteReport = function(reportId) {
    if (!confirm('确定要删除这条报告吗？')) {
        return;
    }
    
    // 过滤掉要删除的报告
    AppState.savedReports = AppState.savedReports.filter(function(r) {
        return r.id !== reportId;
    });
    
    // 保存到localStorage
    try {
        localStorage.setItem('caisheen_reports', JSON.stringify(AppState.savedReports));
    } catch (e) {
        console.log('localStorage不可用');
    }
    
    // 重新渲染
    renderSavedReports();
};

// 获取离职原因文本
function getReasonText(reason) {
    var reasonMap = {
        'organization': '被裁员/辞退',
        'demotion': '调岗降薪',
        'noncompete': '竞业限制',
        'bonus': '年终奖问题',
        'contract': '合同到期/不续签',
        'unknown': '其他问题'
    };
    return reasonMap[reason] || '待评估';
}

// 查看历史报告
window.viewReport = function(reportId) {
    var report = AppState.savedReports.find(function(r) {
        return r.id === reportId;
    });

    if (!report) {
        alert('报告不存在');
        return;
    }

    // 恢复报告数据到AppState
    AppState.userData = Object.assign({}, report.userData);
    AppState.calculatedData = Object.assign({}, report.calculatedData);
    
    // 设置付费状态，以便showReport显示正确内容
    // 如果报告记录中标记为已付费，则临时设置全局状态
    if (report.isPaid) {
        AppState.hasDiagnosisReport = true;
    } else {
        AppState.hasDiagnosisReport = false;
    }

    // 显示报告
    showReport();
};

// 检测是否在微信浏览器中
function isWeChatBrowser() {
    var ua = navigator.userAgent.toLowerCase();
    return ua.indexOf('micromessenger') > -1;
}

// 检测是否在微信小程序webview中
function isWeChatMiniProgram() {
    var ua = navigator.userAgent.toLowerCase();
    // 小程序webview的user-agent会包含miniprogram
    return ua.indexOf('miniprogram') > -1;
}

// 小程序环境中保存图片到相册
function saveImageInMiniProgram(imageDataUrl, loadingToast) {
    // 移除加载提示，显示保存提示
    if (loadingToast) {
        loadingToast.textContent = '正在保存到相册...';
    }

    // 检查wx.miniProgram是否存在
    if (typeof wx !== 'undefined' && wx.miniProgram) {
        try {
            // 先上传图片到服务器，获取URL后再跳转小程序
            uploadImageToServer(imageDataUrl, function(imageUrl) {
                if (imageUrl) {
                    // 上传成功，跳转到小程序页面
                    wx.miniProgram.navigateTo({
                        url: '/pages/save-image/save-image?imageUrl=' + encodeURIComponent(imageUrl)
                    });
                } else {
                    // 上传失败，尝试直接传递base64
                    tryDirectTransfer(imageDataUrl, loadingToast);
                }
            });
        } catch (e) {
            console.error('跳转小程序页面失败:', e);
            showWeChatAuthGuide(loadingToast, imageDataUrl);
        }
    } else {
        // 无法使用小程序API，显示提示
        if (loadingToast) {
            loadingToast.textContent = '小程序环境异常';
        }
        setTimeout(function() {
            alert('系统错误：无法进入小程序环境，请确保在微信小程序中打开');
        }, 500);
    }
}

// 上传图片到服务器
function uploadImageToServer(base64Data, callback) {
    // 移除data:image/png;base64,前缀
    var base64WithoutPrefix = base64Data.replace(/^data:image\/\w+;base64,/, '');

    console.log('开始上传图片，数据长度:', base64WithoutPrefix.length);

    fetch(API_BASE_URL + '/api/upload/image', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            image: base64WithoutPrefix
        })
    })
    .then(function(res) {
        console.log('上传响应状态:', res.status);
        return res.json();
    })
    .then(function(data) {
        console.log('上传响应数据:', data);
        if (data.success && data.url) {
            console.log('上传成功，图片URL:', data.url);
            callback(data.url);
        } else {
            console.error('上传失败，错误:', data.error);
            callback(null);
        }
    })
    .catch(function(err) {
        console.error('上传图片失败:', err);
        callback(null);
    });
}

// 尝试直接传递（备用方案）
function tryDirectTransfer(imageDataUrl, loadingToast) {
    var dataLength = encodeURIComponent(imageDataUrl).length;
    console.log('图片数据长度:', dataLength);

    // 尝试直接传递
    if (dataLength < 1000000) { // 1MB以内可以尝试
        wx.miniProgram.navigateTo({
            url: '/pages/save-image/save-image?imageData=' + encodeURIComponent(imageDataUrl)
        });
    } else {
        // 数据太大，提示用户
        if (loadingToast) {
            loadingToast.textContent = '报告内容过长';
        }
        setTimeout(function() {
            alert('报告内容过长，无法保存。');
        }, 1000);
    }
}

// ==================== 接收小程序消息 ====================
// (此处的重复定义已被移除，统一在文件末尾处理)

// 处理支付成功后的解锁逻辑
window.handlePaymentSuccess = function(productType) {
    console.log('处理支付成功，解锁产品类型:', productType);

    if (productType === 'tool_package' || productType === 'script' || productType === 'evidence' || productType === 'knowledge') {
        // 解锁话术库/证据清单/知识库
        AppState.hasToolPackage = true;
        persistUnlockState();

        // 确保关闭支付收银台弹窗
        closePaymentModal();

        // 隐藏对应的支付墙
        var paywallId = productType + '-paywall';
        var paywall = document.getElementById(paywallId);
        if (paywall) {
            paywall.style.display = 'none';
        }
        
        // 隐藏通用的工具包支付墙
        var toolPaywall = document.getElementById('tool_package-paywall');
        if (toolPaywall) {
            toolPaywall.style.display = 'none';
        }

        // 重新渲染内容
        if (productType === 'script' || productType === 'tool_package') {
            // 如果是在主页点击解锁，重新渲染主页模块
            renderScriptList();
            
            // 如果打开了话术库弹窗，重新渲染弹窗内容
            var modal = document.getElementById('script-modal');
            if (modal && !modal.classList.contains('hidden')) {
                if (typeof renderScriptModalContent === 'function') {
                    renderScriptModalContent();
                } else {
                    renderScriptList();
                }
            } else {
                // 如果没有打开，支付成功后自动打开话术库弹窗
                if (typeof openScriptLibrary === 'function') {
                    openScriptLibrary();
                }
            }
        } else if (productType === 'evidence') {
            renderEvidenceList();
            var modal = document.getElementById('evidence-modal');
            if (modal && !modal.classList.contains('hidden')) {
                if (typeof renderEvidenceModalContent === 'function') {
                    renderEvidenceModalContent();
                } else {
                    renderEvidenceList();
                }
            } else {
                if (typeof openEvidenceChecklist === 'function') {
                    openEvidenceChecklist();
                } else if (typeof openEvidenceGuide === 'function') {
                    openEvidenceGuide();
                }
            }
        } else if (productType === 'knowledge') {
            renderKnowledgeList();
            setTimeout(function() {
                initKnowledgeEvents();
            }, 100);
            var modal = document.getElementById('knowledge-modal');
            if (!modal || modal.classList.contains('hidden')) {
                if (typeof openKnowledgeBase === 'function') {
                    openKnowledgeBase();
                }
            }
        }

        showToast('解锁成功！');
    } else if (productType === 'topic_package' || productType === 'topic') {
        // 解锁热门话题
        AppState.hasTopicPackage = true;
        persistUnlockState();

        // 关闭支付收银台弹窗
        closePaymentModal();

        // 关闭话题付费弹窗
        var topicPayModal = document.getElementById('topic-pay-modal');
        if (topicPayModal) {
            topicPayModal.classList.add('hidden');
            topicPayModal.style.display = 'none';
        }

        // 隐藏话题支付墙
        var topicPaywall = document.getElementById('topic-paywall');
        if (topicPaywall) {
            topicPaywall.style.display = 'none';
        }

        // 重新渲染话题列表
        renderTopicPage('全部');

        // 跳转到功能界面并显示全部话题
        if (typeof goToTopicList === 'function') {
            goToTopicList();
        }

        // 如果有记录当前点击的话题ID，且在话题列表页面之上再打开话题详情
        if (AppState.currentTopicId && typeof showTopicDetail === 'function') {
            // 延迟一下，等列表渲染完毕再弹详情
            setTimeout(function() {
                showTopicDetail(AppState.currentTopicId);
            }, 300);
        }

        showToast('热门话题已解锁！');
    } else if (productType === 'diagnosis_report') {
        // 诊断报告支付成功
        AppState.hasDiagnosisReport = true;
        saveReportToHistory(true);
        // 如果是从支付弹窗过来的，需要确保弹窗关闭
        closePaymentModal();
        showReport();
    }
};

// 立即检查URL参数，如果有授权信息或者从小程序引导页过来，预先标记
(function() {
    try {
        var urlParams = new URLSearchParams(window.location.search);
        // 如果是从小程序引导页过来(from_miniprogram=1)，或者已经有授权参数，直接跳过H5的引导页
        if (urlParams.get('phone') || urlParams.get('auth_rejected') || urlParams.get('from_miniprogram') === '1') {
            document.documentElement.classList.add('auth-callback-mode');
            // 添加内联样式强制隐藏引导页（如果在head中执行可能body还未解析，但在app.js加载时应该已有部分DOM）
            var style = document.createElement('style');
            style.innerHTML = '#splash-screen { display: none !important; } #main-content { display: block !important; }';
            document.head.appendChild(style);
        }
    } catch(e) {}
})();

// 页面加载完成后初始化
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
        initMiniProgramMessageListener();
        checkUrlParamsForAuth();
        checkUrlParamsForPaymentResult();
    });
} else {
    initMiniProgramMessageListener();
    checkUrlParamsForAuth();
    checkUrlParamsForPaymentResult();
}

// 检查URL参数中的授权信息（从从授权页返回）
function checkUrlParamsForAuth() {
    try {
        var urlParams = new URLSearchParams(window.location.search);
        var phone = urlParams.get('phone');
        var authRejected = urlParams.get('auth_rejected');
        
        // 如果有 phone 参数（授权成功），或者 auth_rejected 参数（授权拒绝），都进入主应用
        if (phone || authRejected) {
            console.log('检测到授权状态:', phone ? '成功' : '拒绝');
            
            // 标记为已从授权返回，不再显示引导页
            try {
                localStorage.setItem('has_authed', 'true');
            } catch(e) {}
            
            if (phone) {
                // 授权成功：清除拒绝标记
                localStorage.removeItem('auth_rejected');
                
                // 自动登录
                AppState.isLoggedIn = true;
                AppState.userData.phone = phone;
                // 设置默认昵称和头像（模拟微信资料）
                AppState.userData.name = '微信用户'; 
                // 使用 HTTPS 协议的头像链接
                AppState.userData.avatar = 'https://thirdwx.qlogo.cn/mmopen/vi_32/POgEwh4mIHO4nibH0KlMECNjjGxQUq24ZEaGT4poC6icRiccVGKSyXwibcPq4BWmiaIGuG1icwxaQX6grC9VemZoJ8rg/132';
                
                // 保存到localStorage
                try {
                    localStorage.setItem('userPhone', phone);
                    localStorage.setItem('userName', AppState.userData.name);
                    localStorage.setItem('userAvatar', AppState.userData.avatar);
                } catch (e) {}

                // 更新UI (必须在保存数据之后调用)
                updateProfileDisplay();
                updateLoginState();
            } else if (authRejected) {
                // 授权拒绝：记录拒绝状态
                localStorage.setItem('auth_rejected', 'true');
                AppState.hasRejectedAuth = true;
            }
            
            // 确保进入主应用界面，隐藏引导页
            // 使用requestAnimationFrame确保DOM更新
            requestAnimationFrame(function() {
                var splashScreen = document.getElementById('splash-screen');
                var mainContent = document.getElementById('main-content');
                
                // 强制隐藏引导页
                if (splashScreen) {
                    splashScreen.style.cssText = 'display: none !important;';
                    splashScreen.classList.add('hidden');
                }
                
                // 强制显示主界面
                if (mainContent) {
                    mainContent.style.cssText = 'display: block !important;';
                    mainContent.classList.remove('hidden');
                }
                
                // 调用enterApp确保逻辑完整，但避免重复操作
                if (typeof enterApp === 'function') {
                    // 覆盖enterApp中的检查逻辑，确保它不会重新显示引导页
                    window.enterApp();
                }
            });
            
            // 处理之前的待办事项（如果有的话）
            if (phone) {
                var pendingAction = AppState.pendingAction || localStorage.getItem('pendingAction');
                
                // 清除pendingAction，防止重复触发
                AppState.pendingAction = null;
                localStorage.removeItem('pendingAction');

                if (pendingAction === 'submitDiagnosis') {
                    // 延迟一点时间，确保UI已渲染
                    setTimeout(function() {
                        // 确保诊断弹窗是打开的，并且有数据
                        // 如果是从头开始，可能需要恢复之前的输入，这里简单处理直接显示支付
                        // 实际业务中可能需要持久化存储未提交的诊断数据
                        showPaymentModal();
                    }, 500);
                }
            }
        } else {
            // 如果本地记录过已授权，即使没有参数也尝试隐藏引导页
            var hasAuthed = false;
            try {
                hasAuthed = localStorage.getItem('has_authed') === 'true';
            } catch(e) {}
            
            if (hasAuthed || localStorage.getItem('userPhone')) {
                requestAnimationFrame(function() {
                    var splashScreen = document.getElementById('splash-screen');
                    var mainContent = document.getElementById('main-content');
                    if (splashScreen) {
                        splashScreen.style.cssText = 'display: none !important;';
                        splashScreen.classList.add('hidden');
                    }
                    if (mainContent) {
                        mainContent.style.cssText = 'display: block !important;';
                        mainContent.classList.remove('hidden');
                    }
                });
            }
        }
    } catch (e) {
        console.error('解析URL参数失败:', e);
    }
}

function checkUrlParamsForPaymentResult() {
    try {
        var urlParams = new URLSearchParams(window.location.search);
        var status = urlParams.get('payment_status');
        var productType = urlParams.get('payment_product');
        var message = urlParams.get('payment_message');
        if (status === 'success' && productType && typeof handlePaymentSuccess === 'function') {
            handlePaymentSuccess(productType);
        } else if (status === 'fail') {
            showToast('支付失败：' + (message || '请重试'));
        }
        if (status) {
            urlParams.delete('payment_status');
            urlParams.delete('payment_product');
            urlParams.delete('payment_message');
            urlParams.delete('payment_ts');
            var cleanQuery = urlParams.toString();
            var cleanUrl = window.location.pathname + (cleanQuery ? '?' + cleanQuery : '');
            window.history.replaceState({}, '', cleanUrl);
        }
    } catch (e) {}
}

// 微信环境保存图片到相册
function saveImageToWeChatAlbum(imageDataUrl, loadingToast) {
    // 移除加载提示，显示保存提示
    if (loadingToast) {
        loadingToast.textContent = '正在保存到相册...';
    }

    // 检查wx对象是否存在（微信JS-SDK）
    if (typeof wx !== 'undefined' && wx.downloadImage) {
        // 尝试将base64转换为临时文件并保存
        // 首先上传到服务器获取临时media_id（这里简化处理）
        // 在实际项目中，需要先调用wx.uploadImage上传到微信服务器

        // 方法1：尝试直接使用wx.saveImageToPhotosAlbum
        wx.ready(function() {
            // 检查授权状态
            wx.getSetting({
                success: function(res) {
                    if (!res.authSetting['scope.writePhotosAlbum']) {
                        // 未授权，请求授权
                        wx.authorize({
                            scope: 'scope.writePhotosAlbum',
                            success: function() {
                                // 授权成功，保存图片
                                saveBase64ImageToAlbum(imageDataUrl);
                            },
                            fail: function(err) {
                                // 授权失败，引导用户手动打开
                                showWeChatAuthGuide(loadingToast, imageDataUrl);
                            }
                        });
                    } else {
                        // 已授权，直接保存
                        saveBase64ImageToAlbum(imageDataUrl);
                    }
                },
                fail: function(err) {
                    showWeChatAuthGuide(loadingToast, imageDataUrl);
                }
            });
        });

        wx.error(function(err) {
            console.error('微信JS-SDK错误:', err);
            // JS-SDK不可用，使用提示方式
            showWeChatAuthGuide(loadingToast, imageDataUrl);
        });
    } else {
        // 微信JS-SDK不可用，提供提示
        showWeChatAuthGuide(loadingToast, imageDataUrl);
    }
}

// 保存base64图片到微信相册（需要先上传到服务器获取URL）
function saveBase64ImageToAlbum(imageDataUrl) {
    // 由于wx.saveImageToPhotosAlbum需要本地临时文件路径
    // 我们需要将base64转换为blob，然后保存

    // 显示成功提示
    var toast = document.getElementById('download-loading');
    if (toast) document.body.removeChild(toast);

    // 检测环境并给出相应提示
    if (isWeChatMiniProgram()) {
        // 微信小程序环境
        showToast('图片已生成，请长按保存到相册');
    } else {
        // 微信浏览器环境
        showToast('长按图片保存到相册');
    }

    // 创建图片供用户查看和保存
    showSaveImagePreview(imageDataUrl);
}

// 显示微信授权引导
function showWeChatAuthGuide(loadingToast, imageDataUrl) {
    // 移除加载提示
    if (loadingToast) {
        var toast = document.getElementById('download-loading');
        if (toast) document.body.removeChild(toast);
    }

    // 根据环境显示不同的提示文案
    var hintText = isWeChatMiniProgram() ?
        '1. 图片已生成<br>2. 请长按图片 "另存为"<br>3. 选择保存到手机相册' :
        '1. 图片已生成<br>2. 请长按图片选择"保存到相册"<br>3. 或者点击下方按钮重新生成';

    // 创建授权引导弹窗
    var modal = document.createElement('div');
    modal.id = 'wechat-save-guide';
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:9999;display:flex;align-items:center;justify-content:center;';

    modal.innerHTML = '<div style="background:#fff;border-radius:16px;padding:30px;max-width:320px;text-align:center;margin:20px;">' +
        '<h3 style="margin:0 0 15px;font-size:18px;color:#333;">保存到相册</h3>' +
        '<p style="margin:0 0 20px;font-size:14px;color:#666;line-height:1.6;">' + hintText + '</p>' +
        '<div id="save-guide-preview" style="margin:15px 0;"></div>' +
        '<button onclick="closeWeChatSaveGuide()" style="width:100%;padding:12px;background:#07C160;color:#fff;border:none;border-radius:8px;font-size:16px;">我知道了</button>' +
        '</div>';

    document.body.appendChild(modal);

    // 显示图片预览
    setTimeout(function() {
        var preview = document.getElementById('save-guide-preview');
        if (preview) {
            preview.innerHTML = '<img src="' + imageDataUrl + '" style="max-width:100%;border-radius:8px;">';
        }
    }, 100);
}

window.closeWeChatSaveGuide = function() {
    var modal = document.getElementById('wechat-save-guide');
    if (modal) {
        document.body.removeChild(modal);
    }
};

// 显示保存图片预览（供长按保存）
function showSaveImagePreview(imageDataUrl) {
    // 创建预览弹窗
    var modal = document.createElement('div');
    modal.id = 'save-preview-modal';
    modal.style.cssText = 'position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.9);z-index:9999;display:flex;align-items:center;justify-content:center;';

    modal.innerHTML = '<div style="text-align:center;padding:20px;">' +
        '<img src="' + imageDataUrl + '" style="max-width:90%;max-height:70vh;border-radius:8px;box-shadow:0 4px 20px rgba(0,0,0,0.5);">' +
        '<p style="color:#fff;margin:20px 0;font-size:16px;">长按图片保存到相册</p>' +
        '<button onclick="closeSavePreview()" style="padding:12px 40px;background:#07C160;color:#fff;border:none;border-radius:25px;font-size:16px;">关闭</button>' +
        '</div>';

    document.body.appendChild(modal);
}

window.closeSavePreview = function() {
    var modal = document.getElementById('save-preview-modal');
    if (modal) {
        document.body.removeChild(modal);
    }
};

window.saveToAlbum = function() {
    // 保存到相册功能 - 使用新的微信兼容实现
    downloadReport();
};

window.shareToFriend = function() {
    alert('分享给朋友功能开发中...');
};

// 客服
window.openCustomerService = function() {
    closeUserMenu();
    var modal = document.getElementById('customer-service-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
};

window.closeCustomerService = function() {
    var modal = document.getElementById('customer-service-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

window.submitFeedback = function() {
    var content = document.getElementById('feedback-content');
    if (content && content.value.trim()) {
        alert('反馈已提交，感谢您的支持！');
        closeCustomerService();
    } else {
        alert('请输入反馈内容');
    }
};

// 解锁功能
window.unlockToolPackage = function(type) {
    /* if (!checkLogin()) return; disabled */
    var currentType = type || 'tool_package';
    showPaymentModal(currentType, 4.9);
};

// 解锁热门话题包
window.unlockTopicPackage = function() {
    // 检查是否登录
    /* if (!checkLogin()) return; disabled */
    // 显示支付弹窗，设置类型为topic_package，价格为4.9
    showPaymentModal('topic_package', 4.9);
};

// 隐私设置
window.updateBlurState = function() {
    var toggle = document.getElementById('privacy-blur-toggle');
    if (toggle) {
        var isEnabled = toggle.checked;
        var sensitiveElements = document.querySelectorAll('.blur-sensitive');
        sensitiveElements.forEach(function(el) {
            if (isEnabled) {
                el.classList.add('blurred');
            } else {
                el.classList.remove('blurred');
            }
        });
    }
};

// 日期选择
window.updateDate = function(type) {
    var yearEl = document.getElementById(type + '-year');
    var monthEl = document.getElementById(type + '-month');
    var dayEl = document.getElementById(type + '-day');
    var hiddenEl = document.getElementById(type + '-date');

    if (yearEl && monthEl && dayEl && hiddenEl) {
        var date = yearEl.value + '-' + monthEl.value + '-' + dayEl.value;
        hiddenEl.value = date;

        if (type === 'entry') {
            AppState.userData.entryDate = date;
        } else if (type === 'leave') {
            AppState.userData.leaveDate = date;
        }
    }
};

// 更新工资预览并保存到状态
window.updateSalaryPreview = function() {
    var salaryInput = document.getElementById('avg-salary');
    if (salaryInput && salaryInput.value) {
        AppState.userData.avgSalary = salaryInput.value;
    }
};

window.initDatePickers = function() {
    var currentYear = new Date().getFullYear();

    // 初始化年份选择器
    var yearSelects = document.querySelectorAll('#entry-year, #leave-year, #calc-entry-year, #calc-leave-year');
    yearSelects.forEach(function(select) {
        if (select && select.options.length <= 1) {
            // 添加默认选项
            var defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = '年';
            select.appendChild(defaultOption);

            for (var y = currentYear; y >= currentYear - 30; y--) {
                var option = document.createElement('option');
                option.value = y;
                option.textContent = y + '年';
                select.appendChild(option);
            }
        }
    });

    // 初始化月份选择器
    var monthSelects = document.querySelectorAll('#entry-month, #leave-month, #calc-entry-month, #calc-leave-month');
    monthSelects.forEach(function(select) {
        if (select && select.options.length <= 1) {
            var defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = '月';
            select.appendChild(defaultOption);

            for (var m = 1; m <= 12; m++) {
                var option = document.createElement('option');
                option.value = m;
                option.textContent = m + '月';
                select.appendChild(option);
            }
        }
    });

    // 初始化日期选择器
    var daySelects = document.querySelectorAll('#entry-day, #leave-day, #calc-entry-day, #calc-leave-day');
    daySelects.forEach(function(select) {
        if (select && select.options.length <= 1) {
            var defaultOption = document.createElement('option');
            defaultOption.value = '';
            defaultOption.textContent = '日';
            select.appendChild(defaultOption);

            for (var d = 1; d <= 31; d++) {
                var option = document.createElement('option');
                option.value = d;
                option.textContent = d + '日';
                select.appendChild(option);
            }
        }
    });
};

window.showToast = function(message) {
    var toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    toast.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(0,0,0,0.8);color:#fff;padding:20px 40px;border-radius:10px;z-index:9999;';
    document.body.appendChild(toast);

    setTimeout(function() {
        document.body.removeChild(toast);
    }, 2000);
};

window.showDisclaimer = function() {
    alert('本产品提供法律信息参考和工具服务，不构成法律意见。如需专业法律帮助，请咨询持证律师。');
};

// 从话题详情页进入专业诊断
window.startDiagnosisFromTopic = function() {
    closeTopicDetail();
    startDiagnosis();
};

// ==================== 平均工资计算器 ====================

// 打开计算器
window.openCalculator = function() {
    /* if (!checkLogin()) return; disabled */
    var modal = document.getElementById('calculator-modal');
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
    // 重置到第一步
    var section1 = document.getElementById('calc-section-1');
    var section2 = document.getElementById('calc-section-2');
    if (section1) section1.classList.remove('hidden');
    if (section2) section2.classList.add('hidden');

    // 更新步骤指示器
    var step1Indicator = document.getElementById('step1-indicator');
    var step2Indicator = document.getElementById('step2-indicator');
    if (step1Indicator) step1Indicator.classList.add('active');
    if (step2Indicator) step2Indicator.classList.remove('active');

    // 重置表单
    resetCalculatorForm();
};

// 关闭计算器
window.closeCalculator = function() {
    var modal = document.getElementById('calculator-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 重置计算器表单
window.resetCalculatorForm = function() {
    var citySelect = document.getElementById('calc-city');
    var basicSalary = document.getElementById('calc-basic-salary');
    var monthsWorked = document.getElementById('calc-months-worked');
    var performance = document.getElementById('calc-performance');
    var yearend = document.getElementById('calc-yearend');
    var overtime = document.getElementById('calc-overtime');
    var allowance = document.getElementById('calc-allowance');

    if (citySelect) citySelect.value = 'beijing';
    if (basicSalary) basicSalary.value = '';
    if (monthsWorked) monthsWorked.value = '12';
    if (performance) performance.value = '';
    if (yearend) yearend.value = '';
    if (overtime) overtime.value = '';
    if (allowance) allowance.value = '';

    // 取消所有"无"选项
    var checkboxes = document.querySelectorAll('#calc-section-2 input[type="checkbox"]');
    checkboxes.forEach(function(cb) {
        cb.checked = false;
    });

    // 启用所有输入框
    var inputs = document.querySelectorAll('#calc-section-2 input[type="number"]');
    inputs.forEach(function(input) {
        input.disabled = false;
        input.style.background = '';
    });
};

// 切换薪资输入框（"无"选项）
window.toggleSalaryInput = function(type) {
    var checkbox = document.getElementById('calc-' + type + '-none');
    var input = document.getElementById('calc-' + type);

    if (checkbox && input) {
        if (checkbox.checked) {
            input.value = '';
            input.disabled = true;
            input.style.background = '#f5f5f5';
        } else {
            input.disabled = false;
            input.style.background = '';
        }
        calculateAvgSalary();
    }
};

// 计算平均工资
window.calculateAvgSalary = function() {
    var basicSalary = parseFloat(document.getElementById('calc-basic-salary').value) || 0;
    var monthsWorked = parseInt(document.getElementById('calc-months-worked').value) || 12;

    // 其他薪资收入
    var performance = document.getElementById('calc-performance-none').checked ? 0 : (parseFloat(document.getElementById('calc-performance').value) || 0);
    var yearend = document.getElementById('calc-yearend-none').checked ? 0 : (parseFloat(document.getElementById('calc-yearend').value) || 0);
    var overtime = document.getElementById('calc-overtime-none').checked ? 0 : (parseFloat(document.getElementById('calc-overtime').value) || 0);
    var allowance = document.getElementById('calc-allowance-none').checked ? 0 : (parseFloat(document.getElementById('calc-allowance').value) || 0);

    // 年终奖按月折算
    var yearendMonthly = yearend / 12;

    // 计算月平均工资
    var monthlyAvg = basicSalary + performance + yearendMonthly + overtime + allowance;

    // 保存计算数据到状态
    AppState.calculatedData.avgSalary = monthlyAvg;
    AppState.calculatedData.basicSalary = basicSalary;
    AppState.calculatedData.performance = performance;
    AppState.calculatedData.yearendMonthly = yearendMonthly;
    AppState.calculatedData.overtime = overtime;
    AppState.calculatedData.allowance = allowance;
    AppState.calculatedData.monthsWorked = monthsWorked;
    AppState.calculatedData.city = document.getElementById('calc-city').value;

    return monthlyAvg;
};

// 进入步骤2
window.goToSalaryStep2 = function() {
    var basicSalary = document.getElementById('calc-basic-salary');
    if (!basicSalary || !basicSalary.value || parseFloat(basicSalary.value) <= 0) {
        alert('请输入基本工资');
        return;
    }

    var section1 = document.getElementById('calc-section-1');
    var section2 = document.getElementById('calc-section-2');
    if (section1) section1.classList.add('hidden');
    if (section2) section2.classList.remove('hidden');

    // 更新步骤指示器
    var step1Indicator = document.getElementById('step1-indicator');
    var step2Indicator = document.getElementById('step2-indicator');
    if (step1Indicator) step1Indicator.classList.remove('active');
    if (step2Indicator) step2Indicator.classList.add('active');

    // 计算一次
    calculateAvgSalary();
};

// 返回步骤1
window.goToSalaryStep1 = function() {
    var section1 = document.getElementById('calc-section-1');
    var section2 = document.getElementById('calc-section-2');
    if (section1) section1.classList.remove('hidden');
    if (section2) section2.classList.add('hidden');

    // 更新步骤指示器
    var step1Indicator = document.getElementById('step1-indicator');
    var step2Indicator = document.getElementById('step2-indicator');
    if (step1Indicator) step1Indicator.classList.add('active');
    if (step2Indicator) step2Indicator.classList.remove('active');
};

// 完成计算，显示结果
window.finishSalaryCalculation = function() {
    var avgSalary = calculateAvgSalary();

    if (avgSalary <= 0) {
        alert('请至少填写基本工资');
        return;
    }

    // 显示结果弹窗
    showSalaryResultModal(avgSalary);
};

// 显示计算结果弹窗
window.showSalaryResultModal = function(avgSalary) {
    var resultModal = document.getElementById('salary-result-modal');
    if (!resultModal) {
        // 如果结果弹窗不存在，创建一个
        var modalContainer = document.createElement('div');
        modalContainer.id = 'salary-result-modal';
        modalContainer.className = 'modal';
        modalContainer.innerHTML = getSalaryResultModalHTML(avgSalary);
        document.body.appendChild(modalContainer);
    } else {
        resultModal.innerHTML = getSalaryResultModalHTML(avgSalary);
    }

    resultModal = document.getElementById('salary-result-modal');
    resultModal.classList.remove('hidden');
    resultModal.style.display = 'flex';
};

// 获取结果弹窗HTML
function getSalaryResultModalHTML(avgSalary) {
    var cityName = document.getElementById('calc-city');
    cityName = cityName ? cityName.options[cityName.selectedIndex].text : '本地';

    var basicSalary = AppState.calculatedData.basicSalary || 0;
    var performance = AppState.calculatedData.performance || 0;
    var yearendMonthly = AppState.calculatedData.yearendMonthly || 0;
    var overtime = AppState.calculatedData.overtime || 0;
    var allowance = AppState.calculatedData.allowance || 0;

    return '<div class="modal-content">' +
        '<div class="modal-header">' +
            '<h2>📊 计算结果</h2>' +
            '<button class="close-btn" onclick="closeSalaryResultModal()">×</button>' +
        '</div>' +
        '<div class="salary-result-content">' +
            '<div class="salary-main-result">' +
                '<div class="result-label">您的月平均工资</div>' +
                '<div class="result-value">¥' + avgSalary.toLocaleString() + '</div>' +
                '<div class="result-note">* 此为参考值，实际以离职前12个月平均工资为准</div>' +
            '</div>' +
            '<div class="salary-breakdown">' +
                '<h4>💰 工资明细</h4>' +
                '<div class="breakdown-item">' +
                    '<span>基本工资</span>' +
                    '<span>¥' + basicSalary.toLocaleString() + '</span>' +
                '</div>' +
                (performance > 0 ? '<div class="breakdown-item"><span>绩效工资</span><span>¥' + performance.toLocaleString() + '</span></div>' : '') +
                (yearendMonthly > 0 ? '<div class="breakdown-item"><span>年终奖（折算）</span><span>¥' + yearendMonthly.toLocaleString() + '</span></div>' : '') +
                (overtime > 0 ? '<div class="breakdown-item"><span>加班费</span><span>¥' + overtime.toLocaleString() + '</span></div>' : '') +
                (allowance > 0 ? '<div class="breakdown-item"><span>补助补贴</span><span>¥' + allowance.toLocaleString() + '</span></div>' : '') +
            '</div>' +
            '<div class="salary-legal-ref">' +
                '<h4>📜 法律依据</h4>' +
                '<p>根据《劳动合同法》第四十七条：经济补偿金按劳动者离职前12个月平均工资计算</p>' +
                '<p>根据《劳动合同法实施条例》第二十七条：月工资包括计时工资、计件工资、奖金、津贴和补贴等劳动报酬</p>' +
            '</div>' +
            '<div class="salary-cta">' +
                '<button class="btn-primary" onclick="goToDiagnosis()">' +
                    '<span>🎯 开始诊断计算赔偿金</span>' +
                '</button>' +
                '<button class="btn-secondary" onclick="closeSalaryResultModal();closeCalculator();">' +
                    '<span>返回</span>' +
                '</button>' +
            '</div>' +
        '</div>' +
    '</div>';
}

// 关闭结果弹窗
window.closeSalaryResultModal = function() {
    var resultModal = document.getElementById('salary-result-modal');
    if (resultModal) {
        resultModal.classList.add('hidden');
        resultModal.style.display = 'none';
    }
};

// 跳转到诊断
window.goToDiagnosis = function() {
    closeSalaryResultModal();
    closeCalculator();
    // 使用计算出的平均工资预填充诊断表单
    setTimeout(function() {
        startDiagnosis();
        // 如果有平均工资输入框，预填充
        var avgSalaryInput = document.getElementById('avg-salary');
        if (avgSalaryInput && AppState.calculatedData.avgSalary) {
            avgSalaryInput.value = AppState.calculatedData.avgSalary;
            AppState.userData.avgSalary = AppState.calculatedData.avgSalary;
        }
    }, 300);
};

// ==================== 小程序图片保存功能 ====================

// 检测是否在微信小程序webview中
function isWeChatMiniProgram() {
    var ua = navigator.userAgent.toLowerCase();
    return ua.indexOf('miniprogram') > -1;
}

// 小程序环境中保存图片到相册
function saveImageInMiniProgram(imageDataUrl, loadingToast) {
    if (loadingToast) {
        loadingToast.textContent = '正在保存到相册...';
    }

    if (typeof wx !== 'undefined' && wx.miniProgram) {
        try {
            uploadImageToServer(imageDataUrl, function(imageUrl) {
                if (imageUrl) {
                    wx.miniProgram.navigateTo({
                        url: '/pages/save-image/save-image?imageUrl=' + encodeURIComponent(imageUrl)
                    });
                } else {
                    tryDirectTransfer(imageDataUrl, loadingToast);
                }
            });
        } catch (e) {
            console.error('跳转小程序页面失败:', e);
            showWeChatAuthGuide(loadingToast, imageDataUrl);
        }
    } else {
        if (loadingToast) {
            loadingToast.textContent = '小程序环境异常';
        }
    }
}

// 上传图片到服务器
function uploadImageToServer(base64Data, callback) {
    var base64WithoutPrefix = base64Data.replace(/^data:image\/\w+;base64,/, '');

    fetch(API_BASE_URL + '/api/upload/image', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            image: base64WithoutPrefix
        })
    })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if (data.success && data.url) {
            callback(data.url);
        } else {
            callback(null);
        }
    })
    .catch(function(err) {
        console.error('上传图片失败:', err);
        callback(null);
    });
}

// 尝试直接传递（备用方案）
function tryDirectTransfer(imageDataUrl, loadingToast) {
    var dataLength = encodeURIComponent(imageDataUrl).length;
    console.log('图片数据长度:', dataLength);

    if (dataLength < 1000000) {
        wx.miniProgram.navigateTo({
            url: '/pages/save-image/save-image?imageData=' + encodeURIComponent(imageDataUrl)
        });
    } else {
        if (loadingToast) {
            loadingToast.textContent = '报告内容过长';
        }
    }
}

var miniProgramMessageListenerInited = false;

// 接收小程序消息
function initMiniProgramMessageListener() {
    if (miniProgramMessageListenerInited) return;
    if (typeof wx !== 'undefined' && wx.miniProgram) {
        miniProgramMessageListenerInited = true;
        wx.miniProgram.onMessage(function(res) {
            console.log('收到小程序消息:', res);
            if (res.type === 'save_success') {
                // 隐藏正在保存的提示
                hideLoadingToast();
                // 显示保存成功提示
                showToast('报告已保存到相册！');
            } else if (res.type === 'save_fail') {
                // 隐藏正在保存的提示
                hideLoadingToast();
                // 显示保存失败提示
                showToast('保存失败，请重试');
            } else if (res.type === 'payment_success') {
                // 支付成功消息
                console.log('支付成功，产品类型:', res.productType);
                handlePaymentSuccess(res.productType);
            } else if (res.type === 'payment_fail') {
                // 支付失败消息
                console.log('支付失败:', res.message);
                showToast('支付失败：' + (res.message || '请重试'));
            }
        });
    }
}

// 隐藏加载提示toast
function hideLoadingToast() {
    // 尝试多种可能的toast元素
    var toastIds = ['download-loading', 'save-loading', 'saving-toast', 'loading-toast'];
    for (var i = 0; i < toastIds.length; i++) {
        var toast = document.getElementById(toastIds[i]);
        if (toast && toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }

    // 也尝试查找包含"正在保存"的元素
    var allElements = document.querySelectorAll('*');
    for (var j = 0; j < allElements.length; j++) {
        var elem = allElements[j];
        if (elem.textContent && elem.textContent.indexOf('正在保存') > -1) {
            var parent = elem.parentElement;
            while (parent && !parent.classList.contains('modal') && parent !== document.body) {
                parent = parent.parentElement;
            }
            if (parent && parent.classList.contains('modal')) {
                parent.classList.add('hidden');
                parent.style.display = 'none';
            }
        }
    }
}

// 显示toast提示
function showToast(message) {
    // 移除已存在的toast
    var existingToast = document.querySelector('.toast-message');
    if (existingToast && existingToast.parentNode) {
        existingToast.parentNode.removeChild(existingToast);
    }

    // 创建toast元素
    var toast = document.createElement('div');
    toast.className = 'toast-message';
    toast.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:rgba(0,0,0,0.8);color:#fff;padding:20px 40px;border-radius:10px;font-size:16px;z-index:10000;max-width:80%;text-align:center;';

    // 根据消息类型设置不同的图标
    if (message.indexOf('成功') > -1) {
        toast.innerHTML = '<div style="font-size:40px;margin-bottom:10px;">✅</div>';
    } else if (message.indexOf('失败') > -1 || message.indexOf('错误') > -1) {
        toast.innerHTML = '<div style="font-size:40px;margin-bottom:10px;">❌</div>';
    } else {
        toast.innerHTML = '<div style="font-size:40px;margin-bottom:10px;">ℹ️</div>';
    }
    toast.innerHTML += '<div>' + message + '</div>';

    document.body.appendChild(toast);

    // 2秒后自动隐藏
    setTimeout(function() {
        if (toast && toast.parentNode) {
            toast.parentNode.removeChild(toast);
        }
    }, 2000);
}

// 监听页面显示事件（从后台返回时隐藏加载提示）
document.addEventListener('visibilitychange', function() {
    if (document.visibilityState === 'visible') {
        // 页面重新显示时，隐藏所有加载提示
        hideLoadingToast();
    }
});

// 监听uni-app的页面显示事件（如果使用uni-app）
if (typeof uni !== 'undefined') {
    uni.onAppShow(function() {
        hideLoadingToast();
    });
}

// 监听wx.onAppShow（微信环境）
if (typeof wx !== 'undefined' && wx.onAppShow) {
    wx.onAppShow(function() {
        hideLoadingToast();
    });
}

// ==================== 核心功能函数 ====================

// 打开计算器
window.openCalculator = function() {
    /* if (!checkLogin()) return; disabled */
    // 显示平均工资计算器弹窗
    var modal = document.getElementById('calculator-modal');
    if (!modal) {
        // 如果弹窗不存在，创建一个
        createCalculatorModal();
        modal = document.getElementById('calculator-modal');
    }
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
};

// 创建计算器弹窗
function createCalculatorModal() {
    var modalHtml = `
        <div id="calculator-modal" class="modal hidden">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>平均工资计算器</h3>
                    <span class="modal-close" onclick="closeCalculator()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>入职时间</label>
                        <input type="date" id="calc-entry-date" class="form-input">
                    </div>
                    <div class="form-group">
                        <label>离职时间（选填）</label>
                        <input type="date" id="calc-leave-date" class="form-input">
                    </div>
                    <div class="form-group">
                        <label>月平均工资（元）</label>
                        <input type="number" id="calc-salary" class="form-input" placeholder="税前工资">
                    </div>
                    <button class="btn-primary" onclick="calculateCompensation()">计算赔偿金</button>
                    <div id="calc-result" class="calc-result"></div>
                </div>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', modalHtml);
}

// 关闭计算器
window.closeCalculator = function() {
    var modal = document.getElementById('calculator-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 计算赔偿金
window.calculateCompensation = function() {
    var entryDate = document.getElementById('calc-entry-date').value;
    var leaveDate = document.getElementById('calc-leave-date').value || new Date().toISOString().split('T')[0];
    var salary = parseFloat(document.getElementById('calc-salary').value);

    if (!entryDate || !salary) {
        alert('请填写入职时间和工资');
        return;
    }

    var entry = new Date(entryDate);
    var leave = new Date(leaveDate);
    var years = (leave - entry) / (1000 * 60 * 60 * 24 * 365);
    years = Math.round(years * 10) / 10;

    if (years < 0) {
        alert('离职时间不能早于入职时间');
        return;
    }

    // 使用新逻辑计算 N
    var n = calculateNValue(entryDate, leaveDate);
    var n1 = n + 1;
    var twoN = n * 2;

    var resultHtml = `
        <div class="compensation-result">
            <div class="result-title">您的赔偿金估算（基于${years}年工作年限）</div>
            <div class="result-grid">
                <div class="result-item">
                    <span class="result-label">N</span>
                    <span class="result-value">¥${(salary * n).toLocaleString()}</span>
                </div>
                <div class="result-item">
                    <span class="result-label">N+1</span>
                    <span class="result-value">¥${(salary * n1).toLocaleString()}</span>
                </div>
                <div class="result-item">
                    <span class="result-label">2N</span>
                    <span class="result-value">¥${(salary * twoN).toLocaleString()}</span>
                </div>
            </div>
            <div class="result-note">
                * 具体金额以实际为准，可先咨询专业律师
            </div>
        </div>
    `;
    document.getElementById('calc-result').innerHTML = resultHtml;
};

// 打开话术库（付费功能）
window.openScriptLibrary = function() {
    var modal = document.getElementById('script-modal');
    if (!modal) return;

    // 显示弹窗
    modal.classList.remove('hidden');
    modal.style.display = 'flex';
    modal.style.zIndex = '9998'; // 确保在支付弹窗(10000)之下

    if (typeof renderScriptModalContent === 'function') {
        renderScriptModalContent();
    } else {
        renderScriptList();
    }

    // 处理支付墙显示状态
    var paywall = document.getElementById('script-paywall');
    if (paywall) paywall.style.display = 'none';
};

// 渲染话术列表
window.renderScriptList = function() {
    var container = document.getElementById('script-library-content');
    if (!container) return;

    // 根据解锁状态决定显示多少条
    // 如果未解锁，显示前4条；如果已解锁，显示全部
    var dataToRender = AppState.hasToolPackage ? ScriptData : ScriptData.slice(0, 4);

    var html = '<div class="script-list" style="background-color: #1a1b23 !important; padding: 20px; border-radius: 12px; color: #fff !important;">';
    dataToRender.forEach(function(item) {
        html += `
            <div class="script-item" onclick="showScriptDetail(${item.id})" style="margin-bottom: 20px; cursor: pointer; border-bottom: 1px solid #2a2b36 !important; padding-bottom: 15px;">
                <div class="script-tag" style="display: inline-block; background-color: rgba(64, 110, 255, 0.15); color: #406eff; padding: 4px 8px; border-radius: 4px; font-size: 12px; margin-bottom: 10px;">${item.category}</div>
                <div class="script-title" style="font-size: 16px; font-weight: bold; margin-bottom: 8px; color: #fff !important;">${item.title}</div>
                <div class="script-desc" style="font-size: 14px; color: #8a8b94;">${item.desc}</div>
            </div>`;
    });
    

    if (!AppState.hasToolPackage) {
        html += `
            <div class="view-more-container" style="text-align:center; padding: 20px 0; position: relative; margin-top: -10px;">
                <div style="position: absolute; top: -60px; left: 0; right: 0; height: 60px; background: linear-gradient(to bottom, rgba(26,27,35,0), rgba(26,27,35,1)); z-index: 1; pointer-events: none;"></div>
                <div style="position: relative; z-index: 2; margin-bottom: 15px; color: #8a8b94; font-size: 12px; display: flex; align-items: center; justify-content: center;">
                    <span style="flex: 1; height: 1px; background: #2a2b36 !important; margin-right: 10px;"></span>
                    付费解锁更多话术
                    <span style="flex: 1; height: 1px; background: #2a2b36 !important; margin-left: 10px;"></span>
                </div>
                <button class="btn-primary" onclick="showPaymentModal('tool_package', 4.9)" style="position: relative; z-index: 2; border-radius: 24px; padding: 12px 30px; font-size: 16px; width: 100%; background: #406eff; color: white; border: none;">
                    🔒 解锁全部话术（¥4.9）
                </button>
            </div>
        `;
    }

    html += '</div>';
    container.innerHTML = html;
};

// 解锁工具包（话术库）
window.purchaseToolPackage = function(type) {
    /* if (!checkLogin()) return; disabled */
    showPaymentModal('tool_package', 4.9);
};

// 显示全部话术（已解锁）- 已废弃，合并到openScriptLibrary
function showAllScriptsModal() {
    // 兼容旧代码调用
    openScriptLibrary();
}

// 显示部分话术（未解锁）- 已废弃，合并到openScriptLibrary
function showPartialScriptsModal() {
    // 兼容旧代码调用
    openScriptLibrary();
}

// 购买话术库
window.purchaseToolPackage = function() {
    // 不关闭当前弹窗，让支付弹窗覆盖
    // closeScriptLibrary();
    // 显示支付弹窗，设置类型为script（对应话术库），价格为4.9
    // 注意：这里使用 'script' 是为了匹配 handlePaymentSuccess 中的逻辑和 HTML ID (script-paywall)
    showPaymentModal('script', 4.9);
};

// 关闭话术库
window.closeScriptLibrary = function() {
    var modal = document.getElementById('script-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
    // 兼容旧的动态弹窗
    var partialModal = document.getElementById('script-partial-modal');
    if (partialModal) {
        partialModal.classList.add('hidden');
        partialModal.style.display = 'none';
    }
};

// 显示话术详情
window.showScriptDetail = function(id) {
    var isFree = false;
    for (var i = 0; i < Math.min(4, ScriptData.length); i++) {
        if (ScriptData[i].id === id) {
            isFree = true;
            break;
        }
    }
    
    if (!isFree && !AppState.hasToolPackage) {
        showPaymentModal('tool_package', 4.9);
        return;
    }

    var script = ScriptData.find(function(s) { return s.id === id; });
    if (!script) return;

    var detailHtml = `
        <div id="script-detail-modal" class="modal" style="z-index:9999; display:flex; align-items: flex-end; justify-content: center; background: rgba(0,0,0,0.6);">
            <div class="modal-content" style="background-color: #1a1b23 !important; border-radius: 20px 20px 0 0; width: 100%; max-width: 600px; height: 85vh; padding: 0; color: #fff !important; display: flex; flex-direction: column;">
                <div class="modal-header" style="padding: 20px; border-bottom: 1px solid #2a2b36 !important; display: flex; justify-content: space-between; align-items: center; flex-shrink: 0;">
                    <h2 style="margin: 0; font-size: 18px; font-weight: bold;">话术详情</h2>
                    <button class="close-btn" onclick="closeScriptDetail()" style="background: none; border: none; color: #8a8b94; font-size: 24px; cursor: pointer;">×</button>
                </div>
                <div class="modal-body" style="padding: 20px; overflow-y: auto; flex: 1;">
                    <div class="script-detail">
                        <div class="detail-header" style="margin-bottom: 25px;">
                            <span class="detail-tag" style="display: inline-block; background-color: rgba(64, 110, 255, 0.15); color: #406eff; padding: 4px 8px; border-radius: 4px; font-size: 12px; margin-bottom: 15px;">${script.category}</span>
                            <h4 style="font-size: 18px; margin: 0; font-weight: bold;">${script.title}</h4>
                        </div>
                        <div class="detail-section" style="margin-bottom: 25px;">
                            <div class="detail-label" style="color: #8a8b94; font-size: 14px; margin-bottom: 12px;">HR可能会说：</div>
                            <div class="detail-content hr-say" style="border-left: 3px solid #ff7a68; padding-left: 15px; color: #fff !important; font-size: 15px; line-height: 1.6;">"${script.hrSay}"</div>
                        </div>
                        <div class="detail-section" style="margin-bottom: 25px;">
                            <div class="detail-label" style="color: #8a8b94; font-size: 14px; margin-bottom: 12px;">实际情况：</div>
                            <div class="detail-content truth" style="border-left: 3px solid #ffb84d; padding-left: 15px; color: #fff !important; font-size: 15px; line-height: 1.6;">${script.truth}</div>
                        </div>
                        <div class="detail-section" style="margin-bottom: 20px;">
                            <div class="detail-label" style="color: #8a8b94; font-size: 14px; margin-bottom: 12px;">建议回答：</div>
                            <div class="detail-content answer" style="background-color: #2a2b36 !important; border-left: 3px solid #4ade80; padding: 20px; border-radius: 8px; color: #fff !important; font-size: 15px; line-height: 1.6;">${script.answer}</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    // 移除旧的弹窗
    var detailModal = document.getElementById('script-detail-modal');
    if (detailModal) {
        detailModal.remove();
    }
    document.body.insertAdjacentHTML('beforeend', detailHtml);
    
    // 强制显示新弹窗
    setTimeout(function() {
        var newModal = document.getElementById('script-detail-modal');
        if (newModal) {
            newModal.classList.remove('hidden');
            newModal.style.display = 'flex';
        }
    }, 10);
};

window.closeScriptDetail = function() {
    var modal = document.getElementById('script-detail-modal');
    if (modal) {
        modal.remove();
    }
};

// 打开知识库（免费）
window.openKnowledgeBase = function() {
    var modal = document.getElementById('knowledge-modal');
    if (!modal) {
        var modalHtml = `
            <div id="knowledge-modal" class="modal hidden">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>📚 劳动法知识库</h3>
                        <span class="modal-close" onclick="closeKnowledgeBase()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="knowledge-list">`;
        KnowledgeData.forEach(function(item) {
            modalHtml += `
                <div class="knowledge-item" onclick="showKnowledgeDetail(${item.id})">
                    <div class="knowledge-title">${item.title}</div>
                    <div class="knowledge-desc">${item.desc}</div>
                </div>`;
        });
        modalHtml += `
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        modal = document.getElementById('knowledge-modal');
    }
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
};

window.closeKnowledgeBase = function() {
    var modal = document.getElementById('knowledge-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

window.showKnowledgeDetail = function(id) {
    var knowledge = KnowledgeData.find(function(k) { return k.id === id; });
    if (!knowledge) return;

    var detailHtml = `
        <div class="knowledge-detail">
            <h4>${knowledge.title}</h4>
            <div class="knowledge-content">${knowledge.content}</div>
        </div>
    `;

    var detailModal = document.getElementById('knowledge-detail-modal');
    if (!detailModal) {
        var detailHtmlStr = `
            <div id="knowledge-detail-modal" class="modal hidden">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>知识详情</h3>
                        <span class="modal-close" onclick="closeKnowledgeDetail()">&times;</span>
                    </div>
                    <div class="modal-body" id="knowledge-detail-content"></div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', detailHtmlStr);
        detailModal = document.getElementById('knowledge-detail-modal');
    }
    document.getElementById('knowledge-detail-content').innerHTML = detailHtml;
    detailModal.classList.remove('hidden');
    detailModal.style.display = 'flex';
};

window.closeKnowledgeDetail = function() {
    var modal = document.getElementById('knowledge-detail-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 打开热门话题列表（付费功能）
window.goToTopicList = function() {
    var page = document.getElementById('topic-list-page');
    if (page) {
        page.classList.remove('hidden');
        page.style.display = 'flex';
        page.style.zIndex = '9998'; // 确保在支付弹窗(10000)之下
    }
    renderTopicPage('全部');
};

// 显示全部话题（已解锁）
function showAllTopicsModal() {
    var modal = document.getElementById('topic-list-modal');
    if (!modal) {
        var modalHtml = `
            <div id="topic-list-modal" class="modal hidden" style="z-index: 9998;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>🔥 热门话题</h3>
                        <span class="modal-close" onclick="closeTopicListModal()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="topic-full-list">`;
        TopicData.forEach(function(topic) {
            modalHtml += `
                <div class="topic-full-item" onclick="showTopicDetail('${topic.id}')">
                    <span class="topic-full-tag">${topic.category}</span>
                    <span class="topic-full-title">${topic.title}</span>
                    <span class="topic-full-desc">${topic.desc}</span>
                </div>`;
        });
        modalHtml += `
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        modal = document.getElementById('topic-list-modal');
    }
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
}

// 显示话题列表（未解锁，显示前4条+付费按钮）
function showTopicListWithPayModal() {
    var modal = document.getElementById('topic-list-partial-modal');
    if (!modal) {
        // 前4个话题
        var freeTopics = TopicData.slice(0, 4);
        var modalHtml = `
            <div id="topic-list-partial-modal" class="modal hidden" style="z-index: 9998;">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>🔥 热门话题</h3>
                        <span class="modal-close" onclick="closeTopicListModal()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="topic-full-list">`;
        freeTopics.forEach(function(topic) {
            modalHtml += `
                <div class="topic-full-item" onclick="showTopicDetail('${topic.id}')">
                    <span class="topic-full-tag">${topic.category}</span>
                    <span class="topic-full-title">${topic.title}</span>
                    <span class="topic-full-desc">${topic.desc}</span>
                </div>`;
        });
        modalHtml += `
                        </div>
                        <div class="pay-section">
                            <div class="pay-divider">
                                <span>付费解锁更多话题</span>
                            </div>
                            <button class="btn-primary" onclick="purchaseTopicPackage()">
                                🔓 解锁全部话题（¥4.9）
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        modal = document.getElementById('topic-list-partial-modal');
    }
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
    }
}

window.closeTopicListModal = function() {
    var modal = document.getElementById('topic-list-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
    var partialModal = document.getElementById('topic-list-partial-modal');
    if (partialModal) {
        partialModal.classList.add('hidden');
        partialModal.style.display = 'none';
    }
};

// 显示话题详情（免费预览前4个）
window.showTopicDetail = function(topicId) {
    AppState.currentTopicId = topicId;

    var isFree = false;
    for (var i = 0; i < Math.min(4, TopicData.length); i++) {
        if (TopicData[i].id === topicId) {
            isFree = true;
            break;
        }
    }
    
    if (!isFree && !AppState.hasTopicPackage) {
        showPaymentModal('topic_package', 4.9);
        return;
    }

    var topic = TopicData.find(function(t) { return t.id === topicId; });
    if (!topic) return;

    var listModal = document.getElementById('topic-list-modal');
    if (listModal) {
        listModal.classList.add('hidden');
        listModal.style.display = 'none';
    }

    var detailModal = document.getElementById('topic-detail-modal');
    if (detailModal) {
        detailModal.remove(); // Remove old to avoid duplicates
    }

    var detailHtmlStr = `
        <div id="topic-detail-modal" class="modal hidden" style="z-index:9998; display:flex; align-items: flex-end; justify-content: center; background: rgba(0,0,0,0.6);">
            <div class="modal-content" style="background-color: #1a1b23 !important; border-radius: 16px; width: 90%; max-width: 400px; padding: 0; overflow: hidden; color: #fff !important;">
                <div class="modal-header" style="padding: 20px 20px 10px; border-bottom: none; display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin: 0; font-size: 18px; font-weight: bold;">话题标题</h3>
                    <span class="modal-close" onclick="closeTopicDetail()" style="font-size: 24px; cursor: pointer; color: #8a8b94;">&times;</span>
                </div>
                <div class="modal-body" style="padding: 0; overflow-y: auto; max-height: 70vh;">
                    <div class="topic-detail">
                        <div class="topic-detail-header" style="padding: 0 20px 20px;">
                            <span class="topic-detail-tag" style="display: inline-block; background-color: rgba(255, 122, 104, 0.15); color: #ff7a68; padding: 4px 8px; border-radius: 4px; font-size: 12px; margin-bottom: 10px;">${topic.category || ''}</span>
                            <h4 style="margin: 0 0 10px 0; font-size: 20px; font-weight: bold;">${topic.title || ''}</h4>
                            <p class="topic-detail-desc" style="color: #8a8b94; font-size: 14px; margin: 0;">${topic.desc || ''}</p>
                        </div>
                        <div class="topic-detail-content" style="padding: 0 20px 20px; font-size: 15px; line-height: 1.6; color: #e0e0e0;">
                            ${topic.content || ''}
                        </div>
                        ${topic.cases && topic.cases.length > 0 ? `
                        <div class="topic-cases" style="padding: 20px; border-top: 1px solid #2a2b36 !important;">
                            <h5 style="margin-bottom: 15px; font-size: 16px; color: #fff !important;">真实案例</h5>
                            ${topic.cases.map(function(c) {
                                return `
                                <div class="case-item" style="background: #2a2b36 !important; padding: 15px; border-radius: 12px; margin-bottom: 15px; border-left: 3px solid #406eff;">
                                    <div style="margin-bottom: 8px;"><span style="color: #406eff; font-size: 14px;">${c.platform || ''}</span></div>
                                    <div style="font-size: 14px; margin-bottom: 12px; color: #e0e0e0;">${c.summary || ''}</div>
                                    <div style="color: #4ade80; font-weight: bold; font-size: 14px; background: rgba(74, 222, 128, 0.1); padding: 8px 12px; border-radius: 6px; display: inline-block;">${c.result || ''}</div>
                                </div>`;
                            }).join('')}
                        </div>
                        ` : ''}
                    </div>
                </div>
                <div style="padding: 20px; border-top: 1px solid #2a2b36 !important; text-align: center;">
                    <button class="btn-primary" onclick="showCustomerService()" style="background: #406eff; color: white; border: none; border-radius: 24px; padding: 12px 30px; font-size: 16px; width: 100%;">💬 AI帮我分析案情</button>
                </div>
            </div>
        </div>
    `;
    document.body.insertAdjacentHTML('beforeend', detailHtmlStr);
    detailModal = document.getElementById('topic-detail-modal');
    
    if (detailModal) {
        detailModal.classList.remove('hidden');
        detailModal.style.display = 'flex';
        detailModal.style.zIndex = '9999';
    }
};

window.closeTopicDetail = function() {
    var modal = document.getElementById('topic-detail-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 显示话题包付费弹窗
window.showTopicPayModal = function() {
    var modal = document.getElementById('topic-pay-modal');
    if (!modal) {
        var modalHtml = `
            <div id="topic-pay-modal" class="modal hidden">
                <div class="modal-content pay-modal">
                    <div class="modal-header">
                        <h3>🔥 解锁热门话题</h3>
                        <span class="modal-close" onclick="closeTopicPayModal()">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="pay-icon">🔓</div>
                        <div class="pay-title">解锁全部热门话题</div>
                        <div class="pay-desc">包含N+1、2N、PIP、仲裁流程等深度内容，还有真实案例分析</div>
                        <div class="pay-price">¥4.9</div>
                        <button class="btn-primary btn-pay" onclick="purchaseTopicPackage()">立即解锁</button>
                        <div class="pay-tip">💡 付费后可查看全部话题详情和真实案例</div>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHtml);
        modal = document.getElementById('topic-pay-modal');
    }
    if (modal) {
        modal.classList.remove('hidden');
        modal.style.display = 'flex';
        modal.style.zIndex = '1040';
    }
};

window.closeTopicPayModal = function() {
    var modal = document.getElementById('topic-pay-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.style.display = 'none';
    }
};

// 购买话题包 - 跳转到小程序支付页面
window.purchaseTopicPackage = function() {
    console.log('触发 purchaseTopicPackage');
    
    // 关闭话题相关的弹窗（不包括底部的支付收银台）
    closeTopicPayModal();
    var partialModal = document.getElementById('topic-list-partial-modal');
    if (partialModal) {
        partialModal.classList.add('hidden');
        partialModal.style.display = 'none';
    }

    if (!checkLogin()) {
        console.log('未登录，拦截 purchaseTopicPackage');
        return; 
    }

    console.log('准备显示支付弹窗，类型: topic_package');
    // 显示支付弹窗，设置类型为topic_package，价格为4.9
    showPaymentModal('topic_package', 4.9);
};
