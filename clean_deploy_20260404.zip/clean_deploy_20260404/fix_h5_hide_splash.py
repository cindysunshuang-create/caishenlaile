import re
import os
import shutil

app_js_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/app.js'

with open(app_js_path, 'r', encoding='utf-8') as f:
    content = f.read()

# 恢复 H5 隐藏自己内部引导页的逻辑（因为小程序端已经有了一个精美的原生引导页）
old_init = """document.addEventListener('DOMContentLoaded', function() {
    console.log('裁神来了 - DOM加载完成');

    // 初始化数据渲染
    initLandingPage();"""

new_init = """document.addEventListener('DOMContentLoaded', function() {
    console.log('裁神来了 - DOM加载完成');

    // 由于外部小程序已经有精美的引导页了，这里 H5 一加载就直接隐藏自己的简陋引导页
    var splashScreen = document.getElementById('splash-screen');
    var mainContent = document.getElementById('main-content');
    if (splashScreen) splashScreen.style.display = 'none';
    if (mainContent) {
        mainContent.classList.remove('hidden');
        mainContent.style.display = 'block';
    }

    // 初始化数据渲染
    initLandingPage();"""

content = content.replace(old_init, new_init)

with open(app_js_path, 'w', encoding='utf-8') as f:
    f.write(content)

# Update index.html version cache
index_html_path = '/Users/cindy/Desktop/caishenlaile/miniprogram/deploy_packages/clean_deploy_20260404/index.html'
with open(index_html_path, 'r', encoding='utf-8') as f:
    html_content = f.read()

html_content = re.sub(r'app\.js\?v=[a-zA-Z0-9_]+', 'app.js?v=20260404_TRUE_FINAL_SPLASH', html_content)

with open(index_html_path, 'w', encoding='utf-8') as f:
    f.write(html_content)

print("H5 inner splash hidden again. Ready for deployment.")